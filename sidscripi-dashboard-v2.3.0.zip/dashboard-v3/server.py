#!/usr/bin/env python3
"""
SidscriPi Server Dashboard v2.3.0
- Real-time system & service monitoring
- Start / Stop / Restart (systemd, Docker, Windows/remote probe)
- Built-in iframe service viewer
- Config file editor with smart suggestions + full file browser
- Add Server wizard: Scan (systemd/Docker/ports) or Manual
- Docker container support
- Windows / VM / remote service support (port-probe status)
- Kiwix library refresh
Runs on port 8029
"""

import subprocess
import json
import os
import re
import socket
import uuid
import urllib.parse
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime
import shutil

# ─── Service Definitions ───
# (name, unit, port, category, description, web_path, config_files)
# web_path=None means no web UI, web_path="" means root
SERVICES = [
    # Media
    ("Plex", "plexmediaserver", 32400, "media", "Media Server", "/web", []),
    ("Navidrome", "navidrome", 4533, "media", "Music Streaming", "", ["/opt/appdata/navidrome/navidrome.toml"]),
    ("Kiwix", "kiwix", 8090, "media", "Offline Wikipedia", "", []),
    ("MPD Local", "mpd", 6600, "media", "Music Player (Local)", None, ["/etc/mpd.conf"]),
    ("MPD Stream", "mpd-stream", 6601, "media", "Music Player (HTTP Stream)", None, ["/etc/mpd-stream.conf"]),
    ("ympd Local", "ympd-local", 8586, "media", "MPD Web UI (Local)", "", []),
    ("ympd Stream", "ympd-stream", 8587, "media", "MPD Web UI (Stream)", "", []),

    # *arr Stack
    ("Sonarr A", "sonarr-a", 8989, "arr", "TV Shows (A)", "", ["/opt/appdata/sonarr-a/config/config.xml"]),
    ("Sonarr B", "sonarr-b", 8990, "arr", "TV Shows (B)", "", ["/opt/appdata/sonarr-b/config/config.xml"]),
    ("Radarr A", "radarr-a", 7878, "arr", "Movies (A)", "", ["/opt/appdata/radarr-a/config/config.xml"]),
    ("Radarr B", "radarr-b", 7879, "arr", "Movies (B)", "", ["/opt/appdata/radarr-b/config/config.xml"]),
    ("Lidarr B", "lidarr-b", 8687, "arr", "Music (B)", "", ["/opt/appdata/lidarr-b/config/config.xml"]),
    ("Readarr A", "readarr-a", 8787, "arr", "Books (A)", "", ["/opt/appdata/readarr-a/config/config.xml"]),
    ("Readarr B", "readarr-b", 8788, "arr", "Books (B)", "", ["/opt/appdata/readarr-b/config/config.xml"]),
    ("Readarr Audiobooks A", "readarr-audiobooks-a", 8789, "arr", "Audiobooks (A)", "", ["/opt/appdata/readarr-audiobooks-a/config/config.xml"]),
    ("Readarr Audiobooks B", "readarr-audiobooks-b", 8790, "arr", "Audiobooks (B)", "", ["/opt/appdata/readarr-audiobooks-b/config/config.xml"]),
    ("Prowlarr A", "prowlarr-a", 9696, "arr", "Indexer Manager (A)", "", ["/opt/appdata/prowlarr-a/config/config.xml"]),
    ("Prowlarr B", "prowlarr-b", 9697, "arr", "Indexer Manager (B)", "", ["/opt/appdata/prowlarr-b/config/config.xml"]),

    # Downloads
    ("Deluge Daemon",          "deluged",                58846, "downloads", "Torrent Daemon", None, ["/opt/appdata/deluged/core.conf"]),
    ("Deluge Web",             "deluge-web",              8112, "downloads", "Torrent Web UI",  "",  []),
    ("SABnzbd",                "sabnzbd",                 8095, "downloads", "Usenet Downloader", "", ["/opt/appdata/sabnzbd/sabnzbd.ini"]),

    # TV / DVR
    ("xTeVe A", "xteve-a", 34400, "tv", "IPTV Proxy (A)", "/web", []),
    ("xTeVe B", "xteve-b", 34401, "tv", "IPTV Proxy (B)", "/web", []),

    # Home & Apps
    ("Home Assistant", "homeassistant", 8123, "home", "Home Automation", "", ["/opt/appdata/homeassistant/config/configuration.yaml"]),
    ("Adv. Flashcards", "advanced-flashcards", 8009, "home", "Flashcards Web Server", "", []),

    # System
    ("SSH", "ssh", 22, "system", "Secure Shell", None, ["/etc/ssh/sshd_config"]),
    ("Samba", "smbd", 445, "system", "File Sharing", None, ["/etc/samba/smb.conf"]),
    ("xRDP", "xrdp", 3389, "system", "Remote Desktop", None, ["/etc/xrdp/xrdp.ini"]),
    ("CUPS", "cups", 631, "system", "Printing", "", []),
    ("Bluetooth", "bluetooth", None, "system", "Bluetooth Service", None, ["/etc/bluetooth/main.conf"]),
    ("Pi Dashboard", "pi-dashboard", 8029, "system", "This Dashboard", "", ["/opt/pi-dashboard/server.py"]),
]

CATEGORY_META = {
    "media":     {"label": "Media",        "icon": "🎬"},
    "arr":       {"label": "Arr Stack",    "icon": "📡"},
    "downloads": {"label": "Downloads",    "icon": "⬇️"},
    "tv":        {"label": "TV / DVR",     "icon": "📺"},
    "home":      {"label": "Home & Apps",  "icon": "🏠"},
    "system":    {"label": "System",       "icon": "⚙️"},
    "docker":    {"label": "Docker",       "icon": "🐋"},
    "windows":   {"label": "Windows / VM", "icon": "🪟"},
    "remote":    {"label": "Remote",       "icon": "🌐"},
}

# Safety: only allow editing files under these paths
ALLOWED_EDIT_PATHS = [
    "/opt/appdata/", "/etc/mpd", "/etc/samba/", "/etc/ssh/",
    "/etc/bluetooth/", "/etc/xrdp/", "/opt/pi-dashboard/",
    "/opt/appdata/homeassistant/", "/opt/appdata/navidrome/",
    "/opt/", "/etc/", "/home/",
]

# ─── Smart config file suggestions (by unit keyword) ───
CONFIG_TEMPLATES = {
    "sonarr":        ["/opt/appdata/{unit}/config/config.xml"],
    "radarr":        ["/opt/appdata/{unit}/config/config.xml"],
    "lidarr":        ["/opt/appdata/{unit}/config/config.xml"],
    "readarr":       ["/opt/appdata/{unit}/config/config.xml"],
    "prowlarr":      ["/opt/appdata/{unit}/config/config.xml"],
    "sabnzbd":       ["/opt/appdata/{unit}/sabnzbd.ini"],
    "deluged":       ["/opt/appdata/deluged/core.conf"],
    "navidrome":     ["/opt/appdata/navidrome/navidrome.toml"],
    "homeassistant": ["/opt/appdata/homeassistant/config/configuration.yaml",
                      "/opt/appdata/homeassistant/config/automations.yaml"],
    "smbd":          ["/etc/samba/smb.conf"],
    "ssh":           ["/etc/ssh/sshd_config"],
    "xrdp":          ["/etc/xrdp/xrdp.ini"],
    "mpd":           ["/etc/mpd.conf"],
    "bluetooth":     ["/etc/bluetooth/main.conf"],
    "zim-forge":     ["/opt/zim-forge/settings.json"],
    "kiwix":         [],
}

# ─── System-wide files always available in the editor ───
SYSTEM_CONFIG_FILES = [
    "/etc/fstab", "/etc/hosts", "/etc/hostname", "/etc/crontab",
    "/etc/samba/smb.conf", "/etc/ssh/sshd_config", "/etc/xrdp/xrdp.ini",
    "/etc/bluetooth/main.conf", "/etc/dhcpcd.conf", "/etc/network/interfaces",
    "/etc/mpd.conf", "/opt/pi-dashboard/server.py",
]

# ─── Common ports for the port scanner ───
SCAN_PORT_MAP = {
    80:    ("HTTP",         "Web Server",         "remote",    ""),
    443:   ("HTTPS",        "Secure Web",         "remote",    ""),
    4533:  ("Navidrome",    "Music Streaming",    "media",     ""),
    5000:  ("ZIM Forge",    "Kiwix Conversion",   "home",      ""),
    6600:  ("MPD",          "Music Player",       "media",     None),
    7878:  ("Radarr",       "Movies",             "arr",       ""),
    8009:  ("Flashcards",   "Flashcards App",     "home",      ""),
    8029:  ("Pi Dashboard", "This Dashboard",     "system",    ""),
    8080:  ("HTTP-Alt",     "Web Server",         "remote",    ""),
    8090:  ("Kiwix",        "Offline Library",    "media",     ""),
    8095:  ("SABnzbd",      "Usenet Client",      "downloads", ""),
    8112:  ("Deluge",       "Torrent UI",         "downloads", ""),
    8123:  ("HomeAsst",     "Home Automation",    "home",      ""),
    8443:  ("HTTPS-Alt",    "Secure Web",         "remote",    ""),
    8586:  ("ympd",         "MPD Web UI",         "media",     ""),
    8989:  ("Sonarr",       "TV Shows",           "arr",       ""),
    9696:  ("Prowlarr",     "Indexer Manager",    "arr",       ""),
    32400: ("Plex",         "Media Server",       "media",     "/web"),
    34400: ("xTeVe",        "IPTV Proxy",         "tv",        "/web"),
}


# ─── Dashboard Settings (dashboard-only mappings) ───
SETTINGS_PATH = "/opt/pi-dashboard/settings.json"
SETTINGS_SCHEMA_VERSION = 3

def _suggest_configs(unit, existing_configs):
    """Return best config file list for a unit using templates, then fallback scan."""
    ok = [c for c in (existing_configs or []) if os.path.isfile(c)]
    if ok:
        return ok
    for kw, tmpl in CONFIG_TEMPLATES.items():
        if kw in unit.lower():
            resolved = [t.replace("{unit}", unit) for t in tmpl]
            found = [c for c in resolved if os.path.isfile(c)]
            if found:
                return found
            if resolved:
                return resolved
    cands = []
    for d in [f"/opt/appdata/{unit}/config", f"/opt/appdata/{unit}", f"/etc/{unit}"]:
        if os.path.isdir(d):
            try:
                for fn in sorted(os.listdir(d)):
                    ext = fn.lower().split(".")[-1] if "." in fn else ""
                    if ext in ("conf", "ini", "toml", "xml", "yaml", "yml", "json", "cfg"):
                        cands.append(os.path.join(d, fn))
            except Exception:
                pass
    return cands[:6]

def _default_service_map():
    svc = {}
    for name, unit, port, cat, desc, web_path, configs in SERVICES:
        guessed_data = [f"/opt/appdata/{unit}"]
        for cf in (configs or []):
            try:
                d = os.path.dirname(cf)
                if d and d not in guessed_data:
                    guessed_data.append(d)
            except Exception:
                pass

        entry = {
            "display_name": name,
            "unit": unit,
            "port": port,
            "web_path": web_path,
            "config_files": _suggest_configs(unit, list(configs or [])),
            "data_paths": guessed_data,
            "runtime": "systemd",
        }

        if unit == "kiwix":
            entry["kiwix_zim_dir"] = "/opt/appdata/kiwix/data/zims"
            entry["kiwix_library_xml"] = "/opt/appdata/kiwix/data/library.xml"

        svc[unit] = entry
    return svc

def default_settings():
    return {
        "schema_version": SETTINGS_SCHEMA_VERSION,
        "dashboard": {
            "viewer_host": "auto",
            "viewer_scheme": "http",
            "hide_stopped_services": False,
            "protect_dashboard_service": True,
            "hidden_units": [],
        },
        "services": _default_service_map(),
        "custom_services": [],
        "auto_detect": {
            "enabled": True,
            "write_back_missing": True,
        },
    }

def _migrate_old_settings(obj):
    """Migrate very old settings.json (kiwix_* keys at root) to schema v2."""
    s = default_settings()
    if isinstance(obj, dict):
        kz = obj.get("kiwix_zim_dir")
        kx = obj.get("kiwix_library_xml")
        if kz:
            s["services"]["kiwix"]["kiwix_zim_dir"] = str(kz)
        if kx:
            s["services"]["kiwix"]["kiwix_library_xml"] = str(kx)
        vh = obj.get("viewer_host") or obj.get("dashboard_host")
        if vh:
            s["dashboard"]["viewer_host"] = str(vh)
    return s

def _autodetect_service(unit, current_entry):
    """Best-effort dashboard-side discovery: find likely config/data paths."""
    entry = dict(current_entry or {})
    entry.setdefault("unit", unit)

    try:
        frag, _ = run_cmd(f"systemctl show {unit} --property=FragmentPath --value", timeout=4)
        workdir, _ = run_cmd(f"systemctl show {unit} --property=WorkingDirectory --value", timeout=4)
        execs, _ = run_cmd(f"systemctl show {unit} --property=ExecStart --value", timeout=4)

        for p in [frag.strip(), workdir.strip()]:
            if p and p.startswith("/"):
                d = p if os.path.isdir(p) else os.path.dirname(p)
                if d and d not in entry.get("data_paths", []):
                    entry.setdefault("data_paths", []).append(d)

        for token in re.findall(r"(/[^\s'\"]+)", execs or ""):
            if token.startswith("/"):
                d = token if os.path.isdir(token) else os.path.dirname(token)
                if d and d not in entry.get("data_paths", []):
                    entry.setdefault("data_paths", []).append(d)
    except Exception:
        pass

    cfgs = entry.get("config_files") or []
    cfgs_existing = [c for c in cfgs if isinstance(c, str) and c.startswith("/") and os.path.isfile(c)]
    if not cfgs_existing:
        candidates = []
        common_dirs = [
            f"/opt/appdata/{unit}/config",
            f"/opt/appdata/{unit}",
            f"/etc/{unit}",
            "/etc",
        ]
        for d in common_dirs:
            if os.path.isdir(d):
                try:
                    for fn in os.listdir(d):
                        if fn.lower().endswith((".conf", ".ini", ".toml", ".xml", ".yaml", ".yml")):
                            candidates.append(os.path.join(d, fn))
                except Exception:
                    pass
        if candidates:
            entry["config_files"] = sorted(list(dict.fromkeys(candidates)))[:8]

    dps = []
    for p in entry.get("data_paths", []):
        p = str(p).strip()
        if p.startswith("/") and p not in dps:
            dps.append(p)
    entry["data_paths"] = dps

    return entry

def load_settings():
    base = default_settings()
    try:
        if os.path.isfile(SETTINGS_PATH):
            with open(SETTINGS_PATH, "r") as f:
                obj = json.load(f)

            if not isinstance(obj, dict) or int(obj.get("schema_version", 0)) < SETTINGS_SCHEMA_VERSION:
                obj = _migrate_old_settings(obj)

            dash = obj.get("dashboard", {}) if isinstance(obj, dict) else {}
            if isinstance(dash, dict):
                base["dashboard"]["viewer_host"] = str(dash.get("viewer_host", base["dashboard"]["viewer_host"]))
                base["dashboard"]["viewer_scheme"] = str(dash.get("viewer_scheme", base["dashboard"]["viewer_scheme"]))
                base["dashboard"]["hide_stopped_services"] = bool(dash.get("hide_stopped_services", False))
                base["dashboard"]["protect_dashboard_service"] = bool(dash.get("protect_dashboard_service", True))
                hu = dash.get("hidden_units", [])
                base["dashboard"]["hidden_units"] = hu if isinstance(hu, list) else []

            svc_obj = obj.get("services", {}) if isinstance(obj, dict) else {}
            if isinstance(svc_obj, dict):
                for unit, def_entry in base["services"].items():
                    cur = svc_obj.get(unit, {})
                    if isinstance(cur, dict):
                        merged = dict(def_entry)
                        for k in ("port", "web_path", "config_files", "data_paths",
                                  "kiwix_zim_dir", "kiwix_library_xml", "runtime",
                                  "docker_container"):
                            if k in cur:
                                merged[k] = cur[k]
                        base["services"][unit] = merged

            # Load custom services (v2.3+)
            cs = obj.get("custom_services", []) if isinstance(obj, dict) else []
            if isinstance(cs, list):
                base["custom_services"] = [c for c in cs if isinstance(c, dict)]

            ad = obj.get("auto_detect", {}) if isinstance(obj, dict) else {}
            if isinstance(ad, dict):
                base["auto_detect"]["enabled"] = bool(ad.get("enabled", True))
                base["auto_detect"]["write_back_missing"] = bool(ad.get("write_back_missing", True))
    except Exception:
        pass

    try:
        if base.get("auto_detect", {}).get("enabled", True):
            changed = False
            for unit, entry in base["services"].items():
                if not entry.get("data_paths") or not entry.get("config_files"):
                    base["services"][unit] = _autodetect_service(unit, entry)
                    changed = True
            if changed and base.get("auto_detect", {}).get("write_back_missing", True):
                save_settings(base)
    except Exception:
        pass

    return base

def _validate_settings(s):
    if not isinstance(s, dict):
        return False, "Settings must be an object"
    if int(s.get("schema_version", 0)) < 1:
        return False, "schema_version required"

    dash = s.get("dashboard", {})
    if not isinstance(dash, dict):
        return False, "dashboard must be an object"
    vh = str(dash.get("viewer_host", "")).strip()
    if not vh:
        return False, "dashboard.viewer_host is required"
    vs = str(dash.get("viewer_scheme", "http")).strip().lower()
    if vs not in ("http", "https"):
        return False, "dashboard.viewer_scheme must be http or https"

    # Optional dashboard UI/safety settings
    hs = dash.get("hide_stopped_services", False)
    pd = dash.get("protect_dashboard_service", True)
    hu = dash.get("hidden_units", [])
    if not isinstance(hs, (bool, int)):
        return False, "dashboard.hide_stopped_services must be a boolean"
    if not isinstance(pd, (bool, int)):
        return False, "dashboard.protect_dashboard_service must be a boolean"
    if hu is None:
        hu = []
    if not isinstance(hu, list):
        return False, "dashboard.hidden_units must be a list"
    valid_units = {u for _, u, _, _, _, _, _ in SERVICES}
    cleaned_hu = []
    for u in hu:
        u = str(u).strip()
        if not u:
            continue
        if u not in valid_units:
            continue
        if u not in cleaned_hu:
            cleaned_hu.append(u)
    dash["hide_stopped_services"] = bool(hs)
    dash["protect_dashboard_service"] = bool(pd)
    dash["hidden_units"] = cleaned_hu


    svc = s.get("services", {})
    if not isinstance(svc, dict):
        return False, "services must be an object"

    valid_units = {u for _, u, _, _, _, _, _ in SERVICES}
    for unit, entry in svc.items():
        if unit not in valid_units:
            continue
        if not isinstance(entry, dict):
            return False, f"services.{unit} must be an object"
        port = entry.get("port", None)
        if port is not None:
            try:
                p = int(port)
                if p < 1 or p > 65535:
                    return False, f"services.{unit}.port invalid"
                entry["port"] = p
            except Exception:
                return False, f"services.{unit}.port must be a number"
        for lk in ("config_files", "data_paths"):
            if lk in entry:
                if not isinstance(entry[lk], list):
                    return False, f"services.{unit}.{lk} must be a list"
                cleaned = []
                for v in entry[lk]:
                    v = str(v).strip()
                    if not v:
                        continue
                    if not v.startswith("/"):
                        return False, f"services.{unit}.{lk} entries must be absolute paths"
                    if v not in cleaned:
                        cleaned.append(v)
                entry[lk] = cleaned

        if unit == "kiwix":
            for k in ("kiwix_zim_dir", "kiwix_library_xml"):
                if k in entry:
                    v = str(entry[k]).strip()
                    if v and not v.startswith("/"):
                        return False, f"services.kiwix.{k} must be an absolute path"

    return True, "OK"

def save_settings(s):
    ok, msg = _validate_settings(s)
    if not ok:
        return False, msg

    tmp = SETTINGS_PATH + ".tmp"
    try:
        os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
        with open(tmp, "w") as f:
            json.dump(s, f, indent=2)
        os.replace(tmp, SETTINGS_PATH)
        return True, "Settings saved"
    except Exception as e:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        return False, str(e)


def run_cmd(cmd, timeout=8):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip(), r.returncode
    except Exception as e:
        return str(e), 1


def _probe_port(host, port, timeout=1.5):
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True
    except Exception:
        return False


def get_service_status(unit, runtime="systemd", host="localhost", port=None, docker_container=None):
    if runtime == "systemd":
        out, _ = run_cmd(f"systemctl is-active {unit}")
        return out.strip()
    elif runtime == "docker":
        cname = docker_container or unit
        out, rc = run_cmd(f"docker inspect --format={{{{.State.Status}}}} {cname} 2>/dev/null")
        if rc != 0 or not out.strip():
            return "inactive"
        return "active" if out.strip().lower() == "running" else out.strip().lower()
    elif runtime in ("windows", "external", "remote"):
        if port:
            return "active" if _probe_port(host or "localhost", port) else "inactive"
        return "unknown"
    return "unknown"


def get_service_memory(unit, runtime="systemd", docker_container=None):
    if runtime == "systemd":
        out, _ = run_cmd(f"systemctl show {unit} --property=MemoryCurrent --value")
        try:
            val = int(out)
            if val > 0:
                return val / (1024 * 1024)
        except Exception:
            pass
    elif runtime == "docker":
        cname = docker_container or unit
        out, rc = run_cmd(f"docker stats --no-stream --format {{{{.MemUsage}}}} {cname} 2>/dev/null")
        if rc == 0 and out.strip():
            import re as _re
            m = _re.match(r"([\d.]+)([KMG]i?B)", out.strip())
            if m:
                val, u = float(m.group(1)), m.group(2)
                mult = {"KiB": 1/1024, "MiB": 1, "GiB": 1024, "KB": 1/1024, "MB": 1, "GB": 1024}.get(u, 1)
                return round(val * mult, 1)
    return None


def get_service_cpu(unit, runtime="systemd"):
    if runtime == "systemd":
        pid_out, _ = run_cmd(f"systemctl show {unit} --property=MainPID --value")
        try:
            pid = int(pid_out)
            if pid > 0:
                cpu, _ = run_cmd(f"ps -p {pid} -o %cpu= 2>/dev/null")
                return float(cpu.strip()) if cpu.strip() else None
        except Exception:
            pass
    return None


def scan_services():
    """Discover new services not already in the dashboard."""
    known = set(svc[1] for svc in SERVICES)
    s = load_settings()
    known |= {c.get("unit", "") for c in s.get("custom_services", [])}
    result = {"systemd": [], "docker": [], "ports": []}

    # systemd
    try:
        out, rc = run_cmd("systemctl list-units --type=service --all --no-pager 2>/dev/null", timeout=15)
        if rc == 0 and out:
            for line in out.splitlines():
                m = re.match(r"\s*\*?\s*([\w@.\-]+\.service)\s+\S+\s+(\S+)\s+\S+\s+(.*)", line)
                if not m:
                    continue
                unit = m.group(1).replace(".service", "")
                active = m.group(2)
                if unit in known:
                    continue
                if re.match(r"(sys-|user@|getty|systemd-|session-)", unit):
                    continue
                result["systemd"].append({
                    "unit": unit, "active": active,
                    "description": m.group(3).strip()[:60], "suggested_port": None
                })
    except Exception:
        pass

    # Docker
    try:
        out, rc = run_cmd(
            "docker ps -a --format '{{.Names}}\t{{.Status}}\t{{.Ports}}\t{{.Image}}' 2>/dev/null",
            timeout=10
        )
        if rc == 0 and out.strip():
            for line in out.strip().splitlines():
                parts = line.split("\t")
                if len(parts) < 2:
                    continue
                cname = parts[0].strip()
                cstatus = parts[1].strip()
                cports = parts[2].strip() if len(parts) > 2 else ""
                cimage = parts[3].strip() if len(parts) > 3 else ""
                pm = re.search(r":(\d+)->", cports)
                result["docker"].append({
                    "container": cname,
                    "status": "active" if "Up" in cstatus else "inactive",
                    "image": cimage, "ports": cports,
                    "suggested_port": int(pm.group(1)) if pm else None
                })
    except Exception:
        pass

    # Port scan (threaded)
    lock = threading.Lock()

    def check_port(port, info):
        if _probe_port("localhost", port, timeout=0.6):
            with lock:
                result["ports"].append({
                    "port": port, "name": info[0], "description": info[1],
                    "category": info[2], "web_path": info[3]
                })

    threads = [threading.Thread(target=check_port, args=(p, i)) for p, i in SCAN_PORT_MAP.items()]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=3)

    # Remove already-known ports
    known_ports = {svc[2] for svc in SERVICES if svc[2]}
    result["ports"] = [p for p in result["ports"] if p["port"] not in known_ports]
    return result



def get_system_info():
    info = {}
    info["hostname"], _ = run_cmd("hostname")
    ip_out, _ = run_cmd("hostname -I")
    info["ip"] = ip_out.split()[0] if ip_out else "unknown"

    uptime_raw, _ = run_cmd("cat /proc/uptime")
    if uptime_raw:
        secs = float(uptime_raw.split()[0])
        d, h, m = int(secs // 86400), int((secs % 86400) // 3600), int((secs % 3600) // 60)
        info["uptime"] = f"{d}d {h}h {m}m"

    load_out, _ = run_cmd("cat /proc/loadavg")
    if load_out:
        p = load_out.split()
        info["load"] = f"{p[0]} / {p[1]} / {p[2]}"

    temp, _ = run_cmd("cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null")
    if temp:
        try: info["cpu_temp"] = round(int(temp) / 1000, 1)
        except: pass

    mem_out, _ = run_cmd("free -b")
    if mem_out:
        lines = mem_out.split("\n")
        mp = lines[1].split()
        info["mem_total"] = int(mp[1])
        info["mem_used"] = int(mp[2])
        info["mem_available"] = int(mp[6]) if len(mp) > 6 else int(mp[1]) - int(mp[2])
        sp = lines[2].split()
        info["swap_total"] = int(sp[1])
        info["swap_used"] = int(sp[2])

    disk_out, _ = run_cmd("df -B1 /")
    if disk_out:
        dp = disk_out.split("\n")[1].split()
        info["disk_total"] = int(dp[1])
        info["disk_used"] = int(dp[2])
        info["disk_avail"] = int(dp[3])

    info["os"], _ = run_cmd("cat /etc/os-release | grep PRETTY_NAME | cut -d'\"' -f2")
    info["kernel"], _ = run_cmd("uname -r")
    return info


def get_service_data(settings=None):
    if settings is None:
        settings = load_settings()
    svc_map = (settings or {}).get("services", {}) if isinstance(settings, dict) else {}

    services = []
    for name, unit, port, cat, desc, web_path, configs in SERVICES:
        ov = svc_map.get(unit, {}) if isinstance(svc_map, dict) else {}
        eff_port = ov.get("port", port)
        eff_web_path = ov.get("web_path", web_path)
        eff_configs = ov.get("config_files") or _suggest_configs(unit, list(configs or []))
        eff_data_paths = ov.get("data_paths", [])
        rt = ov.get("runtime", "systemd")
        dc = ov.get("docker_container")

        status = get_service_status(unit, runtime=rt, docker_container=dc)
        mem = get_service_memory(unit, runtime=rt, docker_container=dc)
        cpu = get_service_cpu(unit, runtime=rt)

        svc = {
            "name": name, "unit": unit, "port": eff_port, "category": cat,
            "description": desc, "status": status,
            "memory_mb": round(mem, 1) if mem else None,
            "cpu_pct": round(cpu, 1) if cpu else None,
            "web_path": eff_web_path, "config_files": eff_configs,
            "data_paths": eff_data_paths, "runtime": rt,
            "docker_container": dc, "is_builtin": True, "icon": "",
        }
        if unit == "kiwix" and isinstance(ov, dict):
            svc["kiwix_zim_dir"] = ov.get("kiwix_zim_dir")
            svc["kiwix_library_xml"] = ov.get("kiwix_library_xml")
        services.append(svc)

    # Custom / add-server services
    for cs in settings.get("custom_services", []):
        if not isinstance(cs, dict):
            continue
        unit = cs.get("unit", cs.get("id", ""))
        rt = cs.get("runtime", "external")
        host = cs.get("host", "localhost")
        port = cs.get("port")
        container = cs.get("docker_container")
        status = get_service_status(unit, runtime=rt, host=host, port=port, docker_container=container)
        mem = get_service_memory(unit, runtime=rt, docker_container=container)
        cpu = get_service_cpu(unit, runtime=rt)
        services.append({
            "name": cs.get("name", unit), "unit": unit, "port": port,
            "category": cs.get("category", "home"), "description": cs.get("description", ""),
            "status": status,
            "memory_mb": round(mem, 1) if mem else None,
            "cpu_pct": round(cpu, 1) if cpu else None,
            "web_path": cs.get("web_path", ""),
            "config_files": cs.get("config_files", []),
            "data_paths": cs.get("data_paths", []),
            "runtime": rt, "host": host, "docker_container": container,
            "icon": cs.get("icon", ""),
            "custom_id": cs.get("id", ""), "is_builtin": False,
        })

    return services


def is_path_allowed(filepath):
    filepath = os.path.realpath(filepath)
    return any(filepath.startswith(p) for p in ALLOWED_EDIT_PATHS)


def read_config_file(filepath):
    filepath = os.path.realpath(filepath)
    if not is_path_allowed(filepath):
        return None, "Path not allowed"
    if not os.path.isfile(filepath):
        return None, "File not found"
    try:
        with open(filepath, 'r') as f:
            return f.read(), None
    except PermissionError:
        out, rc = run_cmd(f"sudo cat '{filepath}'")
        if rc == 0:
            return out, None
        return None, "Permission denied"


def write_config_file(filepath, content):
    filepath = os.path.realpath(filepath)
    if not is_path_allowed(filepath):
        return False, "Path not allowed"
    run_cmd(f"sudo cp '{filepath}' '{filepath}.bak.$(date +%Y%m%d%H%M%S)' 2>/dev/null")
    try:
        with open(filepath, 'w') as f:
            f.write(content)
        return True, "Saved"
    except PermissionError:
        import tempfile
        tmp = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.tmp')
        tmp.write(content)
        tmp.close()
        _, rc = run_cmd(f"sudo cp '{tmp.name}' '{filepath}'")
        os.unlink(tmp.name)
        if rc == 0:
            return True, "Saved (via sudo)"
        return False, "Permission denied"


def service_control(unit, action, runtime="systemd", host="localhost", docker_container=None):
    if action not in ('start', 'stop', 'restart'):
        return False, "Invalid action"

    # Safety: protect dashboard from accidental stop
    try:
        s = load_settings()
        dash = (s or {}).get("dashboard", {}) if isinstance(s, dict) else {}
        if action == "stop" and unit == "pi-dashboard" and bool(dash.get("protect_dashboard_service", True)):
            return False, "Stop is disabled for Pi Dashboard (Settings)"
    except Exception:
        pass

    if runtime == "systemd":
        valid_units = set(s[1] for s in SERVICES)
        valid_units |= {c.get("unit", "") for c in load_settings().get("custom_services", []) if c.get("runtime") == "systemd"}
        if unit not in valid_units:
            return False, "Unknown service"
        out, rc = run_cmd(f"sudo systemctl {action} {unit}", timeout=15)
        return (rc == 0), (out or (f"{action}ed {unit}" if rc == 0 else f"Failed to {action} {unit}"))

    elif runtime == "docker":
        cname = docker_container or unit
        out, rc = run_cmd(f"docker {action} {cname}", timeout=30)
        return (rc == 0), (out or (f"docker {action} {cname}" if rc == 0 else f"Docker {action} failed: {cname}"))

    elif runtime in ("windows", "external", "remote"):
        return False, f"Manual control required for {runtime} service"

    return False, f"Unknown runtime: {runtime}"


def browse_directory(path, show_files=True):
    """List contents of a directory for the file browser."""
    try:
        path = os.path.realpath(path)
        if not os.path.isdir(path):
            return None, "Not a directory"
        
        items = []
        # Add parent directory option
        parent = os.path.dirname(path)
        if parent and parent != path:
            items.append({"name": "..", "path": parent, "type": "dir"})
        
        for name in sorted(os.listdir(path)):
            if name.startswith('.'):
                continue
            full_path = os.path.join(path, name)
            try:
                if os.path.isdir(full_path):
                    items.append({"name": name + "/", "path": full_path, "type": "dir"})
                elif show_files and os.path.isfile(full_path):
                    # Only show config-like files
                    ext = name.lower().split('.')[-1] if '.' in name else ''
                    if ext in ('conf', 'ini', 'toml', 'xml', 'yaml', 'yml', 'json', 'cfg', 'config', 'py', 'sh', 'service'):
                        items.append({"name": name, "path": full_path, "type": "file"})
            except PermissionError:
                continue
        
        return {"path": path, "items": items}, None
    except Exception as e:
        return None, str(e)


def refresh_kiwix_library():
    """Rebuild Kiwix library.xml from the dashboard settings and restart Kiwix."""
    s = load_settings()
    svc = (s.get("services", {}) or {}).get("kiwix", {})
    zim_dir = str(svc.get("kiwix_zim_dir", "/opt/appdata/kiwix/data/zims")).strip()
    lib_xml = str(svc.get("kiwix_library_xml", "/opt/appdata/kiwix/data/library.xml")).strip()

    if not zim_dir.startswith("/") or not lib_xml.startswith("/"):
        return False, "Kiwix paths must be absolute in Settings", ""

    try:
        os.makedirs(zim_dir, exist_ok=True)
        os.makedirs(os.path.dirname(lib_xml), exist_ok=True)
    except Exception as e:
        return False, f"Unable to create directories: {e}", ""

    zims = []
    try:
        for fn in sorted(os.listdir(zim_dir)):
            low = fn.lower()
            if low.endswith(".zim") or low.endswith(".zimaa"):
                p = os.path.join(zim_dir, fn)
                if os.path.isfile(p):
                    zims.append(p)
    except Exception as e:
        return False, f"Unable to scan ZIM directory: {e}", ""

    if not zims:
        return False, f"No ZIM files found in {zim_dir}", ""

    if shutil.which("kiwix-manage") is None:
        script = "/usr/local/bin/kiwix-refresh-library.sh"
        if os.path.exists(script):
            out, rc = run_cmd(f"sudo {script}", timeout=180)
            if rc == 0:
                return True, "Kiwix library refreshed (script)", out or ""
            return False, "Kiwix refresh failed (script)", out or ""
        return False, "kiwix-manage not found and helper script missing", ""

    try:
        if os.path.exists(lib_xml):
            os.remove(lib_xml)
    except Exception:
        pass

    details = []
    for f in zims:
        p = subprocess.run(
            ["kiwix-manage", lib_xml, "add", f],
            capture_output=True, text=True
        )
        if p.returncode != 0:
            err = (p.stderr or p.stdout or "").strip()
            return False, f"kiwix-manage failed adding {os.path.basename(f)}", err
        details.append(f"Added: {os.path.basename(f)}")

    out, rc = run_cmd("systemctl restart kiwix 2>/dev/null || systemctl restart kiwix-serve 2>/dev/null || true", timeout=20)
    msg = f"Kiwix library refreshed · {len(zims)} file(s)"
    return True, msg, "\n".join(details) + ("\n" + out if out else "")



def read_app_version():
    """Read version.json next to this script (best-effort)."""
    try:
        here = os.path.dirname(os.path.realpath(__file__))
        vp = os.path.join(here, "version.json")
        if os.path.isfile(vp):
            with open(vp, "r", encoding="utf-8") as f:
                v = json.load(f)
            if isinstance(v, dict):
                return {
                    "version": str(v.get("version", "")).strip(),
                    "release_date": str(v.get("release_date", "")).strip(),
                    "codename": str(v.get("codename", "")).strip(),
                }
    except Exception:
        pass
    return {"version": "", "release_date": "", "codename": ""}


def build_api_response():
    s = load_settings()
    return json.dumps({
        "app": read_app_version(),
        "system": get_system_info(),
        "services": get_service_data(s),
        "categories": CATEGORY_META,
        "settings": s,
        "system_configs": SYSTEM_CONFIG_FILES,
        "timestamp": datetime.now().isoformat(),
    })


# ─────────────────────────────────────────────
# HTML
# ─────────────────────────────────────────────
HTML_PAGE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SidscriPi Dashboard</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
  --bg: #0a0c10; --bg-card: #12151c; --bg-card-hover: #181c25;
  --bg-overlay: rgba(10,12,16,0.85); --bg-panel: #0f1118;
  --border: #1e2330; --border-glow: #2a3040;
  --text: #e2e8f0; --text2: #7a8599; --text3: #4a5568;
  --green: #22c55e; --green-d: rgba(34,197,94,0.12);
  --red: #ef4444; --red-d: rgba(239,68,68,0.12);
  --amber: #f59e0b; --amber-d: rgba(245,158,11,0.12);
  --blue: #3b82f6; --blue-d: rgba(59,130,246,0.12);
  --purple: #a855f7; --purple-d: rgba(168,85,247,0.12);
  --cyan: #06b6d4; --cyan-d: rgba(6,182,212,0.12);
  --font: 'Outfit', sans-serif; --mono: 'JetBrains Mono', monospace;
  --radius: 10px;
}
* { margin:0; padding:0; box-sizing:border-box; }
body { background:var(--bg); color:var(--text); font-family:var(--font); min-height:100vh; }
body.modal-open { overflow:hidden; }
body::before { content:''; position:fixed; inset:0; background-image:
  linear-gradient(rgba(30,35,48,0.3) 1px,transparent 1px),
  linear-gradient(90deg,rgba(30,35,48,0.3) 1px,transparent 1px);
  background-size:60px 60px; z-index:0; pointer-events:none; }
.container { position:relative; z-index:1; max-width:1440px; margin:0 auto; padding:20px 24px; }

/* Header */
.header { display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; padding-bottom:16px; border-bottom:1px solid var(--border); }
.header-left { display:flex; align-items:center; gap:14px; }
.logo { width:42px; height:42px; border-radius:12px; background:linear-gradient(135deg,var(--blue),var(--purple));
  display:flex; align-items:center; justify-content:center; font-size:22px; font-weight:700; color:white;
  box-shadow:0 4px 20px rgba(59,130,246,0.25); }
.header h1 { font-size:21px; font-weight:700; letter-spacing:-0.5px; }
.header h1 span { color:var(--blue); }
.appver { font-family:var(--mono); font-size:12px; color:var(--text2); font-weight:600; margin-left:8px; }
.header-right { display:flex; align-items:center; gap:16px; font-family:var(--mono); font-size:12px; color:var(--text2); }
.pulse-dot { width:8px; height:8px; border-radius:50%; background:var(--green); animation:pulse 2s ease-in-out infinite; display:inline-block; margin-right:5px; }
@keyframes pulse { 0%,100%{opacity:1;box-shadow:0 0 0 0 rgba(34,197,94,0.4)} 50%{opacity:0.7;box-shadow:0 0 0 6px rgba(34,197,94,0)} }

/* Nav Tabs */
.nav { display:flex; gap:4px; margin-bottom:20px; background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:4px; width:fit-content; }
.nav-btn { padding:8px 18px; border-radius:8px; border:none; background:transparent; color:var(--text2);
  font-family:var(--font); font-size:13px; font-weight:600; cursor:pointer; transition:all 0.2s; }
.nav-btn:hover { color:var(--text); background:var(--bg-card-hover); }
.nav-btn.active { background:var(--blue-d); color:var(--blue); }
.tab-content { display:none; }
.tab-content.active { display:block; }

/* System Bar */
.sys-bar { display:grid; grid-template-columns:repeat(auto-fit,minmax(195px,1fr)); gap:10px; margin-bottom:24px; }
.sys-card { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:14px 16px; transition:border-color 0.2s; }
.sys-card:hover { border-color:var(--border-glow); }
.sys-lbl { font-size:10px; text-transform:uppercase; letter-spacing:1px; color:var(--text3); font-weight:600; margin-bottom:4px; font-family:var(--mono); }
.sys-val { font-size:19px; font-weight:700; letter-spacing:-0.5px; }
.sys-sub { font-size:10px; color:var(--text2); margin-top:3px; font-family:var(--mono); }
.pbar { height:4px; background:var(--border); border-radius:2px; margin-top:6px; overflow:hidden; }
.pfill { height:100%; border-radius:2px; transition:width 0.6s; }
.fg { background:var(--green); } .fa { background:var(--amber); } .fr { background:var(--red); }

/* Category */
.category { margin-bottom:20px; }
.cat-hdr { display:flex; align-items:center; gap:10px; margin-bottom:10px; padding-left:2px; }
.cat-icon { font-size:15px; }
.cat-title { font-size:13px; font-weight:600; text-transform:uppercase; letter-spacing:1.5px; color:var(--text2); }
.cat-count { font-family:var(--mono); font-size:10px; color:var(--text3); background:var(--bg-card); padding:2px 7px; border-radius:10px; border:1px solid var(--border); }

/* Service Row */
.sgrid { display:grid; grid-template-columns:repeat(auto-fill,minmax(340px,1fr)); gap:8px; }
.svc { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:12px 14px;
  display:flex; align-items:center; gap:10px; transition:all 0.15s; position:relative; overflow:hidden; }
.svc::before { content:''; position:absolute; left:0; top:0; bottom:0; width:3px; border-radius:3px 0 0 3px; }
.svc.on::before { background:var(--green); } .svc.off::before { background:var(--red); } .svc.unk::before { background:var(--amber); }
.svc:hover { border-color:var(--border-glow); background:var(--bg-card-hover); }
.sdot { width:8px; height:8px; border-radius:50%; flex-shrink:0; }
.svc.on .sdot { background:var(--green); box-shadow:0 0 8px rgba(34,197,94,0.5); }
.svc.off .sdot { background:var(--red); box-shadow:0 0 8px rgba(239,68,68,0.5); }
.svc.unk .sdot { background:var(--amber); }
.sinfo { flex:1; min-width:0; }
.sname { font-size:13px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sdesc { font-size:10px; color:var(--text2); margin-top:1px; }
.smeta { display:flex; align-items:center; gap:6px; flex-shrink:0; font-family:var(--mono); font-size:10px; }
.sport { color:var(--cyan); background:var(--cyan-d); padding:2px 7px; border-radius:6px; font-weight:500; }
.sport a { color:var(--cyan); text-decoration:none; } .sport a:hover { text-decoration:underline; }
.smem { color:var(--purple); } .scpu { color:var(--amber); }

/* Control Buttons */
.sctrl { display:flex; gap:3px; flex-shrink:0; }
.cbtn { width:26px; height:26px; border-radius:6px; border:1px solid var(--border); background:var(--bg-card);
  color:var(--text2); cursor:pointer; display:flex; align-items:center; justify-content:center;
  font-size:12px; transition:all 0.15s; }
.cbtn:hover { border-color:var(--border-glow); background:var(--bg-card-hover); }
.cbtn.start:hover { color:var(--green); border-color:var(--green); background:var(--green-d); }
.cbtn.stop:hover { color:var(--red); border-color:var(--red); background:var(--red-d); }
.cbtn.restart:hover { color:var(--amber); border-color:var(--amber); background:var(--amber-d); }
.cbtn.view:hover { color:var(--blue); border-color:var(--blue); background:var(--blue-d); }
.cbtn.edit:hover { color:var(--purple); border-color:var(--purple); background:var(--purple-d); }
.cbtn.kiwix:hover { color:var(--cyan); border-color:var(--cyan); background:var(--cyan-d); }
.cbtn.del:hover { color:var(--red); border-color:var(--red); background:var(--red-d); }
.cbtn.spinning svg { animation: spin 1s linear infinite; }
.sbadge { display:inline-block; font-size:9px; font-weight:700; text-transform:uppercase; letter-spacing:.05em; padding:1px 5px; border-radius:3px; }
.sbadge-docker { background:rgba(30,130,230,0.18); color:#60a5fa; border:1px solid rgba(60,130,230,0.25); }
.sbadge-windows { background:rgba(0,180,100,0.12); color:#4ade80; border:1px solid rgba(0,180,100,0.2); }
.sbadge-external { background:rgba(168,85,247,0.12); color:#c084fc; border:1px solid rgba(168,85,247,0.2); }
@keyframes spin { to { transform: rotate(360deg); } }

/* Viewer Panel */
.viewer-overlay { display:none; position:fixed; inset:0; background:var(--bg-overlay); z-index:100; backdrop-filter:blur(4px); }
.viewer-overlay.open { display:flex; align-items:stretch; justify-content:center; padding:20px; }
.viewer-panel { background:var(--bg-panel); border:1px solid var(--border); border-radius:14px; width:100%; max-width:1300px;
  display:flex; flex-direction:column; overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,0.5);
  height:100%; max-height:calc(100vh - 40px); min-height:0; }
.viewer-bar { display:flex; align-items:center; justify-content:space-between; padding:12px 18px; border-bottom:1px solid var(--border);
  background:var(--bg-card); flex-shrink:0; }
.viewer-title { font-weight:600; font-size:15px; }
.viewer-url { font-family:var(--mono); font-size:11px; color:var(--text2); background:var(--bg); padding:4px 10px;
  border-radius:6px; border:1px solid var(--border); margin:0 12px; flex:1; text-align:center; }
.viewer-close { width:32px; height:32px; border-radius:8px; border:1px solid var(--border); background:var(--bg-card);
  color:var(--text2); cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:16px; transition:all 0.15s; }
.viewer-close:hover { color:var(--red); border-color:var(--red); background:var(--red-d); }
.viewer-frame { flex:1; border:none; background:#000; width:100%; min-height:0; }

/* Editor Panel */
.editor-overlay { display:none; position:fixed; inset:0; background:var(--bg-overlay); z-index:100; backdrop-filter:blur(4px); }
.editor-overlay.open { display:flex; align-items:stretch; justify-content:center; padding:20px; }
.editor-panel { background:var(--bg-panel); border:1px solid var(--border); border-radius:14px; width:100%; max-width:900px;
  display:flex; flex-direction:column; overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,0.5);
  height:100%; max-height:calc(100vh - 40px); min-height:0; }
.editor-bar { display:flex; align-items:center; justify-content:space-between; padding:12px 18px; border-bottom:1px solid var(--border);
  background:var(--bg-card); flex-shrink:0; gap:8px; }
.editor-title { font-weight:600; font-size:14px; flex-shrink:0; }
.editor-path { font-family:var(--mono); font-size:11px; color:var(--cyan); flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.editor-btns { display:flex; gap:6px; flex-shrink:0; }
.ebtn { padding:6px 14px; border-radius:8px; border:1px solid var(--border); background:var(--bg-card);
  color:var(--text2); cursor:pointer; font-family:var(--font); font-size:12px; font-weight:600; transition:all 0.15s; }
.ebtn:hover { border-color:var(--border-glow); }
.ebtn.save { color:var(--green); } .ebtn.save:hover { border-color:var(--green); background:var(--green-d); }
.ebtn.close { color:var(--text2); } .ebtn.close:hover { color:var(--red); border-color:var(--red); background:var(--red-d); }
.ebtn.back { color:var(--blue); } .ebtn.back:hover { border-color:var(--blue); background:var(--blue-d); }
.editor-select { display:flex; gap:4px; padding:8px 18px; border-bottom:1px solid var(--border); background:var(--bg); flex-wrap:wrap; align-items:center; }
.file-tab { padding:4px 10px; border-radius:6px; border:1px solid var(--border); background:var(--bg-card); color:var(--text2);
  font-family:var(--mono); font-size:11px; cursor:pointer; transition:all 0.15s; }
.file-tab:hover { border-color:var(--border-glow); color:var(--text); }
.file-tab.active { border-color:var(--cyan); color:var(--cyan); background:var(--cyan-d); }
.file-tab.browse { border-color:var(--purple); color:var(--purple); }
.file-tab.browse:hover { background:var(--purple-d); }
.editor-area { flex:1; display:flex; }
.editor-area textarea { flex:1; background:var(--bg); color:var(--text); border:none; padding:16px 20px;
  font-family:var(--mono); font-size:12px; line-height:1.6; resize:none; outline:none; tab-size:4; }
.editor-status { padding:8px 18px; border-top:1px solid var(--border); font-family:var(--mono); font-size:11px; color:var(--text3);
  display:flex; justify-content:space-between; background:var(--bg-card); }
.editor-status .saved { color:var(--green); }
.editor-status .error { color:var(--red); }

/* File Browser */
.browser-overlay { display:none; position:fixed; inset:0; background:var(--bg-overlay); z-index:150; backdrop-filter:blur(4px); }
.browser-overlay.open { display:flex; align-items:center; justify-content:center; padding:20px; }
.browser-panel { background:var(--bg-panel); border:1px solid var(--border); border-radius:14px; width:100%; max-width:600px;
  max-height:calc(100vh - 40px); display:flex; flex-direction:column; overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,0.5); min-height:0; }
.browser-bar { display:flex; align-items:center; justify-content:space-between; padding:12px 18px; border-bottom:1px solid var(--border);
  background:var(--bg-card); flex-shrink:0; }
.browser-title { font-weight:600; font-size:14px; }
.browser-path { font-family:var(--mono); font-size:11px; color:var(--cyan); padding:8px 18px; border-bottom:1px solid var(--border); 
  background:var(--bg); word-break:break-all; }
.browser-list { flex:1; overflow-y:auto; padding:8px; }
.browser-item { padding:8px 12px; border-radius:6px; cursor:pointer; display:flex; align-items:center; gap:8px;
  font-family:var(--mono); font-size:12px; transition:all 0.15s; }
.browser-item:hover { background:var(--bg-card-hover); }
.browser-item.dir { color:var(--blue); }
.browser-item.file { color:var(--text); }
.browser-item.file:hover { background:var(--cyan-d); color:var(--cyan); }
.fsize { margin-left:auto; font-size:11px; color:var(--text3); }
.file-group-label { display:inline-block; font-size:10px; font-weight:700; text-transform:uppercase;
  letter-spacing:.08em; color:var(--text3); padding:0 4px; margin-right:2px; }
.file-tab.system { border-color:var(--amber); color:var(--amber); }
.file-tab.system:hover { background:var(--amber-d); }
/* ── Wizard ── */
.wizard-overlay { position:fixed; inset:0; background:rgba(0,0,0,.65); z-index:300; display:none; align-items:flex-start; justify-content:center; padding-top:60px; }
.wizard-overlay.open { display:flex; }
.wizard-panel { background:var(--bg-panel); border:1px solid var(--border); border-radius:var(--radius); width:min(720px,95vw); max-height:80vh; display:flex; flex-direction:column; overflow:hidden; }
.wizard-bar { display:flex; align-items:center; justify-content:space-between; padding:14px 20px 12px; border-bottom:1px solid var(--border); }
.wizard-bar h3 { font-size:14px; font-weight:700; }
.wizard-body { padding:20px; overflow-y:auto; flex:1; }
.wizard-footer { padding:12px 20px; border-top:1px solid var(--border); display:flex; gap:10px; justify-content:flex-end; }
.ebtn.primary { color:var(--cyan); border-color:var(--cyan); background:var(--cyan-d); }
.ebtn.primary:hover { filter:brightness(1.2); }
/* ── Scan results ── */
.scan-section { margin-bottom:20px; }
.scan-section-title { font-size:12px; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:var(--text3); margin-bottom:8px; display:flex; align-items:center; gap:8px; }
.scan-item { display:flex; align-items:center; gap:10px; padding:10px 12px; border:1px solid var(--border); border-radius:8px; margin-bottom:4px; cursor:pointer; transition:all .15s; }
.scan-item:hover { border-color:var(--border-glow); background:var(--bg-card-hover); }
.scan-item.selected { border-color:var(--cyan); background:var(--cyan-d); }
.scan-item-check { width:18px; height:18px; border:1.5px solid var(--border); border-radius:4px; display:flex; align-items:center; justify-content:center; font-size:10px; color:transparent; flex-shrink:0; }
.scan-item.selected .scan-item-check { border-color:var(--cyan); color:var(--cyan); }
.scan-item-info { flex:1; }
.scan-item-name { font-size:13px; font-weight:600; }
.scan-item-sub { font-size:11px; color:var(--text2); margin-top:2px; }
.scan-item-badge { font-size:10px; font-weight:700; padding:2px 6px; border-radius:4px; }
.scan-badge-docker { background:rgba(30,130,230,0.15); color:#60a5fa; }
.scan-badge-port   { background:rgba(168,85,247,0.15); color:#c084fc; }
.scan-badge-systemd{ background:rgba(34,197,94,0.12); color:var(--green); }
.scan-empty { padding:30px; text-align:center; color:var(--text2); font-size:13px; }
/* ── Manual wizard tabs ── */
.wtabs { display:flex; gap:4px; margin-bottom:16px; border-bottom:1px solid var(--border); padding-bottom:10px; }
.wtab { padding:5px 12px; border-radius:6px; border:1px solid transparent; font-size:12px; font-weight:600; color:var(--text2); cursor:pointer; background:none; }
.wtab:hover { color:var(--text); border-color:var(--border); }
.wtab.active { color:var(--cyan); border-color:var(--cyan); background:var(--cyan-d); }
.runtime-instructions { font-size:12px; color:var(--text2); line-height:1.7; padding:10px 14px; border-left:2px solid var(--cyan); background:rgba(6,182,212,0.05); border-radius:0 6px 6px 0; margin-bottom:16px; }
.runtime-instructions b { color:var(--text); }
.runtime-instructions code { background:var(--bg); border:1px solid var(--border); border-radius:3px; padding:0 4px; font-family:var(--mono); font-size:11px; color:var(--cyan); }
/* ── Form helpers ── */
.form-row { margin-bottom:12px; }
.form-row label { display:block; font-size:11px; font-weight:600; color:var(--text2); text-transform:uppercase; letter-spacing:.06em; margin-bottom:4px; }
.form-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:0; }
.form-row-3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px; margin-bottom:0; }
.finput { width:100%; background:var(--bg); border:1px solid var(--border); border-radius:6px; color:var(--text); padding:6px 10px; font-size:12px; font-family:var(--mono); box-sizing:border-box; }
.finput:focus { outline:none; border-color:var(--cyan); }
.finput-select { width:100%; background:var(--bg); border:1px solid var(--border); border-radius:6px; color:var(--text); padding:6px 10px; font-size:12px; box-sizing:border-box; }
.finput-select:focus { outline:none; border-color:var(--cyan); }
.form-hint { font-size:10px; color:var(--text3); margin-top:4px; }
.form-hint code { color:var(--cyan); }
/* ── Custom server list ── */
.custom-svc-row { display:flex; align-items:center; gap:8px; padding:8px 10px; border:1px solid var(--border); border-radius:6px; margin-bottom:4px; }
.csname { font-size:13px; font-weight:600; flex:1; }
.csmeta { font-size:11px; color:var(--text2); font-family:var(--mono); }
.browser-actions { display:flex; gap:8px; padding:12px 18px; border-top:1px solid var(--border); background:var(--bg-card); }
.browser-input { flex:1; padding:8px 12px; border-radius:6px; border:1px solid var(--border); background:var(--bg);
  color:var(--text); font-family:var(--mono); font-size:12px; }

/* Toast */
.toast { position:fixed; bottom:24px; right:24px; z-index:200; display:flex; flex-direction:column; gap:6px; }
.toast-msg { padding:10px 16px; border-radius:8px; font-size:13px; font-weight:500; animation:slideIn 0.3s ease;
  border:1px solid var(--border); background:var(--bg-card); color:var(--text); box-shadow:0 8px 30px rgba(0,0,0,0.3); }
.toast-msg.ok { border-color:var(--green); color:var(--green); }
.toast-msg.err { border-color:var(--red); color:var(--red); }
@keyframes slideIn { from{transform:translateX(30px);opacity:0} to{transform:translateX(0);opacity:1} }

/* Footer */
.footer { margin-top:24px; padding-top:14px; border-top:1px solid var(--border); display:flex; justify-content:space-between;
  font-family:var(--mono); font-size:11px; color:var(--text3); }

/* Journal Tab */
.journal-wrap { display:flex; gap:12px; }
.journal-list { width:220px; flex-shrink:0; display:flex; flex-direction:column; gap:4px; max-height:70vh; overflow-y:auto; }
.jbtn { padding:8px 12px; border-radius:8px; border:1px solid var(--border); background:var(--bg-card); color:var(--text2);
  font-size:12px; cursor:pointer; text-align:left; transition:all 0.15s; font-family:var(--font); }
.jbtn:hover { border-color:var(--border-glow); color:var(--text); }
.jbtn.active { border-color:var(--blue); color:var(--blue); background:var(--blue-d); }
.journal-output { flex:1; background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius);
  padding:14px; font-family:var(--mono); font-size:11px; line-height:1.5; color:var(--text2);
  max-height:70vh; overflow-y:auto; white-space:pre-wrap; word-break:break-all; }

@media (max-width:768px) {
  .container { padding:14px; }
  .sys-bar { grid-template-columns:repeat(2,1fr); }
  .sgrid { grid-template-columns:1fr; }
  .header { flex-direction:column; align-items:flex-start; gap:10px; }
  .journal-wrap { flex-direction:column; }
  .journal-list { width:100%; max-height:200px; flex-direction:row; flex-wrap:wrap; }
  /* Modal panels on small screens */
  .viewer-overlay.open, .editor-overlay.open, .browser-overlay.open { padding:8px; }
  .viewer-panel, .editor-panel, .browser-panel { max-height:calc(100vh - 16px); width:100%; max-width:100%; border-radius:12px; }
  .viewer-bar { flex-wrap:wrap; gap:8px; }
  .viewer-url { flex-basis:100%; margin:0; order:3; }

}

/* Settings */
.settings-wrap { display:flex; gap:16px; flex-wrap:wrap; margin-top:8px; }
.settings-card { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius);
  padding:16px; min-width:320px; flex:1; }
.settings-title { font-weight:800; letter-spacing:0.2px; margin-bottom:10px; }
.settings-row { margin-bottom:12px; }
.settings-row label { display:block; font-size:12px; color:var(--text2); margin-bottom:6px; }
.settings-input { width:100%; padding:10px 12px; border-radius:10px; border:1px solid var(--border);
  background:var(--bg-panel); color:var(--text); font-family:var(--mono); font-size:12px; outline:none; }
.settings-input:focus { border-color:var(--border-glow); }
.settings-textarea { width:100%; padding:10px 12px; border-radius:10px; border:1px solid var(--border);
  background:var(--bg-panel); color:var(--text); font-family:var(--mono); font-size:12px; outline:none;
  min-height:96px; resize:vertical; }
.settings-textarea:focus { border-color:var(--border-glow); }
.settings-hint { font-size:12px; color:var(--text2); line-height:1.35; }
.settings-actions { display:flex; gap:10px; margin-top:10px; }

</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="header-left"><div class="logo">π</div><h1>Sidscri<span>Pi</span> <span id="appver" class="appver"></span></h1></div>
    <div class="header-right"><span><span class="pulse-dot"></span>LIVE</span><span id="clock"></span><span id="rtimer">30s</span></div>
  </div>
  <div class="nav">
    <button class="nav-btn active" data-tab="dashboard" onclick="switchTab('dashboard', this)">Dashboard</button>
    <button class="nav-btn" data-tab="logs" onclick="switchTab('logs', this)">Logs</button>
    <button class="nav-btn" data-tab="settings" onclick="switchTab('settings', this)">Settings</button>
  </div>

  <div id="tab-dashboard" class="tab-content active">
    <div class="sys-bar" id="sys-bar"></div>
    <div id="svc-container"></div>
  </div>

  <div id="tab-logs" class="tab-content">
    <div class="journal-wrap">
      <div class="journal-list" id="jlist"></div>
      <pre class="journal-output" id="jout">Select a service to view its logs.</pre>
    </div>
  </div>

  <div id="tab-settings" class="tab-content">
    <div class="settings-wrap">

      <div class="settings-card">
        <div class="settings-title">Dashboard Viewer</div>

        <div class="settings-row">
          <label for="set_viewer_scheme">Viewer scheme</label>
          <select id="set_viewer_scheme" class="settings-input">
            <option value="http">http</option>
            <option value="https">https</option>
          </select>
          <div class="settings-hint">Used only to build links in the dashboard viewer.</div>
        </div>

        <div class="settings-row">
          <label for="set_viewer_host">Viewer host</label>
          <input id="set_viewer_host" class="settings-input" spellcheck="false" />
          <div class="settings-hint">Use <code>auto</code> to follow the dashboard address (recommended). Set a hostname/IP only if the service UI is hosted elsewhere.</div>
        </div>

        <div class="settings-actions">
          <button class="ebtn" onclick="loadSettings()">Reload</button>
          <button class="ebtn" onclick="saveAllSettings()">Save</button>
          <button class="ebtn" onclick="autoDetectAll()">Auto-detect all</button>
        </div>
        <div class="settings-hint" style="margin-top:10px;">
          These settings are <b>dashboard-only mappings</b>. They do not change how the underlying services are configured.
        </div>
      </div>


      <div class="settings-card">
        <div class="settings-title">Dashboard Filters & Safety</div>

        <div class="settings-row">
          <label>Display</label>
          <div style="display:flex;flex-direction:column;gap:8px;">
            <label style="display:flex;align-items:center;gap:8px;font-size:12px;color:var(--text2);">
              <input type="checkbox" id="set_hide_stopped" />
              Hide stopped services on the Dashboard
            </label>

            <label style="display:flex;align-items:center;gap:8px;font-size:12px;color:var(--text2);">
              <input type="checkbox" id="set_protect_dashboard" />
              Protect Pi Dashboard service (always block Stop for <code>pi-dashboard</code>)
            </label>
          </div>
        </div>

        <div class="settings-row">
          <label for="set_hidden_units">Hidden services (unit names, one per line)</label>
          <textarea id="set_hidden_units" class="settings-textarea" spellcheck="false" placeholder="e.g. deluge-web&#10;prowlarr"></textarea>
          <div class="settings-hint">These services will be hidden from the Dashboard list. They still appear in Settings.</div>
        </div>

        <div class="settings-row">
          <label for="set_hidden_pick">Pick services to hide (multi-select)</label>
          <select id="set_hidden_pick" class="settings-input" multiple style="height:220px;"></select>
          <div class="settings-actions">
            <button class="ebtn" onclick="hiddenPickSyncToText()">Sync → Text</button>
            <button class="ebtn close" onclick="hiddenPickClear()">Clear</button>
          </div>
          <div class="settings-hint">Tip: select multiple items (long-press / Ctrl/Shift depending on device) then click Sync.</div>
        </div>

        <div class="settings-actions">
          <button class="ebtn" onclick="saveAllSettings()">Save</button>
        </div>
      </div>

      <div class="settings-card">
        <div class="settings-title">Service Mappings</div>

        <div class="settings-row">
          <label for="svc_pick">Select service</label>
          <select id="svc_pick" class="settings-input" onchange="onPickService()"></select>
          <div class="settings-hint">Edit where the dashboard looks for configs/data and how it builds the View URL.</div>
        </div>

        <div class="settings-row">
          <label for="svc_port">Port</label>
          <input id="svc_port" class="settings-input" spellcheck="false" />
        </div>

        <div class="settings-row">
          <label for="svc_runtime">Runtime</label>
          <select id="svc_runtime" class="settings-input" onchange="onPickService(true)">
            <option value="systemd">systemd</option>
            <option value="docker">docker</option>
            <option value="external">external</option>
          </select>
        </div>

        <div class="settings-row" id="svc_container_row" style="display:none">
          <label for="svc_docker_container">Docker container name</label>
          <input id="svc_docker_container" class="settings-input" spellcheck="false" placeholder="container-name" />
        </div>

        <div class="settings-row">
          <label for="svc_web_path">Web path</label>
          <input id="svc_web_path" class="settings-input" spellcheck="false" placeholder="e.g. /web or blank for root" />
          <div class="settings-hint">Blank = root. <code>null</code> (leave empty) disables the View button.</div>
        </div>

        <div class="settings-row">
          <label for="svc_config_files">Config files (one per line)</label>
          <textarea id="svc_config_files" class="settings-textarea" spellcheck="false"></textarea>
          <div class="settings-hint">These are the files shown in the dashboard Config Editor.</div>
        </div>

        <div class="settings-row">
          <label for="svc_data_paths">Data folders (one per line)</label>
          <textarea id="svc_data_paths" class="settings-textarea" spellcheck="false"></textarea>
        </div>

        <div id="kiwix_extra" style="display:none;">
          <div class="settings-row">
            <label for="svc_kiwix_zim_dir">Kiwix ZIM directory</label>
            <input id="svc_kiwix_zim_dir" class="settings-input" spellcheck="false" />
          </div>
          <div class="settings-row">
            <label for="svc_kiwix_library_xml">Kiwix library.xml path</label>
            <input id="svc_kiwix_library_xml" class="settings-input" spellcheck="false" />
          </div>
        </div>

        <div class="settings-actions">
          <button class="ebtn" onclick="autoDetectSelected()">Auto-detect this service</button>
          <button class="ebtn" onclick="saveAllSettings()">Save</button>
        </div>
        <div class="settings-hint" style="margin-top:10px;">
          Tip: If a service is installed differently, click <b>Auto-detect</b> then adjust.
        </div>
      </div>

      <!-- Add Server -->
      <div class="settings-card">
        <div class="settings-title">Add Server to Dashboard <span class="sbadge sbadge-docker" style="margin-left:6px;font-size:10px">NEW</span></div>
        <div class="settings-hint" style="margin-bottom:12px;">Add Docker containers, Windows VMs, remote services, or any extra systemd services not in the built-in list.</div>
        <div class="settings-actions">
          <button class="ebtn primary" onclick="openWizard('scan')">🔍 Scan &amp; Detect</button>
          <button class="ebtn" onclick="openWizard('manual')">✏️ Add Manually</button>
        </div>
      </div>

      <!-- Custom servers list -->
      <div class="settings-card" id="custom-servers-card" style="display:none">
        <div class="settings-title">Custom Servers</div>
        <div id="custom-svc-list"></div>
      </div>

    </div>
  </div>

  <div class="footer">
    <span id="fsum">Loading...</span>
    <span id="fupd">...</span>
  </div>
</div>

<!-- Wizard -->
<div class="wizard-overlay" id="wizard">
  <div class="wizard-panel">
    <div class="wizard-bar">
      <h3 id="wizard-title">Add Server</h3>
      <button class="viewer-close" onclick="closeWizard()">✕</button>
    </div>
    <div class="wizard-body" id="wizard-body"></div>
    <div class="wizard-footer" id="wizard-footer">
      <button class="ebtn close" onclick="closeWizard()">Close</button>
    </div>
  </div>
</div>

<!-- Viewer -->
<div class="viewer-overlay" id="viewer">
  <div class="viewer-panel">
    <div class="viewer-bar">
      <span class="viewer-title" id="vtitle"></span>
      <span class="viewer-url" id="vurl"></span>
      <button class="ebtn back" onclick="backToDashboard()">← Dashboard</button>
      <a id="vext" href="#" target="_blank" class="ebtn" style="text-decoration:none">↗ Open</a>
      <button class="viewer-close" onclick="closeViewer()">✕</button>
    </div>
    <iframe class="viewer-frame" id="vframe"></iframe>
  </div>
</div>

<!-- Editor -->
<div class="editor-overlay" id="editor">
  <div class="editor-panel">
    <div class="editor-bar">
      <span class="editor-title" id="etitle"></span>
      <span class="editor-path" id="epath"></span>
      <div class="editor-btns">
        <button class="ebtn back" onclick="backToDashboard()">← Dashboard</button>
        <button class="ebtn save" onclick="saveFile()">Save</button>
        <button class="ebtn close" onclick="closeEditor()">Close</button>
      </div>
    </div>
    <div class="editor-select" id="efiles"></div>
    <div class="editor-area"><textarea id="etext" spellcheck="false"></textarea></div>
    <div class="editor-status"><span id="estatus"></span><span id="elines"></span></div>
  </div>
</div>

<!-- File Browser -->
<div class="browser-overlay" id="browser">
  <div class="browser-panel">
    <div class="browser-bar">
      <span class="browser-title">Browse for Config File</span>
      <button class="viewer-close" onclick="closeBrowser()">✕</button>
    </div>
    <div class="browser-path" id="bpath">/opt</div>
    <div class="browser-list" id="blist"></div>
    <div class="browser-actions">
      <input type="text" class="browser-input" id="binput" placeholder="Or type full path..." />
      <button class="ebtn" onclick="selectBrowserPath()">Select</button>
      <button class="ebtn close" onclick="closeBrowser()">Cancel</button>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
const IP = location.hostname;
let countdown = 30, DATA = null, currentEditorUnit = null, currentEditorFile = null;
let browserCallback = null, SETTINGS = null, SCAN_RESULTS = null, SCAN_SELECTED = new Set();

function viewerBase(){
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  const scheme = (dash.viewer_scheme || 'http');
  let host = (dash.viewer_host || 'auto');
  if (!host || host === 'auto') host = IP;
  return `${scheme}://${host}`;
}

function buildViewUrl(s){
  const h = (s.host && s.host !== 'localhost') ? s.host : IP;
  const base = (s.runtime === 'external' || s.runtime === 'windows' || s.runtime === 'remote')
    ? `http://${h}` : viewerBase();
  const wp = (s.web_path === null || s.web_path === undefined) ? '' : (s.web_path || '');
  return `${base}:${s.port}${wp}`;
}

function _ll(v){ return (v||'').split(/\r?\n/).map(s=>s.trim()).filter(s=>!!s); }
function _la(a){ return Array.isArray(a) ? a.join('\n') : ''; }

function openViewerUnit(unit){
  try{
    const s = (DATA && DATA.services) ? DATA.services.find(x => x.unit === unit) : null;
    if(!s){ toast('Service data not loaded', false); return; }
    openViewer(s.name, buildViewUrl(s));
  }catch(e){ console.error(e); toast('Failed to open viewer', false); }
}

// SVG icons
const ICO = {
  play: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
  stop: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="6" y="6" width="12" height="12"/></svg>',
  refresh: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>',
  eye: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
  edit: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',
  book: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
  trash: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>',
  folder: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
  file: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>',
};

function toast(msg, ok=true) {
  const d = document.getElementById('toast');
  const el = document.createElement('div');
  el.className = 'toast-msg ' + (ok ? 'ok' : 'err');
  el.textContent = msg;
  d.appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

function fmtB(b) { return b > 1073741824 ? (b/1073741824).toFixed(1)+' GB' : b > 1048576 ? (b/1048576).toFixed(0)+' MB' : (b/1024).toFixed(0)+' KB'; }
function pctCls(p) { return p < 60 ? 'fg' : p < 85 ? 'fa' : 'fr'; }

function switchTab(tab, btn) {
  document.querySelectorAll('.tab-content').forEach(e => e.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(e => e.classList.remove('active'));
  document.getElementById('tab-'+tab).classList.add('active');
  if (btn) btn.classList.add('active');
  if (tab === 'logs') buildLogList();
  if (tab === 'settings') loadSettings();
}

function backToDashboard() {
  closeViewer();
  closeEditor();
  closeBrowser();
  // Activate dashboard tab
  document.querySelectorAll('.tab-content').forEach(e => e.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(e => e.classList.remove('active'));
  document.getElementById('tab-dashboard').classList.add('active');
  document.querySelector('.nav-btn[data-tab="dashboard"]').classList.add('active');
}

function renderSys(s) {
  const el = document.getElementById('sys-bar');
  if (!s || !s.mem_total) {
    el.innerHTML = '<div class="sys-card"><div class="sys-val">Loading system info...</div></div>';
    return;
  }
  const mp = ((s.mem_used/s.mem_total)*100).toFixed(1);
  const dp = ((s.disk_used/(s.disk_used+s.disk_avail))*100).toFixed(1);
  const sp = s.swap_total > 0 ? ((s.swap_used/s.swap_total)*100).toFixed(1) : 0;
  el.innerHTML = `
    <div class="sys-card"><div class="sys-lbl">Host / IP</div><div class="sys-val">${s.hostname}</div><div class="sys-sub">${s.ip}</div></div>
    <div class="sys-card"><div class="sys-lbl">Uptime</div><div class="sys-val">${s.uptime||'—'}</div><div class="sys-sub">${s.os||''}</div></div>
    <div class="sys-card"><div class="sys-lbl">Load</div><div class="sys-val">${s.load||'—'}</div><div class="sys-sub">${s.cpu_temp?s.cpu_temp+'°C':''} ${s.kernel||''}</div></div>
    <div class="sys-card"><div class="sys-lbl">Memory</div><div class="sys-val">${mp}%</div><div class="sys-sub">${fmtB(s.mem_used)} / ${fmtB(s.mem_total)}</div><div class="pbar"><div class="pfill ${pctCls(mp)}" style="width:${mp}%"></div></div></div>
    <div class="sys-card"><div class="sys-lbl">Swap</div><div class="sys-val">${sp}%</div><div class="sys-sub">${fmtB(s.swap_used)} / ${fmtB(s.swap_total)}</div><div class="pbar"><div class="pfill ${pctCls(sp)}" style="width:${sp}%"></div></div></div>
    <div class="sys-card"><div class="sys-lbl">Disk</div><div class="sys-val">${dp}%</div><div class="sys-sub">${fmtB(s.disk_used)} / ${fmtB(s.disk_used+s.disk_avail)}</div><div class="pbar"><div class="pfill ${pctCls(dp)}" style="width:${dp}%"></div></div></div>`;
}

function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function fmtSz(b){ return b>1048576?(b/1048576).toFixed(0)+' MB':b>1024?(b/1024).toFixed(0)+' KB':b+'B'; }

function renderSvc(services, cats) {
  const c = document.getElementById('svc-container');
  if (!services || !services.length) {
    c.innerHTML = '<div class="sys-card"><div class="sys-val">Loading services...</div></div>';
    return;
  }
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  const hideStopped = !!dash.hide_stopped_services;
  const hiddenUnits = Array.isArray(dash.hidden_units) ? dash.hidden_units : [];
  let list = services.filter(s => !hiddenUnits.includes(s.unit));
  if (hideStopped) list = list.filter(s => s.status === 'active' || s.status === 'running');

  const g = {};
  list.forEach(s => { if(!g[s.category]) g[s.category]=[]; g[s.category].push(s); });
  const order = ['media','arr','downloads','tv','home','docker','windows','remote','system'];
  let h = '';
  order.forEach(cat => {
    const items = g[cat]; if(!items) return;
    const m = (cats&&cats[cat])||{label:cat,icon:'📦'};
    const ac = items.filter(s=>s.status==='active'||s.status==='running').length;
    h += `<div class="category"><div class="cat-hdr"><span class="cat-icon">${m.icon}</span><span class="cat-title">${esc(m.label)}</span><span class="cat-count">${ac}/${items.length}</span></div><div class="sgrid">`;
    items.forEach(s => {
      const active = s.status==='active'||s.status==='running';
      const cls = active?'on':s.status==='inactive'||s.status==='exited'?'off':'unk';
      let port = '';
      if (s.port) {
        if (s.web_path !== null && s.web_path !== undefined)
          port = `<span class="sport"><a href="#" onclick="openViewerUnit('${esc(s.unit)}');return false">:${s.port}</a></span>`;
        else port = `<span class="sport">:${s.port}</span>`;
      }
      const mem = s.memory_mb ? `<span class="smem">${s.memory_mb}M</span>` : '';
      const cpu = s.cpu_pct != null ? `<span class="scpu">${s.cpu_pct}%</span>` : '';
      const isDash = (s.unit === 'pi-dashboard');
      const hasView = (!isDash) && s.port && (s.web_path !== null && s.web_path !== undefined);
      const rt = s.runtime || 'systemd';
      const canCtrl = rt==='systemd' || rt==='docker';
      const dc = esc(s.docker_container||'');
      let badge = '';
      if (rt==='docker')   badge = '<span class="sbadge sbadge-docker">docker</span> ';
      else if (rt==='windows') badge = '<span class="sbadge sbadge-windows">win</span> ';
      else if (rt==='external'||rt==='remote') badge = '<span class="sbadge sbadge-external">ext</span> ';
      const icon = s.icon ? esc(s.icon)+' ' : '';

      h += `<div class="svc ${cls}">
        <div class="sdot"></div>
        <div class="sinfo"><div class="sname">${icon}${esc(s.name)}</div><div class="sdesc">${esc(s.description)} · <code>${esc(s.unit)}</code></div></div>
        <div class="smeta">${badge}${cpu}${mem}${port}</div>
        <div class="sctrl">
          ${canCtrl?`<button class="cbtn start" title="Start" onclick="svcCtrl('${esc(s.unit)}','start',this,'${rt}','${dc}')">${ICO.play}</button>`:''}
          ${canCtrl&&!isDash?`<button class="cbtn stop" title="Stop" onclick="svcCtrl('${esc(s.unit)}','stop',this,'${rt}','${dc}')">${ICO.stop}</button>`:''}
          ${canCtrl?`<button class="cbtn restart" title="Restart" onclick="svcCtrl('${esc(s.unit)}','restart',this,'${rt}','${dc}')">${ICO.refresh}</button>`:''}
          ${s.unit==='kiwix'?`<button class="cbtn kiwix" title="Refresh Kiwix Library" onclick="kiwixRefresh(this)">${ICO.book}</button>`:''}
          ${hasView?`<button class="cbtn view" title="Open UI" onclick="openViewerUnit('${esc(s.unit)}')">${ICO.eye}</button>`:''}
          <button class="cbtn edit" title="Edit Config" onclick="openEditor('${esc(s.unit)}')">${ICO.edit}</button>
          ${!s.is_builtin?`<button class="cbtn del" title="Remove" onclick="removeCustomServer('${esc(s.custom_id||s.unit)}')">${ICO.trash}</button>`:''}
        </div>
      </div>`;
    });
    h += '</div></div>';
  });
  c.innerHTML = h || '<div style="padding:20px;color:var(--text2);">No services to display.</div>';
}

async function svcCtrl(unit, action, btn, runtime, container) {
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  if (action === 'stop' && unit === 'pi-dashboard' && dash.protect_dashboard_service !== false) {
    toast('Stop is disabled for Pi Dashboard', false);
    return;
  }
  btn.classList.add('spinning');
  try {
    const r = await fetch('/api/control', { method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({unit, action, runtime: runtime||'systemd', docker_container: container||''}) });
    const d = await r.json();
    toast(d.message, d.ok);
    setTimeout(fetchData, 1500);
  } catch(e) { toast('Request failed', false); }
  btn.classList.remove('spinning');
}

async function kiwixRefresh(btn) {
  btn.classList.add('spinning');
  try {
    const r = await fetch('/api/kiwix/refresh', { method:'POST', headers:{'Content-Type':'application/json'}, body:'{}' });
    const d = await r.json();
    toast(d.message || 'Kiwix refresh complete', d.ok);
    if (d.details) console.log('[Kiwix refresh]\n' + d.details);
    setTimeout(fetchData, 2500);
  } catch(e) {
    toast('Kiwix refresh request failed', false);
  }
  btn.classList.remove('spinning');
}

// Settings (dashboard-only mappings)
let SETTINGS = null;

function _linesToList(v){
  return (v || '')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(s => !!s);
}

function _listToLines(arr){
  return Array.isArray(arr) ? arr.join('\n') : '';
}

function _svcKey(){
  const el = document.getElementById('svc_pick');
  return el ? (el.value || '') : '';
}

function _ensureSettingsShape(){
  if (!SETTINGS || typeof SETTINGS !== 'object') SETTINGS = {};
  if (!SETTINGS.dashboard || typeof SETTINGS.dashboard !== 'object') SETTINGS.dashboard = {};
  if (!SETTINGS.services || typeof SETTINGS.services !== 'object') SETTINGS.services = {};
  if (SETTINGS.dashboard.hide_stopped_services === undefined) SETTINGS.dashboard.hide_stopped_services = false;
  if (SETTINGS.dashboard.protect_dashboard_service === undefined) SETTINGS.dashboard.protect_dashboard_service = true;
  if (!Array.isArray(SETTINGS.dashboard.hidden_units)) SETTINGS.dashboard.hidden_units = [];
}

function populateServicePicker(){
  const pick = document.getElementById('svc_pick');
  if (!pick) return;
  pick.innerHTML = '';
  const svcs = (DATA && DATA.services) ? DATA.services : [];
  for (const s of svcs){
    const opt = document.createElement('option');
    opt.value = s.unit;
    opt.textContent = `${s.name}  (${s.unit})`;
    pick.appendChild(opt);
  }
}


function populateHiddenPicker(){
  const pick = document.getElementById('set_hidden_pick');
  if (!pick) return;
  pick.innerHTML = '';
  const hidden = new Set((SETTINGS && SETTINGS.dashboard && Array.isArray(SETTINGS.dashboard.hidden_units)) ? SETTINGS.dashboard.hidden_units : []);
  const svcs = (DATA && DATA.services) ? DATA.services : [];
  for (const s of svcs){
    const opt = document.createElement('option');
    opt.value = s.unit;
    opt.textContent = `${s.name}  (${s.unit})`;
    if (hidden.has(s.unit)) opt.selected = true;
    pick.appendChild(opt);
  }
}

function hiddenPickSyncToText(){
  const pick = document.getElementById('set_hidden_pick');
  const ta = document.getElementById('set_hidden_units');
  if (!pick || !ta) return;
  const sel = Array.from(pick.selectedOptions || []).map(o => o.value);
  ta.value = sel.join('\n');
  toast('Hidden services synced', true);
}

function hiddenPickClear(){
  const pick = document.getElementById('set_hidden_pick');
  const ta = document.getElementById('set_hidden_units');
  if (pick) Array.from(pick.options).forEach(o => o.selected = false);
  if (ta) ta.value = '';
  toast('Hidden services cleared', true);
}

function onPickService(rtChanged){
  _ensureSettingsShape();
  const unit = _svcKey();
  const entry = (SETTINGS.services && SETTINGS.services[unit]) ? SETTINGS.services[unit] : {};
  document.getElementById('svc_port').value = (entry.port ?? '') + '';
  if (!rtChanged) document.getElementById('svc_runtime').value = entry.runtime || 'systemd';
  document.getElementById('svc_web_path').value = (entry.web_path ?? '') + '';
  document.getElementById('svc_config_files').value = _listToLines(entry.config_files);
  document.getElementById('svc_data_paths').value = _listToLines(entry.data_paths);
  const rt = document.getElementById('svc_runtime').value;
  document.getElementById('svc_container_row').style.display = rt==='docker' ? 'block' : 'none';
  document.getElementById('svc_docker_container').value = entry.docker_container || '';
  const isKiwix = unit === 'kiwix';
  document.getElementById('kiwix_extra').style.display = isKiwix ? 'block' : 'none';
  if (isKiwix){
    document.getElementById('svc_kiwix_zim_dir').value = (entry.kiwix_zim_dir ?? '') + '';
    document.getElementById('svc_kiwix_library_xml').value = (entry.kiwix_library_xml ?? '') + '';
  }
}

async function loadSettings() {
  try {
    const r = await fetch('/api/settings', { method:'GET' });
    const d = await r.json();
    if (!d.ok) { toast(d.error || 'Failed to load settings', false); return; }
    SETTINGS = d.settings || {};
    _ensureSettingsShape();

    document.getElementById('set_viewer_host').value = (SETTINGS.dashboard.viewer_host ?? 'auto') + '';
    document.getElementById('set_viewer_scheme').value = (SETTINGS.dashboard.viewer_scheme ?? 'http') + '';

    // Dashboard filters & safety
    const hs = document.getElementById('set_hide_stopped');
    const pd = document.getElementById('set_protect_dashboard');
    const hu = document.getElementById('set_hidden_units');
    if (hs) hs.checked = !!SETTINGS.dashboard.hide_stopped_services;
    if (pd) pd.checked = !!SETTINGS.dashboard.protect_dashboard_service;
    if (hu) hu.value = _listToLines(SETTINGS.dashboard.hidden_units);

    populateHiddenPicker();
    populateServicePicker();
    if (DATA && DATA.services && DATA.services.length){
      const pick = document.getElementById('svc_pick');
      if (pick && !pick.value) pick.value = DATA.services.find(s=>s.is_builtin)?.unit || DATA.services[0].unit;
    }
    onPickService();
    renderCustomServerList(SETTINGS.custom_services || []);
  } catch(e) {
    toast('Settings request failed', false);
  }
}

function renderCustomServerList(list) {
  const card = document.getElementById('custom-servers-card');
  const el = document.getElementById('custom-svc-list');
  if (!list || !list.length) { card.style.display='none'; return; }
  card.style.display = 'block';
  el.innerHTML = list.map(cs => {
    const rt = cs.runtime||'external';
    const badgeCls = rt==='docker'?'sbadge-docker':rt==='windows'?'sbadge-windows':'sbadge-external';
    return `<div class="custom-svc-row">
      <span class="csname">${cs.icon?esc(cs.icon)+' ':''}${esc(cs.name)}</span>
      <span class="csmeta">${esc(rt)} · ${cs.host&&cs.host!=='localhost'?cs.host+':':''}${cs.port||'—'} · ${esc(cs.category)}</span>
      <span class="sbadge ${badgeCls}">${esc(rt)}</span>
      <button class="cbtn del" onclick="removeCustomServer(${JSON.stringify(cs.id||cs.unit)})">${ICO.trash}</button>
    </div>`;
  }).join('');
}

async function removeCustomServer(id) {
  if (!confirm('Remove this server from the dashboard?')) return;
  try {
    const r = await fetch('/api/servers/remove', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({id}) });
    const d = await r.json();
    toast(d.message||'Removed', d.ok);
    if (d.ok) { await fetchData(); await loadSettings(); }
  } catch(e) { toast('Remove failed', false); }
}

function _applyUiToSettings(){
  _ensureSettingsShape();
  SETTINGS.dashboard.viewer_host = (document.getElementById('set_viewer_host').value || '').trim() || 'auto';
  SETTINGS.dashboard.viewer_scheme = (document.getElementById('set_viewer_scheme').value || 'http').trim();
  const hs = document.getElementById('set_hide_stopped');
  const pd = document.getElementById('set_protect_dashboard');
  const huText = document.getElementById('set_hidden_units');
  SETTINGS.dashboard.hide_stopped_services = hs ? !!hs.checked : false;
  SETTINGS.dashboard.protect_dashboard_service = pd ? !!pd.checked : true;
  let hu = [];
  if (huText && huText.value != null) {
    hu = _linesToList(huText.value);
  } else {
    const pick = document.getElementById('set_hidden_pick');
    if (pick) hu = Array.from(pick.selectedOptions || []).map(o => o.value);
  }
  SETTINGS.dashboard.hidden_units = hu;

  const unit = _svcKey();
  if (!unit) return;
  if (!SETTINGS.services[unit] || typeof SETTINGS.services[unit] !== 'object') SETTINGS.services[unit] = {};
  const entry = SETTINGS.services[unit];
  const portRaw = (document.getElementById('svc_port').value || '').trim();
  entry.port = portRaw ? parseInt(portRaw, 10) : null;
  entry.runtime = document.getElementById('svc_runtime').value || 'systemd';
  entry.docker_container = (document.getElementById('svc_docker_container').value || '').trim() || null;
  const wp = (document.getElementById('svc_web_path').value || '').trim();
  entry.web_path = wp === '' ? '' : wp;
  entry.config_files = _linesToList(document.getElementById('svc_config_files').value);
  entry.data_paths = _linesToList(document.getElementById('svc_data_paths').value);
  if (unit === 'kiwix'){
    entry.kiwix_zim_dir = (document.getElementById('svc_kiwix_zim_dir').value || '').trim();
    entry.kiwix_library_xml = (document.getElementById('svc_kiwix_library_xml').value || '').trim();
  }
}

async function saveAllSettings() {
  try {
    _applyUiToSettings();
    const payload = { settings: SETTINGS };
    const r = await fetch('/api/settings', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const d = await r.json();
    toast(d.message || (d.ok ? 'Saved' : 'Save failed'), !!d.ok);
    if (d.ok) {
      SETTINGS = d.settings || SETTINGS;
      await loadSettings();
    }
  } catch(e) {
    toast('Save request failed', false);
  }
}

async function autoDetectSelected() {
  try {
    const unit = _svcKey();
    if (!unit) { toast('Select a service first', false); return; }
    const r = await fetch('/api/settings/autodetect', { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ unit, apply: true }) });
    const d = await r.json();
    toast(d.ok ? 'Auto-detect applied' : (d.message || 'Auto-detect failed'), !!d.ok);
    if (d.ok) await loadSettings();
  } catch(e) {
    toast('Auto-detect request failed', false);
  }
}

async function autoDetectAll() {
  try {
    const r = await fetch('/api/settings/autodetect', { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ all: true, apply: true }) });
    const d = await r.json();
    toast(d.ok ? 'Auto-detect applied to all' : (d.message || 'Auto-detect failed'), !!d.ok);
    if (d.ok) await loadSettings();
  } catch(e) {
    toast('Auto-detect request failed', false);
  }
}

// Viewer
function _syncModalClass(){
  const v = document.getElementById('viewer');
  const e = document.getElementById('editor');
  const b = document.getElementById('browser');
  const open = (v && v.classList.contains('open')) || (e && e.classList.contains('open')) || (b && b.classList.contains('open'));
  document.body.classList.toggle('modal-open', !!open);
}
function openViewer(name, url) {
  document.getElementById('vtitle').textContent = name;
  document.getElementById('vurl').textContent = url;
  document.getElementById('vext').href = url;
  document.getElementById('vframe').src = url;
  document.getElementById('viewer').classList.add('open');
  _syncModalClass();
}
function closeViewer() {
  document.getElementById('viewer').classList.remove('open');
  _syncModalClass();
  document.getElementById('vframe').src = '';
}

// Editor
async function openEditor(unit) {
  const svc = DATA && DATA.services ? DATA.services.find(s => s.unit === unit) : null;
  if (!svc) { toast('Service not found', false); return; }

  currentEditorUnit = unit;
  document.getElementById('etitle').textContent = svc.name + ' Config';
  const filesDiv = document.getElementById('efiles');

  const cfgs = svc.config_files || [];
  const syscfgs = (DATA && DATA.system_configs) || [];
  let tabsHtml = '';

  if (cfgs.length > 0) {
    tabsHtml += '<span class="file-group-label">Service</span>';
    cfgs.forEach((f, i) => {
      tabsHtml += `<button class="file-tab${i===0?' active':''}" onclick="loadFile(${JSON.stringify(f)},this)">${f.split('/').pop()}</button>`;
    });
  }

  if (syscfgs.length > 0) {
    tabsHtml += '<span class="file-group-label" style="margin-left:6px">System</span>';
    syscfgs.forEach(f => {
      if (!cfgs.includes(f))
        tabsHtml += `<button class="file-tab system" onclick="loadFile(${JSON.stringify(f)},this)">${f.split('/').pop()}</button>`;
    });
  }

  tabsHtml += `<button class="file-tab browse" onclick="openBrowserForEditor('${unit}')">📁 Browse...</button>`;
  filesDiv.innerHTML = tabsHtml;

  document.getElementById('editor').classList.add('open');
  _syncModalClass();

  const first = cfgs[0] || null;
  if (first) {
    await loadFile(first, filesDiv.querySelector('.file-tab'));
  } else {
    document.getElementById('etext').value = '';
    document.getElementById('epath').textContent = 'No service configs — use System tabs or Browse';
    document.getElementById('estatus').textContent = '';
    updateLineCount();
  }
}

async function loadFile(filepath, tabEl) {
  currentEditorFile = filepath;
  document.querySelectorAll('.file-tab').forEach(e => e.classList.remove('active'));
  if (tabEl) tabEl.classList.add('active');
  document.getElementById('epath').textContent = filepath;
  document.getElementById('estatus').textContent = 'Loading...';
  try {
    const r = await fetch('/api/config?path=' + encodeURIComponent(filepath));
    const d = await r.json();
    if (d.ok) {
      document.getElementById('etext').value = d.content;
      updateLineCount();
      document.getElementById('estatus').textContent = 'Loaded';
    } else {
      document.getElementById('etext').value = '';
      document.getElementById('estatus').innerHTML = `<span class="error">${d.error}</span>`;
    }
  } catch(e) {
    document.getElementById('estatus').innerHTML = '<span class="error">Failed to load</span>';
  }
}

async function saveFile() {
  if (!currentEditorFile) { toast('No file selected', false); return; }
  const content = document.getElementById('etext').value;
  document.getElementById('estatus').textContent = 'Saving...';
  try {
    const r = await fetch('/api/config', { method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({path:currentEditorFile, content}) });
    const d = await r.json();
    if (d.ok) {
      document.getElementById('estatus').innerHTML = '<span class="saved">✓ Saved (backup created)</span>';
      toast('File saved', true);
    } else {
      document.getElementById('estatus').innerHTML = `<span class="error">${d.error}</span>`;
      toast(d.error, false);
    }
  } catch(e) { toast('Save failed', false); }
}

function closeEditor() {
  document.getElementById('editor').classList.remove('open');
  _syncModalClass();
  currentEditorFile = null; currentEditorUnit = null;
}

function updateLineCount() {
  const t = document.getElementById('etext');
  const lines = t.value.split('\n').length;
  document.getElementById('elines').textContent = lines + ' lines';
}

// File Browser
function openBrowserForEditor(unit) {
  browserCallback = function(filepath) {
    // Add the file to the config and load it
    loadFile(filepath, null);
    // Also add a new tab for it
    const filesDiv = document.getElementById('efiles');
    const filename = filepath.split('/').pop();
    const newTab = document.createElement('button');
    newTab.className = 'file-tab active';
    newTab.textContent = filename;
    newTab.onclick = function() { loadFile(filepath, newTab); };
    // Insert before browse button
    const browseBtn = filesDiv.querySelector('.browse');
    filesDiv.insertBefore(newTab, browseBtn);
  };
  openBrowser('/opt');
}

async function openBrowser(startPath) {
  document.getElementById('browser').classList.add('open');
  _syncModalClass();
  document.getElementById('binput').value = startPath || '/opt';
  await loadBrowserDir(startPath || '/opt');
}

async function loadBrowserDir(path) {
  document.getElementById('bpath').textContent = path;
  document.getElementById('binput').value = path;
  document.getElementById('blist').innerHTML = '<div style="padding:20px;color:var(--text2);">Loading...</div>';
  
  try {
    const r = await fetch('/api/browse?path=' + encodeURIComponent(path));
    const d = await r.json();
    if (!d.ok) {
      document.getElementById('blist').innerHTML = `<div style="padding:20px;color:var(--red);">${d.error}</div>`;
      return;
    }
    
    const items = d.data.items || [];
    if (items.length === 0) {
      document.getElementById('blist').innerHTML = '<div style="padding:20px;color:var(--text2);">Empty directory</div>';
      return;
    }
    
    let html = '';
    items.forEach(item => {
      if (item.type === 'dir') {
        html += `<div class="browser-item dir" onclick="loadBrowserDir('${item.path}')">${ICO.folder} ${item.name}</div>`;
      } else {
        html += `<div class="browser-item file" onclick="selectBrowserFile('${item.path}')">${ICO.file} ${item.name}</div>`;
      }
    });
    document.getElementById('blist').innerHTML = html;
  } catch(e) {
    document.getElementById('blist').innerHTML = '<div style="padding:20px;color:var(--red);">Failed to load directory</div>';
  }
}

function selectBrowserFile(filepath) {
  document.getElementById('binput').value = filepath;
  selectBrowserPath();
}

function selectBrowserPath() {
  const path = document.getElementById('binput').value.trim();
  if (!path) { toast('Enter a path', false); return; }
  closeBrowser();
  if (browserCallback) {
    browserCallback(path);
    browserCallback = null;
  }
}

function closeBrowser() {
  document.getElementById('browser').classList.remove('open');
  _syncModalClass();
}

// Logs
function buildLogList() {
  if (!DATA) return;
  const el = document.getElementById('jlist');
  const svcs = DATA.services.filter(s => s.status === 'active');
  if (svcs.length === 0) {
    el.innerHTML = '<div style="color:var(--text2);padding:8px;">No active services</div>';
    return;
  }
  el.innerHTML = svcs.map(s => `<button class="jbtn" onclick="fetchLog('${s.unit}',this)">${s.name}</button>`).join('');
}

async function fetchLog(unit, btn) {
  document.querySelectorAll('.jbtn').forEach(e => e.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.getElementById('jout').textContent = 'Loading...';
  try {
    const r = await fetch('/api/logs?unit=' + encodeURIComponent(unit));
    const d = await r.json();
    document.getElementById('jout').textContent = d.logs || 'No logs available';
  } catch(e) { document.getElementById('jout').textContent = 'Failed to fetch logs'; }
}

// Data
async function fetchData() {
  try {
    const r = await fetch('/api/status');
    DATA = await r.json();
    renderSys(DATA.system);
    renderSvc(DATA.services, DATA.categories);
    if (DATA.app && DATA.app.version) {
      const vEl = document.getElementById('appver');
      if (vEl) vEl.textContent = 'v' + DATA.app.version;
    }
    const total = DATA.services.length, active = DATA.services.filter(s=>s.status==='active').length;
    const tmem = DATA.services.reduce((a,s) => a+(s.memory_mb||0), 0);
    document.getElementById('fsum').textContent = `${active}/${total} services active · ${tmem.toFixed(0)} MB total`;
    document.getElementById('fupd').textContent = 'Updated: ' + new Date(DATA.timestamp).toLocaleTimeString();
  } catch(e) { 
    console.error('Fetch error:', e);
    document.getElementById('fsum').textContent = 'Error loading data';
  }
}

function tick() {
  document.getElementById('clock').textContent = new Date().toLocaleTimeString();
  countdown--;
  if (countdown <= 0) { countdown = 30; fetchData(); }
  document.getElementById('rtimer').textContent = countdown + 's';
}

// Escape key closes overlays
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeViewer(); closeEditor(); closeBrowser(); }
});

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('etext').addEventListener('input', updateLineCount);
  // Tab key support in editor
  document.getElementById('etext').addEventListener('keydown', function(e) {
    if (e.key === 'Tab') {
      e.preventDefault();
      const s = this.selectionStart, end = this.selectionEnd;
      this.value = this.value.substring(0,s) + '    ' + this.value.substring(end);
      this.selectionStart = this.selectionEnd = s + 4;
    }
  });
});

fetchData();
tick();
setInterval(tick, 1000);
</script>
</body>
</html>"""


class DashboardHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)

        if parsed.path == '/api/status':
            self._json(200, build_api_response())
        elif parsed.path == '/api/config':
            path = qs.get('path', [None])[0]
            if not path:
                self._json(400, json.dumps({"ok": False, "error": "No path"}))
                return
            content, err = read_config_file(path)
            if err:
                self._json(200, json.dumps({"ok": False, "error": err}))
            else:
                self._json(200, json.dumps({"ok": True, "content": content}))
        elif parsed.path == '/api/logs':
            unit = qs.get('unit', [None])[0]
            runtime = qs.get('runtime', ['systemd'])[0] or 'systemd'
            container = qs.get('container', [''])[0] or ''
            if not unit:
                self._json(400, json.dumps({"logs": "No unit specified"}))
                return
            valid = set(s[1] for s in SERVICES)
            valid |= {c.get("unit", "") for c in load_settings().get("custom_services", [])}
            if unit not in valid:
                self._json(400, json.dumps({"logs": "Unknown unit"}))
                return
            if runtime == "docker":
                cname = container or unit
                logs, _ = run_cmd(f"docker logs --tail 100 {cname} 2>&1", timeout=10)
            elif runtime == "systemd":
                logs, _ = run_cmd(f"journalctl -u {unit} --no-pager -n 100 --output=short-iso", timeout=10)
            else:
                logs = f"Logs not available for runtime: {runtime}"
            self._json(200, json.dumps({"logs": logs or "(no logs)"}))
        elif parsed.path == '/api/scan':
            results = scan_services()
            self._json(200, json.dumps({"ok": True, "results": results}))
        elif parsed.path == '/api/settings':
            s = load_settings()
            self._json(200, json.dumps({"ok": True, "settings": s}))
        elif parsed.path == '/api/browse':
            path = qs.get('path', ['/opt'])[0]
            data, err = browse_directory(path)
            if err:
                self._json(200, json.dumps({"ok": False, "error": err}))
            else:
                self._json(200, json.dumps({"ok": True, "data": data}))
        elif parsed.path == '/' or parsed.path == '/index.html':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(HTML_PAGE.encode())
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        length = int(self.headers.get('Content-Length', 0))
        body = json.loads(self.rfile.read(length)) if length else {}

        if parsed.path == '/api/control':
            unit = body.get('unit', '')
            action = body.get('action', '')
            rt = body.get('runtime', 'systemd')
            dc = body.get('docker_container', '') or None
            ok, msg = service_control(unit, action, runtime=rt, docker_container=dc)
            self._json(200, json.dumps({"ok": ok, "message": msg}))
        elif parsed.path == '/api/config':
            path = body.get('path', '')
            content = body.get('content', '')
            ok, msg = write_config_file(path, content)
            self._json(200, json.dumps({"ok": ok, "message": msg, "error": "" if ok else msg}))
        elif parsed.path == '/api/settings':
            if isinstance(body, dict) and isinstance(body.get("settings"), dict):
                new_s = body.get("settings")
            else:
                new_s = load_settings()
                if "viewer_host" in body:
                    new_s["dashboard"]["viewer_host"] = str(body.get("viewer_host", "")).strip()
                if "kiwix_zim_dir" in body:
                    new_s["services"]["kiwix"]["kiwix_zim_dir"] = str(body.get("kiwix_zim_dir", "")).strip()
                if "kiwix_library_xml" in body:
                    new_s["services"]["kiwix"]["kiwix_library_xml"] = str(body.get("kiwix_library_xml", "")).strip()
            new_s["schema_version"] = SETTINGS_SCHEMA_VERSION
            ok, msg = save_settings(new_s)
            self._json(200, json.dumps({"ok": ok, "message": msg, "settings": load_settings()}))

        elif parsed.path == '/api/settings/autodetect':
            s = load_settings()
            svc = s.get("services", {})
            detected = {}
            if body.get("all"):
                units = [u for _, u, _, _, _, _, _ in SERVICES]
            else:
                unit = str(body.get("unit", "")).strip()
                units = [unit] if unit else []
            valid_units = {u for _, u, _, _, _, _, _ in SERVICES}
            units = [u for u in units if u in valid_units]
            if not units:
                self._json(400, json.dumps({"ok": False, "message": "No valid unit specified"}))
                return
            for u in units:
                detected[u] = _autodetect_service(u, svc.get(u, {}))
            if body.get("apply", True):
                for u, entry in detected.items():
                    if u in s["services"]:
                        s["services"][u].update(entry)
                save_settings(s)
            self._json(200, json.dumps({"ok": True, "detected": detected, "settings": load_settings()}))

        elif parsed.path == '/api/servers/add':
            servers = body.get("servers", [])
            if not isinstance(servers, list) or not servers:
                self._json(400, json.dumps({"ok": False, "message": "No servers provided"}))
                return
            s = load_settings()
            cs = s.get("custom_services", [])
            added = 0
            for srv in servers:
                if not isinstance(srv, dict):
                    continue
                if not srv.get("id"):
                    srv["id"] = str(uuid.uuid4())[:8]
                unit = srv.get("unit", "")
                # Skip duplicates by unit
                if any(c.get("unit") == unit for c in cs):
                    continue
                cs.append(srv)
                added += 1
            s["custom_services"] = cs
            ok, msg = save_settings(s)
            self._json(200, json.dumps({"ok": ok, "message": f"Added {added} server(s)" if ok else msg, "settings": load_settings()}))

        elif parsed.path == '/api/servers/remove':
            sid = str(body.get("id", "")).strip()
            if not sid:
                self._json(400, json.dumps({"ok": False, "message": "No id provided"}))
                return
            s = load_settings()
            cs = s.get("custom_services", [])
            before = len(cs)
            cs = [c for c in cs if c.get("id") != sid and c.get("unit") != sid]
            s["custom_services"] = cs
            ok, msg = save_settings(s)
            removed = before - len(cs)
            self._json(200, json.dumps({"ok": ok, "message": f"Removed {removed} server(s)" if ok else msg}))

        elif parsed.path == '/api/kiwix/refresh':
            ok, msg, details = refresh_kiwix_library()
            self._json(200, json.dumps({"ok": ok, "message": msg, "details": details}))
        else:
            self.send_response(404)
            self.end_headers()

    def _json(self, code, data):
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        if isinstance(data, str):
            self.wfile.write(data.encode())
        else:
            self.wfile.write(data)


def main():
    port = 8029
    server = HTTPServer(('0.0.0.0', port), DashboardHandler)
    print(f"SidscriPi Dashboard running at http://0.0.0.0:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.server_close()


if __name__ == '__main__':
    main()
