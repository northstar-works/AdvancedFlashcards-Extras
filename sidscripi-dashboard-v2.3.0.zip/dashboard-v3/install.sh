#!/bin/bash
# SidscriPi Dashboard v2 Installer

set -e
echo "═══════════════════════════════════════"
echo "  SidscriPi Dashboard v2 Installer"
echo "═══════════════════════════════════════"
echo ""

# Stop existing if running
sudo systemctl stop pi-dashboard 2>/dev/null || true

# Copy files
sudo mkdir -p /opt/pi-dashboard
sudo cp server.py /opt/pi-dashboard/

# Install Kiwix refresh helper
sudo cp kiwix-refresh-library.sh /usr/local/bin/kiwix-refresh-library.sh
sudo chmod +x /usr/local/bin/kiwix-refresh-library.sh
sudo chmod +x /opt/pi-dashboard/server.py

# Install settings (preserve existing)
if [ ! -f /opt/pi-dashboard/settings.json ]; then
  sudo cp settings.json /opt/pi-dashboard/settings.json
fi

# Install service (runs as root for systemctl control + config access)
sudo cp pi-dashboard.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable pi-dashboard
sudo systemctl start pi-dashboard

IP=$(hostname -I | awk '{print $1}')
echo ""
echo "✓ Dashboard installed and running!"
echo ""
echo "  URL:  http://${IP}:8029"
echo ""
echo "  Features:"
echo "    • Real-time system monitoring"
echo "    • Start / Stop / Restart services"
echo "    • Built-in web UI viewer (iframe)"
echo "    • Config file editor with backups"
echo "    • Service log viewer"
echo ""
echo "  Commands:"
echo "    sudo systemctl status pi-dashboard"
echo "    sudo systemctl restart pi-dashboard"
echo "    sudo journalctl -u pi-dashboard -f"
echo ""
echo "═══════════════════════════════════════"
