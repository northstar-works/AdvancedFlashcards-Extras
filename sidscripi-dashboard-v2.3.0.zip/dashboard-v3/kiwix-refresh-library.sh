#!/usr/bin/env bash
set -euo pipefail

ZIM_DIR="/opt/appdata/kiwix/data/zims"
LIB_DIR="/opt/appdata/kiwix/data"
LIB_XML="${LIB_DIR}/library.xml"

# Optional: read paths from dashboard settings if present
SETTINGS_JSON="/opt/pi-dashboard/settings.json"
if [[ -f "$SETTINGS_JSON" ]]; then
  # Use python3 to avoid jq dependency
  ZIM_DIR_FROM_SETTINGS="$(python3 - <<'PY' "$SETTINGS_JSON" 2>/dev/null || true
import json,sys
p=sys.argv[1]
d=json.load(open(p))
print(d.get("kiwix_zim_dir",""))
PY
)"
  LIB_XML_FROM_SETTINGS="$(python3 - <<'PY' "$SETTINGS_JSON" 2>/dev/null || true
import json,sys
p=sys.argv[1]
d=json.load(open(p))
print(d.get("kiwix_library_xml",""))
PY
)"
  [[ -n "${ZIM_DIR_FROM_SETTINGS:-}" ]] && ZIM_DIR="$ZIM_DIR_FROM_SETTINGS"
  [[ -n "${LIB_XML_FROM_SETTINGS:-}" ]] && LIB_XML="$LIB_XML_FROM_SETTINGS"
  # If LIB_XML was overridden, update LIB_DIR accordingly
  if [[ -n "${LIB_XML_FROM_SETTINGS:-}" ]]; then
    LIB_DIR="$(dirname "$LIB_XML")"
  fi
fi


mkdir -p "$ZIM_DIR" "$LIB_DIR"

# Rebuild library.xml from scratch to avoid duplicates/stale entries
rm -f "$LIB_XML"

shopt -s nullglob

# Prefer .zimaa when split zims exist; otherwise use .zim
declare -A chosen=()
for f in "$ZIM_DIR"/*.zim "$ZIM_DIR"/*.zim?? "$ZIM_DIR"/*.ZIM "$ZIM_DIR"/*.ZIM??; do
  [ -e "$f" ] || continue
  bn="$(basename "$f")"
  # strip extension (.zim or .zimaa)
  base="${bn%.*}"
  ext="${bn##*.}"
  # normalize ext lower
  ext_l="${ext,,}"
  if [[ "$ext_l" == "zimaa" ]]; then
    chosen["$base"]="$f"
  elif [[ "$ext_l" == "zim" ]]; then
    # only choose .zim if we don't already have .zimaa
    if [[ -z "${chosen["$base"]+x}" ]]; then
      chosen["$base"]="$f"
    fi
  else
    # for other split parts like .zimab, only pick if nothing else
    if [[ -z "${chosen["$base"]+x}" ]]; then
      chosen["$base"]="$f"
    fi
  fi
done

count=0
for key in "${!chosen[@]}"; do
  f="${chosen[$key]}"
  echo "Adding: $f"
  kiwix-manage "$LIB_XML" add "$f"
  count=$((count+1))
done

if [[ "$count" -eq 0 ]]; then
  echo "No ZIM files found in $ZIM_DIR"
else
  echo "Added $count item(s) to $LIB_XML"
fi

# Restart Kiwix service so kiwix-serve reloads the library
if systemctl list-unit-files | grep -q '^kiwix\.'; then
  systemctl restart kiwix
  echo "Restarted systemd unit: kiwix"
else
  # Fallback: try common names
  if systemctl list-unit-files | grep -q '^kiwix-serve\.'; then
    systemctl restart kiwix-serve
    echo "Restarted systemd unit: kiwix-serve"
  else
    echo "NOTE: No 'kiwix' or 'kiwix-serve' systemd unit found. Restart your Kiwix service manually if needed."
  fi
fi
