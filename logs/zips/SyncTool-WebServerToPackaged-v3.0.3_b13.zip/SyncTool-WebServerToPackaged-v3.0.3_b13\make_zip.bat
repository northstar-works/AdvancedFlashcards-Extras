@echo off
REM Wrapper kept for backward compatibility.
call "%~dp0make1_zip_SyncTool-WebServerToPackaged-Zip.bat"
