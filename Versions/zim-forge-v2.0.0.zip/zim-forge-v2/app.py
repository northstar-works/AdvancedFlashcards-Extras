"""
ZIM Forge — Web-based document-to-ZIM converter for Kiwix
"""

import io
import os
import uuid
import json
import threading
import shutil
import subprocess
import time
from pathlib import Path
from flask import Flask, request, jsonify, send_file, render_template, send_from_directory

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB

ALLOWED_EXTENSIONS = {'.doc', '.docx', '.pdf', '.xlsx', '.xls', '.html', '.htm'}

# ─────────────────────────────────────────────
# Settings — persistent JSON
# ─────────────────────────────────────────────

SETTINGS_FILE = Path(os.environ.get('ZF_SETTINGS', '/opt/zim-forge/settings.json'))
SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)

DEFAULTS = {
    'output_dir':        '/opt/appdata/kiwix/data/zims',
    'jobs_dir':          '/opt/zim-forge/jobs',
    'server_host':       '0.0.0.0',
    'server_port':       5000,
    'kiwix_service':     'kiwix',          # systemd unit name
    'kiwix_library_xml': '/opt/appdata/kiwix/data/library.xml',
    'auto_reload_kiwix': True,
}

_settings_lock = threading.Lock()


def load_settings() -> dict:
    with _settings_lock:
        if SETTINGS_FILE.exists():
            try:
                data = json.loads(SETTINGS_FILE.read_text())
                merged = {**DEFAULTS, **data}
                return merged
            except Exception:
                pass
        return dict(DEFAULTS)


def save_settings(new: dict):
    with _settings_lock:
        current = load_settings()
        current.update(new)
        SETTINGS_FILE.write_text(json.dumps(current, indent=2))
    # Apply output dir immediately
    app.config['OUTPUT_FOLDER'] = Path(current['output_dir'])
    app.config['OUTPUT_FOLDER'].mkdir(parents=True, exist_ok=True)


def get_output_dir() -> Path:
    p = Path(load_settings()['output_dir'])
    p.mkdir(parents=True, exist_ok=True)
    return p


def get_jobs_dir() -> Path:
    p = Path(load_settings()['jobs_dir'])
    p.mkdir(parents=True, exist_ok=True)
    return p


# Apply settings at startup
_s = load_settings()
app.config['OUTPUT_FOLDER'] = Path(_s['output_dir'])
app.config['UPLOAD_FOLDER'] = Path(_s['jobs_dir'])

# ─────────────────────────────────────────────
# Job registry
# ─────────────────────────────────────────────

jobs = {}
jobs_lock = threading.Lock()


def allowed_file(filename):
    return Path(filename).suffix.lower() in ALLOWED_EXTENSIONS


def update_job(job_id, **kwargs):
    with jobs_lock:
        if job_id in jobs:
            jobs[job_id].update(kwargs)


def log_job(job_id, message):
    ts = time.strftime('%H:%M:%S')
    with jobs_lock:
        if job_id in jobs:
            jobs[job_id]['log'].append(f"[{ts}] {message}")


# ─────────────────────────────────────────────
# Routes — UI
# ─────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/output/<path:filename>')
def download_output(filename):
    return send_from_directory(get_output_dir(), filename, as_attachment=True)


# ─────────────────────────────────────────────
# Routes — Settings API
# ─────────────────────────────────────────────

@app.route('/api/settings', methods=['GET'])
def get_settings():
    s = load_settings()
    # Add runtime status info
    s['output_dir_exists'] = Path(s['output_dir']).exists()
    s['zim_count'] = len(list(Path(s['output_dir']).glob('*.zim'))) if Path(s['output_dir']).exists() else 0
    return jsonify(s)


@app.route('/api/settings', methods=['POST'])
def update_settings():
    data = request.get_json(force=True)
    allowed_keys = set(DEFAULTS.keys())
    filtered = {k: v for k, v in data.items() if k in allowed_keys}

    # Validate port
    if 'server_port' in filtered:
        try:
            filtered['server_port'] = int(filtered['server_port'])
            if not (1 <= filtered['server_port'] <= 65535):
                return jsonify({'error': 'Port must be 1–65535'}), 400
        except ValueError:
            return jsonify({'error': 'Invalid port'}), 400

    # Validate/create output dir
    if 'output_dir' in filtered:
        try:
            Path(filtered['output_dir']).mkdir(parents=True, exist_ok=True)
        except Exception as e:
            return jsonify({'error': f'Cannot create output dir: {e}'}), 400

    save_settings(filtered)
    return jsonify({'ok': True, 'settings': load_settings()})


@app.route('/api/settings/reset', methods=['POST'])
def reset_settings():
    if SETTINGS_FILE.exists():
        SETTINGS_FILE.unlink()
    save_settings(DEFAULTS)
    return jsonify({'ok': True, 'settings': load_settings()})


# ─────────────────────────────────────────────
# Routes — Kiwix control
# ─────────────────────────────────────────────

@app.route('/api/kiwix/status', methods=['GET'])
def kiwix_status():
    s = load_settings()
    unit = s.get('kiwix_service', 'kiwix')
    try:
        r = subprocess.run(
            ['systemctl', 'is-active', unit],
            capture_output=True, text=True, timeout=5
        )
        active = r.stdout.strip() == 'active'
        status = r.stdout.strip()
    except Exception as e:
        active = False
        status = f'error: {e}'

    zim_dir = Path(s['output_dir'])
    zims = []
    if zim_dir.exists():
        zims = [{'name': f.name, 'size': f.stat().st_size} for f in sorted(zim_dir.glob('*.zim'))]

    return jsonify({
        'unit':   unit,
        'active': active,
        'status': status,
        'zims':   zims,
        'zim_dir': str(zim_dir),
    })


@app.route('/api/kiwix/restart', methods=['POST'])
def kiwix_restart():
    s = load_settings()
    unit = s.get('kiwix_service', 'kiwix')
    try:
        r = subprocess.run(
            ['sudo', 'systemctl', 'restart', unit],
            capture_output=True, text=True, timeout=15
        )
        if r.returncode == 0:
            return jsonify({'ok': True, 'message': f'{unit} restarted'})
        else:
            return jsonify({'ok': False, 'error': r.stderr.strip() or r.stdout.strip()}), 500
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.route('/api/kiwix/stop', methods=['POST'])
def kiwix_stop():
    s = load_settings()
    unit = s.get('kiwix_service', 'kiwix')
    try:
        r = subprocess.run(['sudo', 'systemctl', 'stop', unit],
                           capture_output=True, text=True, timeout=15)
        return jsonify({'ok': r.returncode == 0, 'error': r.stderr.strip()})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.route('/api/kiwix/start', methods=['POST'])
def kiwix_start():
    s = load_settings()
    unit = s.get('kiwix_service', 'kiwix')
    try:
        r = subprocess.run(['sudo', 'systemctl', 'start', unit],
                           capture_output=True, text=True, timeout=15)
        return jsonify({'ok': r.returncode == 0, 'error': r.stderr.strip()})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.route('/api/kiwix/reload-library', methods=['POST'])
def kiwix_reload_library():
    """Rebuild the Kiwix library.xml from all ZIMs in the output dir."""
    s = load_settings()
    zim_dir = Path(s['output_dir'])
    lib_xml = s.get('kiwix_library_xml', '/opt/appdata/kiwix/data/library.xml')

    if not zim_dir.exists():
        return jsonify({'ok': False, 'error': 'ZIM directory does not exist'}), 400

    zims = list(zim_dir.glob('*.zim'))
    if not zims:
        return jsonify({'ok': False, 'error': 'No ZIM files found in output directory'}), 400

    # Try kiwix-manage to rebuild library
    try:
        # Start fresh
        Path(lib_xml).parent.mkdir(parents=True, exist_ok=True)
        if Path(lib_xml).exists():
            Path(lib_xml).unlink()

        added = []
        errors = []
        for zim in zims:
            r = subprocess.run(
                ['kiwix-manage', lib_xml, 'add', str(zim)],
                capture_output=True, text=True, timeout=30
            )
            if r.returncode == 0:
                added.append(zim.name)
            else:
                errors.append(f"{zim.name}: {r.stderr.strip()}")

        # Restart Kiwix to pick up new library
        if s.get('auto_reload_kiwix'):
            subprocess.run(['sudo', 'systemctl', 'restart', s['kiwix_service']],
                           capture_output=True, timeout=15)

        return jsonify({
            'ok': True,
            'added': added,
            'errors': errors,
            'library_xml': lib_xml,
        })
    except FileNotFoundError:
        return jsonify({'ok': False, 'error': 'kiwix-manage not found in PATH'}), 500
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.route('/api/zimforge/restart', methods=['POST'])
def restart_self():
    """Restart the zim-forge systemd service (applies new port/host settings)."""
    def do_restart():
        time.sleep(1)
        subprocess.run(['sudo', 'systemctl', 'restart', 'zim-forge'],
                       capture_output=True, timeout=15)
    threading.Thread(target=do_restart, daemon=True).start()
    return jsonify({'ok': True, 'message': 'ZIM Forge restarting in 1s…'})


# ─────────────────────────────────────────────
# Routes — Logs
# ─────────────────────────────────────────────

@app.route('/api/jobs/<job_id>/log')
def download_job_log(job_id):
    with jobs_lock:
        job = jobs.get(job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404

    meta = job.get('meta', {})
    lines = [
        'ZIM Forge — Job Log',
        '===================',
        f"Job ID   : {job_id}",
        f"Title    : {meta.get('title', '?')}",
        f"Status   : {job.get('status', '?')}",
        f"Progress : {job.get('progress', 0)}%",
        f"Output   : {get_output_dir()}",
        f"Created  : {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(job.get('created_at', 0)))}",
        f"Files    : {', '.join(Path(f).name for f in job.get('files', [])) or 'none'}",
        f"URLs     : {', '.join(job.get('urls', [])) or 'none'}",
        '', '--- Conversion Log ---', '',
    ]
    lines += job.get('log', [])
    if job.get('error'):
        lines += ['', '--- Error Detail ---', job['error']]

    buf = io.BytesIO('\n'.join(lines).encode('utf-8'))
    safe = ''.join(c if c.isalnum() or c in '-_' else '_' for c in meta.get('title', job_id))[:40]
    return send_file(buf, mimetype='text/plain', as_attachment=True,
                     download_name=f"zimforge_{safe}_{job_id[:8]}.log")


@app.route('/api/system/log')
def download_system_log():
    lines = [
        'ZIM Forge — System Log',
        '=======================',
        f"Generated : {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"Settings  : {SETTINGS_FILE}",
        '',
    ]
    s = load_settings()
    lines += ['=== Current Settings ===']
    for k, v in s.items():
        lines.append(f'  {k}: {v}')

    lines += ['', '=== systemd journal (zim-forge) ===']
    try:
        r = subprocess.run(
            ['journalctl', '-u', 'zim-forge', '-n', '300', '--no-pager', '--output=short-iso'],
            capture_output=True, text=True, timeout=10
        )
        lines.append(r.stdout or '(no entries)')
    except Exception as e:
        lines.append(f'(error: {e})')

    lines += ['', '=== zimwriterfs version ===']
    try:
        r = subprocess.run(['zimwriterfs', '--version'], capture_output=True, text=True, timeout=5)
        lines.append(r.stdout.strip() or r.stderr.strip())
    except Exception as e:
        lines.append(str(e))

    buf = io.BytesIO('\n'.join(lines).encode('utf-8'))
    return send_file(buf, mimetype='text/plain', as_attachment=True,
                     download_name=f"zimforge_server_{time.strftime('%Y%m%d_%H%M%S')}.log")


# ─────────────────────────────────────────────
# Routes — Job API
# ─────────────────────────────────────────────

@app.route('/api/jobs', methods=['GET'])
def list_jobs():
    with jobs_lock:
        return jsonify(list(jobs.values()))


@app.route('/api/jobs/<job_id>', methods=['GET'])
def get_job(job_id):
    with jobs_lock:
        job = jobs.get(job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404
    return jsonify(job)


@app.route('/api/jobs/<job_id>', methods=['DELETE'])
def delete_job(job_id):
    with jobs_lock:
        job = jobs.pop(job_id, None)
    if job:
        job_dir = get_jobs_dir() / job_id
        if job_dir.exists():
            shutil.rmtree(job_dir, ignore_errors=True)
        out = get_output_dir() / job.get('output_filename', '')
        if out.exists():
            out.unlink(missing_ok=True)
    return jsonify({'ok': True})


@app.route('/api/convert', methods=['POST'])
def start_conversion():
    job_id = str(uuid.uuid4())
    job_dir = get_jobs_dir() / job_id
    job_dir.mkdir(parents=True, exist_ok=True)

    uploaded_files = []
    for f in request.files.getlist('files[]'):
        if f and f.filename and allowed_file(f.filename):
            dest = job_dir / f.filename
            f.save(str(dest))
            uploaded_files.append(str(dest))

    urls_raw = request.form.get('urls', '').strip()
    urls = [u.strip() for u in urls_raw.splitlines() if u.strip()]

    if not uploaded_files and not urls:
        shutil.rmtree(job_dir, ignore_errors=True)
        return jsonify({'error': 'No files or URLs provided'}), 400

    meta = {
        'title':       request.form.get('zim_title', 'ZIM Forge Export'),
        'description': request.form.get('zim_description', ''),
        'language':    request.form.get('zim_language', 'eng'),
        'creator':     request.form.get('zim_creator', 'ZIM Forge'),
        'publisher':   request.form.get('zim_publisher', 'ZIM Forge'),
    }
    crawl_opts = {
        'depth':       int(request.form.get('crawl_depth', 1)),
        'same_domain': request.form.get('crawl_same_domain', 'true').lower() == 'true',
        'include_re':  request.form.get('include_pattern', ''),
        'exclude_re':  request.form.get('exclude_pattern', ''),
        'delay':       float(request.form.get('crawl_delay', 0.5)),
        'user_agent':  request.form.get('user_agent', 'ZIMForge/1.0 (Kiwix archiver)'),
    }
    output_stem = request.form.get('output_name', '').strip() or meta['title'].replace(' ', '_')

    job = {
        'id':              job_id,
        'status':          'queued',
        'progress':        0,
        'log':             [],
        'meta':            meta,
        'files':           uploaded_files,
        'urls':            urls,
        'crawl_opts':      crawl_opts,
        'output_filename': output_stem + '.zim',
        'created_at':      time.time(),
        'error':           None,
    }
    with jobs_lock:
        jobs[job_id] = job

    threading.Thread(target=run_job, args=(job_id,), daemon=True).start()
    return jsonify({'job_id': job_id})


# ─────────────────────────────────────────────
# Background worker
# ─────────────────────────────────────────────

def run_job(job_id):
    from converters.document import convert_file
    from converters.crawler import crawl_url
    from zim_builder import build_zim

    with jobs_lock:
        job = dict(jobs[job_id])

    job_dir  = get_jobs_dir() / job_id
    html_dir = job_dir / 'html'
    html_dir.mkdir(exist_ok=True)
    out_dir  = get_output_dir()

    update_job(job_id, status='running', progress=5)
    html_pages = []
    total_sources = len(job['files']) + len(job['urls'])
    done = 0

    for filepath in job['files']:
        log_job(job_id, f"Converting file: {Path(filepath).name}")
        try:
            pages = convert_file(filepath, html_dir)
            html_pages.extend(pages)
            log_job(job_id, f"  → {len(pages)} page(s)")
        except Exception as e:
            log_job(job_id, f"  ✗ Error: {e}")
        done += 1
        update_job(job_id, progress=5 + int(50 * done / max(total_sources, 1)))

    for url in job['urls']:
        log_job(job_id, f"Crawling: {url}")
        try:
            pages = crawl_url(url, html_dir, job['crawl_opts'])
            html_pages.extend(pages)
            log_job(job_id, f"  → {len(pages)} page(s) crawled")
        except Exception as e:
            log_job(job_id, f"  ✗ Crawl error: {e}")
        done += 1
        update_job(job_id, progress=5 + int(50 * done / max(total_sources, 1)))

    if not html_pages:
        update_job(job_id, status='failed', error='No content was converted or crawled.')
        return

    log_job(job_id, f"Total pages: {len(html_pages)}")
    log_job(job_id, f"Output dir: {out_dir}")
    update_job(job_id, progress=60)

    out_path = out_dir / job['output_filename']
    log_job(job_id, "Building ZIM archive…")
    try:
        build_zim(
            pages=html_pages,
            output_path=str(out_path),
            meta=job['meta'],
            progress_cb=lambda p: update_job(job_id, progress=60 + int(35 * p))
        )
        log_job(job_id, f"✓ ZIM created: {out_path}")
        size = out_path.stat().st_size
        update_job(job_id, status='done', progress=100,
                   output_filename=job['output_filename'], output_size=size)

        # Auto-reload Kiwix if enabled
        s = load_settings()
        if s.get('auto_reload_kiwix'):
            log_job(job_id, f"Restarting Kiwix service ({s['kiwix_service']})…")
            r = subprocess.run(
                ['sudo', 'systemctl', 'restart', s['kiwix_service']],
                capture_output=True, text=True, timeout=15
            )
            if r.returncode == 0:
                log_job(job_id, "✓ Kiwix restarted — new ZIM is live")
            else:
                log_job(job_id, f"⚠ Kiwix restart failed: {r.stderr.strip()}")

    except Exception as e:
        log_job(job_id, f"✗ ZIM build failed: {e}")
        update_job(job_id, status='failed', error=str(e))


if __name__ == '__main__':
    get_jobs_dir()
    get_output_dir()
    s = load_settings()
    app.run(host=s['server_host'], port=s['server_port'], debug=False)
