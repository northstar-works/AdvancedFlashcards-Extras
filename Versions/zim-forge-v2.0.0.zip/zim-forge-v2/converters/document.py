"""
converters/document.py
Converts .docx, .doc, .pdf, .xlsx/.xls, .html/.htm files → list of HTML page dicts.
"""

import os
import re
import shutil
import subprocess
from pathlib import Path


def convert_file(filepath: str, out_dir: Path) -> list:
    p = Path(filepath)
    ext = p.suffix.lower()
    if ext == '.docx':
        return _convert_docx(p, out_dir)
    elif ext == '.doc':
        return _convert_doc_via_libreoffice(p, out_dir)
    elif ext == '.pdf':
        return _convert_pdf(p, out_dir)
    elif ext in ('.xlsx', '.xls'):
        return _convert_xlsx(p, out_dir)
    elif ext in ('.html', '.htm'):
        return _convert_html(p, out_dir)
    else:
        raise ValueError(f"Unsupported file type: {ext}")


def _convert_docx(p: Path, out_dir: Path) -> list:
    import mammoth
    with open(p, 'rb') as f:
        result = mammoth.convert_to_html(f)
    html = _wrap_html(p.stem, result.value)
    return [{'zim_path': f"docs/{_safe(p.stem)}.html",
             'title': p.stem.replace('_', ' ').replace('-', ' ').title(),
             'content': html, 'mimetype': 'text/html', 'is_front': True}]


def _convert_doc_via_libreoffice(p: Path, out_dir: Path) -> list:
    tmp_dir = out_dir / f"_lo_{p.stem}"
    tmp_dir.mkdir(exist_ok=True)
    try:
        cmd = ['libreoffice', '--headless', '--convert-to', 'html',
               '--outdir', str(tmp_dir), str(p)]
        subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        html_files = list(tmp_dir.glob('*.html'))
        if not html_files:
            raise RuntimeError("LibreOffice produced no HTML")
        content = html_files[0].read_text(encoding='utf-8', errors='replace')
        return [{'zim_path': f"docs/{_safe(p.stem)}.html",
                 'title': p.stem.replace('_', ' ').title(),
                 'content': content, 'mimetype': 'text/html', 'is_front': True}]
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def _convert_pdf(p: Path, out_dir: Path) -> list:
    from pdfminer.high_level import extract_text_to_fp
    from pdfminer.layout import LAParams
    import io
    output = io.StringIO()
    with open(p, 'rb') as f:
        extract_text_to_fp(f, output, laparams=LAParams(), output_type='html', codec=None)
    raw_html = output.getvalue()
    pages = _split_pdfminer_pages(raw_html, p.stem)
    if not pages:
        pages = [{'zim_path': f"docs/{_safe(p.stem)}.html",
                  'title': p.stem.replace('_', ' ').title(),
                  'content': raw_html, 'mimetype': 'text/html', 'is_front': True}]
    return pages


def _split_pdfminer_pages(html: str, stem: str) -> list:
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')
    divs = soup.find_all('div', id=re.compile(r'^page-\d+'))
    if not divs:
        return []
    safe = _safe(stem)
    pages = []
    for i, div in enumerate(divs, 1):
        page_html = _wrap_html(f"{stem} – Page {i}", str(div))
        pages.append({'zim_path': f"docs/{safe}_p{i:04d}.html",
                      'title': f"{stem} – Page {i}",
                      'content': page_html, 'mimetype': 'text/html', 'is_front': i == 1})
    return pages


def _convert_xlsx(p: Path, out_dir: Path) -> list:
    import openpyxl
    wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
    pages = []
    safe = _safe(p.stem)
    for sheet in wb.sheetnames:
        ws = wb[sheet]
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            continue
        table_html = _rows_to_html_table(rows)
        title = f"{p.stem} – {sheet}"
        content = _wrap_html(title, f'<h2>{sheet}</h2>\n{table_html}')
        pages.append({'zim_path': f"docs/{safe}_{_safe(sheet)}.html",
                      'title': title, 'content': content,
                      'mimetype': 'text/html', 'is_front': len(pages) == 0})
    wb.close()
    return pages


def _rows_to_html_table(rows) -> str:
    lines = ['<table class="xlsx-table">']
    for i, row in enumerate(rows):
        tag = 'th' if i == 0 else 'td'
        cells = ''.join(f'<{tag}>{_esc(cell)}</{tag}>' for cell in (row or []))
        lines.append(f'<tr>{cells}</tr>')
    lines.append('</table>')
    return '\n'.join(lines)


def _convert_html(p: Path, out_dir: Path) -> list:
    content = p.read_text(encoding='utf-8', errors='replace')
    m = re.search(r'<title[^>]*>(.*?)</title>', content, re.IGNORECASE | re.DOTALL)
    title = m.group(1).strip() if m else p.stem
    return [{'zim_path': f"docs/{_safe(p.stem)}.html",
             'title': title, 'content': content, 'mimetype': 'text/html', 'is_front': True}]


def _wrap_html(title: str, body: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>{_esc(title)}</title>
  <style>
    body {{ font-family: Georgia, serif; max-width: 900px; margin: 2em auto; padding: 0 1em; line-height: 1.6; }}
    img  {{ max-width: 100%; height: auto; }}
    table.xlsx-table {{ border-collapse: collapse; width: 100%; font-size: .9em; }}
    table.xlsx-table th, table.xlsx-table td {{ border: 1px solid #ccc; padding: .35em .6em; }}
    table.xlsx-table th {{ background: #eee; font-weight: bold; }}
  </style>
</head>
<body>
{body}
</body>
</html>"""


def _esc(v) -> str:
    if v is None: return ''
    return str(v).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')


def _safe(name: str) -> str:
    return re.sub(r'[^\w\-]', '_', name)[:80]
