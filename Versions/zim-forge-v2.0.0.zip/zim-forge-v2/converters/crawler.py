"""
converters/crawler.py
Crawls a URL to a specified depth and returns HTML page dicts for ZIM packing.
"""

import re
import time
from pathlib import Path
from urllib.parse import urljoin, urlparse, urlunparse

import requests
from bs4 import BeautifulSoup


def crawl_url(start_url: str, out_dir: Path, opts: dict) -> list:
    depth       = max(1, int(opts.get('depth', 1)))
    same_domain = bool(opts.get('same_domain', True))
    include_re  = opts.get('include_re', '')
    exclude_re  = opts.get('exclude_re', '')
    delay       = float(opts.get('delay', 0.5))
    ua          = opts.get('user_agent', 'ZIMForge/1.0')

    inc_pat = re.compile(include_re) if include_re else None
    exc_pat = re.compile(exclude_re) if exclude_re else None

    base_domain = urlparse(start_url).netloc
    session = requests.Session()
    session.headers.update({'User-Agent': ua})

    visited   = {}
    queue     = [(start_url, 0)]
    seen_urls = {_normalize(start_url)}

    while queue:
        url, current_depth = queue.pop(0)
        if current_depth > depth or _normalize(url) in visited:
            continue
        try:
            resp = session.get(url, timeout=20, allow_redirects=True)
            resp.raise_for_status()
        except Exception:
            visited[_normalize(url)] = None
            continue

        ct = resp.headers.get('content-type', '')
        if 'html' not in ct:
            visited[_normalize(url)] = None
            continue

        soup = BeautifulSoup(resp.text, 'html.parser')
        title_tag = soup.find('title')
        title = title_tag.get_text(strip=True) if title_tag else url
        zim_path = _url_to_zim_path(url, base_domain)
        html_rewritten = _rewrite_links(soup, url, base_domain, same_domain)

        visited[_normalize(url)] = {
            'zim_path': zim_path, 'title': title,
            'content': html_rewritten, 'mimetype': 'text/html',
            'is_front': len(visited) == 0, 'source_url': url,
        }

        if current_depth < depth:
            for link in soup.find_all('a', href=True):
                abs_url = _normalize(urljoin(url, link['href'].strip()))
                if not abs_url.startswith('http') or abs_url in seen_urls:
                    continue
                if same_domain and urlparse(abs_url).netloc != base_domain:
                    continue
                if inc_pat and not inc_pat.search(abs_url):
                    continue
                if exc_pat and exc_pat.search(abs_url):
                    continue
                seen_urls.add(abs_url)
                queue.append((abs_url, current_depth + 1))

        if delay > 0:
            time.sleep(delay)

    return [v for v in visited.values() if v is not None]


def _normalize(url: str) -> str:
    p = urlparse(url)
    return urlunparse(p._replace(fragment='')).rstrip('/')


def _url_to_zim_path(url: str, base_domain: str) -> str:
    parsed = urlparse(url)
    path = re.sub(r'[^\w/\-\.]', '_', parsed.path.strip('/') or 'index')
    if not path.endswith('.html'):
        path += '.html'
    return f"web/{parsed.netloc}/{path}"


def _rewrite_links(soup, base_url: str, base_domain: str, same_domain: bool) -> str:
    for tag in soup.find_all('a', href=True):
        abs_url = urljoin(base_url, tag['href'].strip())
        p = urlparse(abs_url)
        if p.scheme in ('http', 'https') and (not same_domain or p.netloc == base_domain):
            tag['href'] = '/' + _url_to_zim_path(abs_url, base_domain)
    for tag in soup.find_all('script'):
        tag.decompose()
    return str(soup)
