#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────
#  ZIM Forge — service-install.sh
#
#  Installs ZIM Forge as a systemd service so it:
#    ✓ Starts automatically on boot
#    ✓ Keeps running after you close SSH / terminal
#    ✓ Restarts itself if it ever crashes
#
#  Run ONCE after install.sh has already been run:
#      sudo bash service-install.sh
#
#  Useful commands afterwards:
#      sudo systemctl status  zim-forge   # check it's running
#      sudo systemctl stop    zim-forge   # stop it
#      sudo systemctl start   zim-forge   # start it
#      sudo systemctl restart zim-forge   # restart
#      sudo journalctl -u zim-forge -f    # live logs
# ──────────────────────────────────────────────────────────────

set -e

# ── Config ────────────────────────────────────
INSTALL_DIR="/opt/zim-forge"
SERVICE_NAME="zim-forge"
PORT="${PORT:-5000}"
RUN_AS_USER="${SUDO_USER:-$(whoami)}"   # run as the user who called sudo, not root

# ── Must be run as root ────────────────────────
if [ "$EUID" -ne 0 ]; then
    echo "❌  Please run with sudo:  sudo bash service-install.sh"
    exit 1
fi

echo ""
echo "═══════════════════════════════════════════"
echo "  ZIM Forge — Service Installer"
echo "  Installing for user: ${RUN_AS_USER}"
echo "  Install dir:         ${INSTALL_DIR}"
echo "  Port:                ${PORT}"
echo "═══════════════════════════════════════════"
echo ""

# ── Copy app to /opt if not already there ────
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ "$SOURCE_DIR" != "$INSTALL_DIR" ]; then
    echo "[1/5] Copying app to ${INSTALL_DIR}…"
    mkdir -p "$INSTALL_DIR"
    cp -r "$SOURCE_DIR"/. "$INSTALL_DIR/"
    chown -R "$RUN_AS_USER":"$RUN_AS_USER" "$INSTALL_DIR"
    echo "  ✓ Copied"
else
    echo "[1/5] Already in ${INSTALL_DIR}, skipping copy"
fi

# ── Ensure venv + deps are installed ─────────
echo "[2/5] Verifying Python venv…"
if [ ! -f "${INSTALL_DIR}/venv/bin/gunicorn" ]; then
    echo "  → venv missing or incomplete, running install…"
    cd "$INSTALL_DIR"
    sudo -u "$RUN_AS_USER" bash install.sh --no-start   # see note below
fi
echo "  ✓ venv ready"

# ── Create directories ────────────────────────
echo "[3/5] Creating data directories…"
mkdir -p "${INSTALL_DIR}/jobs" "${INSTALL_DIR}/output"
chown -R "$RUN_AS_USER":"$RUN_AS_USER" "${INSTALL_DIR}/jobs" "${INSTALL_DIR}/output"
echo "  ✓ Directories ready"

# ── Write systemd unit ────────────────────────
echo "[4/5] Writing systemd service…"

GUNICORN="${INSTALL_DIR}/venv/bin/gunicorn"

cat > "/etc/systemd/system/${SERVICE_NAME}.service" << EOF
[Unit]
Description=ZIM Forge — Kiwix Conversion Workbench
Documentation=https://github.com/you/zim-forge
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${RUN_AS_USER}
Group=${RUN_AS_USER}
WorkingDirectory=${INSTALL_DIR}
ExecStart=${GUNICORN} \\
    --bind 0.0.0.0:${PORT} \\
    --workers 2 \\
    --threads 4 \\
    --timeout 600 \\
    --access-logfile - \\
    --error-logfile - \\
    app:app
Restart=on-failure
RestartSec=10
KillMode=mixed
TimeoutStopSec=30
StandardOutput=journal
StandardError=journal
Environment=FLASK_ENV=production

[Install]
WantedBy=multi-user.target
EOF

echo "  ✓ Service file written"

# ── Enable and start ──────────────────────────
echo "[5/5] Enabling and starting service…"
systemctl daemon-reload
systemctl enable  "${SERVICE_NAME}"
systemctl restart "${SERVICE_NAME}"

sleep 2   # give it a moment to start

# ── Status check ─────────────────────────────
echo ""
if systemctl is-active --quiet "${SERVICE_NAME}"; then
    # Get local IP for convenience
    LOCAL_IP=$(hostname -I | awk '{print $1}')
    echo "═══════════════════════════════════════════"
    echo "  ✓  ZIM Forge is running!"
    echo ""
    echo "  Open from ANY device on your network:"
    echo "  ➜  http://${LOCAL_IP}:${PORT}"
    echo ""
    echo "  It will now start automatically on boot."
    echo "  You can safely close this terminal."
    echo ""
    echo "  Manage the service:"
    echo "    sudo systemctl status  zim-forge"
    echo "    sudo systemctl stop    zim-forge"
    echo "    sudo systemctl restart zim-forge"
    echo "    sudo journalctl -u zim-forge -f    ← live logs"
    echo "═══════════════════════════════════════════"
else
    echo "═══════════════════════════════════════════"
    echo "  ⚠  Service may not have started cleanly."
    echo "  Check logs with:"
    echo "    sudo journalctl -u zim-forge -n 50"
    echo "═══════════════════════════════════════════"
    systemctl status "${SERVICE_NAME}" --no-pager || true
fi
