# ZIM Forge

**Web-based document & website → ZIM converter for Kiwix**

Convert `.docx`, `.doc`, `.pdf`, `.xlsx`, `.html` files and crawl entire websites to `.zim` archives — accessible from any device on your network.

---

## Features

| Input | Method |
|-------|--------|
| `.docx` | mammoth (faithful HTML conversion) |
| `.doc` | LibreOffice headless |
| `.pdf` | pdfminer.six (per-page HTML) |
| `.xlsx` / `.xls` | openpyxl (per-sheet HTML tables) |
| `.html` / `.htm` | passthrough |
| URL / website | requests + BeautifulSoup crawler |

**Crawl options:**
- Configurable depth (1–10+)
- Same-domain restriction toggle
- Include / exclude regex URL filters
- Adjustable request delay
- Custom User-Agent string

**ZIM metadata:** title, description, language (ISO 639-3), creator, publisher, output filename

**Job management:** live progress bars, log streams, one-click download — all visible from any browser on your network

---

## Quick Start

### Option A — Bare metal (Raspberry Pi / Debian / Ubuntu)

```bash
git clone https://github.com/you/zim-forge.git
cd zim-forge
chmod +x install.sh
./install.sh
```

Server starts at **http://0.0.0.0:5000** — open from any device on your LAN.

Custom port:
```bash
PORT=8888 ./install.sh
```

### Option B — Docker (recommended for clean deployment)

```bash
docker compose up -d
```

- **ZIM Forge** → http://yourhost:5000
- **Kiwix Serve** → http://yourhost:8080

Converted `.zim` files appear automatically in Kiwix Serve (shared volume).

### Option C — Manual Python

```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
pip install libzim   # optional but preferred
mkdir -p jobs output
python app.py
```

---

## ZIM Backend Priority

ZIM Forge tries backends in this order:

1. **python-libzim** — pure Python, best integration. Requires `libzim` system library (`apt install libzim-dev`).
2. **zimwriterfs** — command-line tool fallback (`apt install zimwriterfs` or Kiwix Tools snap).

At least one must be available. The installer handles this automatically.

---

## System Requirements

| Component | Minimum |
|-----------|---------|
| RAM | 512 MB (2 GB recommended for large PDFs) |
| Disk | Depends on source material |
| Python | 3.9+ |
| LibreOffice | Required only for `.doc` conversion |

---

## Project Structure

```
zim-forge/
├── app.py                 ← Flask server, job management
├── zim_builder.py         ← .zim creation (libzim / zimwriterfs)
├── converters/
│   ├── document.py        ← file converters
│   └── crawler.py         ← URL crawler
├── templates/
│   └── index.html         ← full web UI
├── jobs/                  ← temp scratch space (auto-created)
├── output/                ← finished .zim files (auto-created)
├── requirements.txt
├── install.sh
├── Dockerfile
└── docker-compose.yml
```

---

## API

The Flask backend exposes a simple REST API if you want to integrate:

```
POST /api/convert          — submit a job (multipart/form-data)
GET  /api/jobs             — list all jobs
GET  /api/jobs/<id>        — get job status + log
DELETE /api/jobs/<id>      — remove job + output file
GET  /output/<filename>    — download ZIM
```

---

## Notes

- Large PDFs with many pages may take several minutes; progress is streamed live.
- Website crawling respects `crawl_delay` to avoid hammering servers.
- ZIM files are stored in `output/` indefinitely; use the Remove button or clean up manually.
- Run behind a reverse proxy (nginx/Caddy) if exposing beyond your LAN.
