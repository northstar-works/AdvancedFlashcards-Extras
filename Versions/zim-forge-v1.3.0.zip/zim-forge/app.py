"""
ZIM Forge — Web-based document-to-ZIM converter for Kiwix
"""

import io
import os
import uuid
import json
import threading
import shutil
import subprocess
import time
from pathlib import Path
from flask import Flask, request, jsonify, send_file, render_template, send_from_directory, Response

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB
app.config['UPLOAD_FOLDER'] = Path('jobs')
app.config['OUTPUT_FOLDER'] = Path('output')

ALLOWED_EXTENSIONS = {'.doc', '.docx', '.pdf', '.xlsx', '.xls', '.html', '.htm'}

# In-memory job registry
jobs = {}
jobs_lock = threading.Lock()


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def allowed_file(filename):
    return Path(filename).suffix.lower() in ALLOWED_EXTENSIONS


def update_job(job_id, **kwargs):
    with jobs_lock:
        jobs[job_id].update(kwargs)


def log_job(job_id, message):
    ts = time.strftime('%H:%M:%S')
    with jobs_lock:
        jobs[job_id]['log'].append(f"[{ts}] {message}")


# ─────────────────────────────────────────────
# Routes — UI
# ─────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/output/<path:filename>')
def download_output(filename):
    return send_from_directory(app.config['OUTPUT_FOLDER'], filename, as_attachment=True)


# ─────────────────────────────────────────────
# Routes — Logs
# ─────────────────────────────────────────────

@app.route('/api/jobs/<job_id>/log')
def download_job_log(job_id):
    """Download full job log as a .txt file."""
    with jobs_lock:
        job = jobs.get(job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404

    meta  = job.get('meta', {})
    lines = [
        f"ZIM Forge — Job Log",
        f"===================",
        f"Job ID   : {job_id}",
        f"Title    : {meta.get('title', '?')}",
        f"Status   : {job.get('status', '?')}",
        f"Progress : {job.get('progress', 0)}%",
        f"Created  : {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(job.get('created_at', 0)))}",
        f"Files    : {', '.join(Path(f).name for f in job.get('files', [])) or 'none'}",
        f"URLs     : {', '.join(job.get('urls', [])) or 'none'}",
        f"",
        f"--- Conversion Log ---",
        "",
    ]
    lines += job.get('log', [])

    if job.get('error'):
        lines += ["", "--- Error Detail ---", job['error']]

    content = '\n'.join(lines)
    buf = io.BytesIO(content.encode('utf-8'))
    safe_title = ''.join(c if c.isalnum() or c in '-_' else '_' for c in meta.get('title', job_id))[:40]
    filename = f"zimforge_{safe_title}_{job_id[:8]}.log"

    return send_file(buf, mimetype='text/plain', as_attachment=True, download_name=filename)


@app.route('/api/system/log')
def download_system_log():
    """
    Download the systemd journal for zim-forge service + last 200 lines of
    gunicorn stderr. Falls back gracefully if not running under systemd.
    """
    lines = [
        "ZIM Forge — System / Server Log",
        "================================",
        f"Generated : {time.strftime('%Y-%m-%d %H:%M:%S')}",
        "",
    ]

    # ── journalctl (systemd) ──
    lines.append("=== systemd journal (zim-forge.service) ===")
    try:
        r = subprocess.run(
            ['journalctl', '-u', 'zim-forge', '-n', '300', '--no-pager', '--output=short-iso'],
            capture_output=True, text=True, timeout=10
        )
        lines.append(r.stdout if r.stdout.strip() else "(no journal entries)")
        if r.stderr.strip():
            lines.append(f"[journalctl stderr]: {r.stderr.strip()}")
    except FileNotFoundError:
        lines.append("(journalctl not available — not running under systemd)")
    except Exception as e:
        lines.append(f"(journalctl error: {e})")

    # ── zimwriterfs version ──
    lines += ["", "=== zimwriterfs version ==="]
    try:
        r = subprocess.run(['zimwriterfs', '--version'], capture_output=True, text=True, timeout=5)
        lines.append(r.stdout.strip() or r.stderr.strip() or "(no output)")
    except FileNotFoundError:
        lines.append("zimwriterfs not found in PATH")
    except Exception as e:
        lines.append(f"Error: {e}")

    # ── python-libzim availability ──
    lines += ["", "=== python-libzim ==="]
    try:
        import libzim
        lines.append(f"Available — version: {getattr(libzim, '__version__', 'unknown')}")
    except ImportError:
        lines.append("Not installed (will use zimwriterfs fallback)")

    # ── All active jobs summary ──
    lines += ["", "=== Active Jobs ==="]
    with jobs_lock:
        all_jobs = list(jobs.values())
    if all_jobs:
        for j in all_jobs:
            lines.append(f"  [{j['status']:8s}] {j['id'][:8]}  {j.get('meta',{}).get('title','?')}")
    else:
        lines.append("  (none)")

    content = '\n'.join(lines)
    buf = io.BytesIO(content.encode('utf-8'))
    fname = f"zimforge_server_{time.strftime('%Y%m%d_%H%M%S')}.log"
    return send_file(buf, mimetype='text/plain', as_attachment=True, download_name=fname)


# ─────────────────────────────────────────────
# Routes — Job API
# ─────────────────────────────────────────────

@app.route('/api/jobs', methods=['GET'])
def list_jobs():
    with jobs_lock:
        return jsonify(list(jobs.values()))


@app.route('/api/jobs/<job_id>', methods=['GET'])
def get_job(job_id):
    with jobs_lock:
        job = jobs.get(job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404
    return jsonify(job)


@app.route('/api/jobs/<job_id>', methods=['DELETE'])
def delete_job(job_id):
    with jobs_lock:
        job = jobs.pop(job_id, None)
    if job:
        job_dir = app.config['UPLOAD_FOLDER'] / job_id
        if job_dir.exists():
            shutil.rmtree(job_dir, ignore_errors=True)
        out = app.config['OUTPUT_FOLDER'] / job.get('output_filename', '')
        if out.exists():
            out.unlink(missing_ok=True)
    return jsonify({'ok': True})


@app.route('/api/convert', methods=['POST'])
def start_conversion():
    job_id = str(uuid.uuid4())
    job_dir = app.config['UPLOAD_FOLDER'] / job_id
    job_dir.mkdir(parents=True, exist_ok=True)

    uploaded_files = []
    for f in request.files.getlist('files[]'):
        if f and f.filename and allowed_file(f.filename):
            dest = job_dir / f.filename
            f.save(str(dest))
            uploaded_files.append(str(dest))

    urls_raw = request.form.get('urls', '').strip()
    urls = [u.strip() for u in urls_raw.splitlines() if u.strip()]

    if not uploaded_files and not urls:
        shutil.rmtree(job_dir, ignore_errors=True)
        return jsonify({'error': 'No files or URLs provided'}), 400

    meta = {
        'title':       request.form.get('zim_title', 'ZIM Forge Export'),
        'description': request.form.get('zim_description', ''),
        'language':    request.form.get('zim_language', 'eng'),
        'creator':     request.form.get('zim_creator', 'ZIM Forge'),
        'publisher':   request.form.get('zim_publisher', 'ZIM Forge'),
    }

    crawl_opts = {
        'depth':       int(request.form.get('crawl_depth', 1)),
        'same_domain': request.form.get('crawl_same_domain', 'true').lower() == 'true',
        'include_re':  request.form.get('include_pattern', ''),
        'exclude_re':  request.form.get('exclude_pattern', ''),
        'delay':       float(request.form.get('crawl_delay', 0.5)),
        'user_agent':  request.form.get('user_agent', 'ZIMForge/1.0 (Kiwix archiver)'),
    }

    output_stem = request.form.get('output_name', '').strip() or meta['title'].replace(' ', '_')
    output_filename = output_stem + '.zim'

    job = {
        'id':              job_id,
        'status':          'queued',
        'progress':        0,
        'log':             [],
        'meta':            meta,
        'files':           uploaded_files,
        'urls':            urls,
        'crawl_opts':      crawl_opts,
        'output_filename': output_filename,
        'created_at':      time.time(),
        'error':           None,
    }

    with jobs_lock:
        jobs[job_id] = job

    t = threading.Thread(target=run_job, args=(job_id,), daemon=True)
    t.start()

    return jsonify({'job_id': job_id})


# ─────────────────────────────────────────────
# Background worker
# ─────────────────────────────────────────────

def run_job(job_id):
    from converters.document import convert_file
    from converters.crawler import crawl_url
    from zim_builder import build_zim

    with jobs_lock:
        job = jobs[job_id]

    job_dir  = app.config['UPLOAD_FOLDER'] / job_id
    html_dir = job_dir / 'html'
    html_dir.mkdir(exist_ok=True)
    out_dir  = app.config['OUTPUT_FOLDER']
    out_dir.mkdir(exist_ok=True)

    update_job(job_id, status='running', progress=5)
    html_pages = []
    files = job['files']
    total_sources = len(files) + len(job['urls'])
    done = 0

    for filepath in files:
        log_job(job_id, f"Converting file: {Path(filepath).name}")
        try:
            pages = convert_file(filepath, html_dir)
            html_pages.extend(pages)
            log_job(job_id, f"  → {len(pages)} page(s) from {Path(filepath).name}")
        except Exception as e:
            log_job(job_id, f"  ✗ Error: {e}")
        done += 1
        update_job(job_id, progress=5 + int(50 * done / max(total_sources, 1)))

    crawl_opts = job['crawl_opts']
    for url in job['urls']:
        log_job(job_id, f"Crawling: {url}")
        try:
            pages = crawl_url(url, html_dir, crawl_opts)
            html_pages.extend(pages)
            log_job(job_id, f"  → {len(pages)} page(s) crawled")
        except Exception as e:
            log_job(job_id, f"  ✗ Crawl error: {e}")
        done += 1
        update_job(job_id, progress=5 + int(50 * done / max(total_sources, 1)))

    if not html_pages:
        update_job(job_id, status='failed', error='No content was converted or crawled.')
        return

    log_job(job_id, f"Total pages: {len(html_pages)}")
    update_job(job_id, progress=60)

    log_job(job_id, "Building ZIM archive…")
    out_path = out_dir / job['output_filename']
    try:
        build_zim(
            pages=html_pages,
            output_path=str(out_path),
            meta=job['meta'],
            progress_cb=lambda p: update_job(job_id, progress=60 + int(35 * p))
        )
        log_job(job_id, f"✓ ZIM created: {out_path.name}")
        size = out_path.stat().st_size
        update_job(job_id, status='done', progress=100,
                   output_filename=job['output_filename'], output_size=size)
    except Exception as e:
        log_job(job_id, f"✗ ZIM build failed: {e}")
        update_job(job_id, status='failed', error=str(e))


if __name__ == '__main__':
    Path('jobs').mkdir(exist_ok=True)
    Path('output').mkdir(exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=False)
