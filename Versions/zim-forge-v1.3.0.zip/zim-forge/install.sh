#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────
#  ZIM Forge — install.sh
#  Installs system deps + Python packages, then starts the server
#  Tested on: Debian 11/12, Ubuntu 22.04/24.04, Raspberry Pi OS
# ──────────────────────────────────────────────────────────────

set -e

PYTHON=${PYTHON:-python3}
PORT=${PORT:-5000}
HOST=${HOST:-0.0.0.0}
NO_START=false

# Check for --no-start flag (used by service-install.sh)
for arg in "$@"; do
    [ "$arg" = "--no-start" ] && NO_START=true
done

echo "═══════════════════════════════════════════"
echo "  ZIM Forge — Installer"
echo "═══════════════════════════════════════════"
echo ""

# ── System packages ──────────────────────────
echo "[1/4] Installing system packages…"
sudo apt-get update -qq
sudo apt-get install -y -qq \
    python3 python3-pip python3-venv \
    libreoffice-core libreoffice-writer libreoffice-calc \
    libmagic1 \
    zimwriterfs \
    libzim-dev \
    curl wget 2>/dev/null || true

# zimwriterfs may be in a different package on older distros
if ! command -v zimwriterfs &>/dev/null; then
    echo "  ⚠ zimwriterfs not found via apt — trying snap…"
    sudo snap install kiwix-tools 2>/dev/null || true
fi

echo "  ✓ System packages done"

# ── Python virtual env ────────────────────────
echo "[2/4] Setting up Python venv…"
cd "$(dirname "$0")"

if [ ! -d venv ]; then
    $PYTHON -m venv venv
fi

source venv/bin/activate
pip install --upgrade pip -q

# ── Python packages ───────────────────────────
echo "[3/4] Installing Python packages…"
pip install -r requirements.txt -q

# Try libzim Python bindings
echo "  → Attempting python-libzim install…"
pip install libzim --quiet 2>/dev/null && \
    echo "  ✓ python-libzim installed" || \
    echo "  ℹ  python-libzim unavailable — will use zimwriterfs fallback"

# ── Create dirs ───────────────────────────────
mkdir -p jobs output

echo "[4/4] Setup complete!"

if $NO_START; then
    echo "  (--no-start: skipping server launch)"
    exit 0
fi

echo ""
echo "═══════════════════════════════════════════"
echo "  Starting ZIM Forge on http://${HOST}:${PORT}"
echo "  (accessible from any device on your network)"
echo "  TIP: run  sudo bash service-install.sh  to"
echo "       make this start automatically on boot."
echo "═══════════════════════════════════════════"
echo ""

# ── Start server ─────────────────────────────
export FLASK_APP=app.py
export FLASK_ENV=production

# Use gunicorn for production if available, else flask dev server
if command -v gunicorn &>/dev/null || pip show gunicorn &>/dev/null 2>&1; then
    pip install gunicorn -q
    exec gunicorn \
        --bind "${HOST}:${PORT}" \
        --workers 2 \
        --threads 4 \
        --timeout 600 \
        --max-requests 100 \
        app:app
else
    exec $PYTHON -m flask run --host="${HOST}" --port="${PORT}"
fi
