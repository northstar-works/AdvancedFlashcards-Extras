"""
zim_builder.py
Packs a list of HTML page dicts into a .zim archive using python-libzim.
Falls back to a directory dump + zimwriterfs if libzim is unavailable.
"""

import base64
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Callable, List, Dict, Optional

# Minimal 48x48 grey PNG — satisfies zimwriterfs --illustration requirement
_PLACEHOLDER_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAACXBIWXMAAA7EAAAOxAGVKw4b"
    "AAAAiklEQVRYhe3OMQqAMAxG4br/pXoHQSgOHVz6LxISktdBpHSw4AEOOZ7nAQAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB8AMpMAAVo0Vr3AAAAAElFTkSuQmCC"
)

# zimwriterfs hard limits (from openzim spec)
_LIMITS = {
    'title':       30,
    'description': 80,
    'name':        125,
    'creator':     30,
    'publisher':   30,
    'language':    3,
}


def _trim(value: str, field: str, fallback: str = '') -> str:
    """Return value sanitized and trimmed to field's character limit."""
    v = (value or fallback or field).strip()
    limit = _LIMITS.get(field)
    if limit and len(v) > limit:
        v = v[:limit - 1].rstrip() + '…'
    return v or fallback or field


def build_zim(
    pages: List[Dict],
    output_path: str,
    meta: Dict,
    progress_cb: Optional[Callable[[float], None]] = None,
):
    try:
        _build_with_libzim(pages, output_path, meta, progress_cb)
    except ImportError:
        _build_with_zimwriterfs(pages, output_path, meta, progress_cb)


# ─────────────────────────────────────────────
# Strategy 1: python-libzim
# ─────────────────────────────────────────────

def _build_with_libzim(pages, output_path, meta, progress_cb):
    from libzim.writer import Creator as ZimCreator, Item, StringProvider, Hints

    class PageItem(Item):
        def __init__(self, zim_path, title, content, mimetype, is_front):
            super().__init__()
            self._path     = zim_path
            self._title    = title
            self._content  = content.encode('utf-8') if isinstance(content, str) else content
            self._mimetype = mimetype
            self._front    = is_front

        def get_path(self)     -> str: return self._path
        def get_title(self)    -> str: return self._title
        def get_mimetype(self) -> str: return self._mimetype
        def get_contentprovider(self):
            data = self._content.decode('utf-8') if isinstance(self._content, bytes) else self._content
            return StringProvider(data)
        def get_hints(self) -> dict:
            return {Hints.FRONT_ARTICLE: self._front}

    zim_title     = _trim(meta.get('title', ''),       'title',     'ZIM Export')
    zim_desc      = _trim(meta.get('description', ''), 'description', zim_title)
    zim_creator   = _trim(meta.get('creator', ''),     'creator',   'ZIM Forge')
    zim_publisher = _trim(meta.get('publisher', ''),   'publisher', 'ZIM Forge')
    zim_lang      = _trim(meta.get('language', 'eng'), 'language',  'eng')
    zim_name      = _trim(re.sub(r'[^\w\-]', '_', zim_title).lower(), 'name', 'zim_export')

    main_page = next((p['zim_path'] for p in pages if p.get('is_front')), pages[0]['zim_path'])

    with ZimCreator(output_path) \
            .config_indexing(True, zim_lang) \
            .config_mainpage(main_page) as zim:

        zim.config_metadata(
            Name=zim_name,
            Title=zim_title,
            Language=zim_lang,
            Description=zim_desc,
            Creator=zim_creator,
            Publisher=zim_publisher,
        )

        total = len(pages)
        for i, page in enumerate(pages):
            zim.add_item(PageItem(
                zim_path=page['zim_path'],
                title=page['title'],
                content=page['content'],
                mimetype=page.get('mimetype', 'text/html'),
                is_front=page.get('is_front', False),
            ))
            if progress_cb and i % max(1, total // 20) == 0:
                progress_cb(i / total)

    if progress_cb:
        progress_cb(1.0)


# ─────────────────────────────────────────────
# Strategy 2: zimwriterfs fallback
# ─────────────────────────────────────────────

def _build_with_zimwriterfs(pages, output_path, meta, progress_cb):
    """Write pages to a temp directory then call zimwriterfs."""
    tmp = tempfile.mkdtemp(prefix='zimforge_')
    try:
        main_page = None
        total = len(pages)

        for i, page in enumerate(pages):
            zpath = page['zim_path'].lstrip('/')
            dest  = Path(tmp) / zpath
            dest.parent.mkdir(parents=True, exist_ok=True)
            content = page['content']
            if isinstance(content, str):
                dest.write_text(content, encoding='utf-8')
            else:
                dest.write_bytes(content)
            if page.get('is_front') and main_page is None:
                main_page = zpath
            if progress_cb:
                progress_cb(0.5 * i / max(total, 1))

        main_page = main_page or (pages[0]['zim_path'].lstrip('/') if pages else 'index.html')

        # Write placeholder 48x48 PNG — mandatory for this zimwriterfs version
        illustration_path = Path(tmp) / 'illustration.png'
        illustration_path.write_bytes(base64.b64decode(_PLACEHOLDER_PNG_B64))

        # Sanitize + trim every field to zimwriterfs spec limits
        title     = _trim(meta.get('title', ''),       'title',       'ZIM Export')
        language  = _trim(meta.get('language', 'eng'), 'language',    'eng')
        desc      = _trim(meta.get('description', ''), 'description', title)
        creator   = _trim(meta.get('creator', ''),     'creator',     'ZIM Forge')
        publisher = _trim(meta.get('publisher', ''),   'publisher',   'ZIM Forge')
        name      = _trim(re.sub(r'[^\w\-]', '_', title).lower(), 'name', 'zim_export')

        print(f"[zimwriterfs] metadata → title='{title}' desc='{desc}' name='{name}' creator='{creator}'")

        cmd = [
            'zimwriterfs',
            f'--welcome={main_page}',
            f'--illustration=illustration.png',
            f'--language={language}',
            f'--name={name}',
            f'--title={title}',
            f'--description={desc}',
            f'--creator={creator}',
            f'--publisher={publisher}',
            '--skip-libmagic-check',
            tmp,
            output_path,
        ]

        print(f"[zimwriterfs] running ({len(pages)} pages, main={main_page})")
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)

        if result.returncode != 0:
            raise RuntimeError(
                f"zimwriterfs failed:\n"
                f"  stdout: {result.stdout.strip()[:800]}\n"
                f"  stderr: {result.stderr.strip()[:800]}"
            )

        if progress_cb:
            progress_cb(1.0)

    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ─────────────────────────────────────────────
# Check what's available
# ─────────────────────────────────────────────

def check_backends() -> dict:
    backends = {'libzim': False, 'zimwriterfs': False, 'zimwriterfs_path': None}
    try:
        import libzim  # noqa
        backends['libzim'] = True
    except ImportError:
        pass
    path = shutil.which('zimwriterfs')
    if path:
        backends['zimwriterfs'] = True
        backends['zimwriterfs_path'] = path
    return backends
