# Changelog — Advanced Flashcards (Android)

All notable changes are documented here. Format: **Added / Changed / Fixed**.

---

## v7.1.0 (build 42) — 2026-02-17

### Added
- **Remote Config Push:** Admin screen → new "📱 Remote Config Push" section replaces the old single "Server URL" field.
- **Separate **Host**, **Port**, and **Server Type** (Standalone / Packaged / Raspberry Pi) fields for clarity.
- **Push to Apps** button sends config to `POST /api/sync/admin/remote-config`; all Android clients auto-discover the change on next startup/login.
- **Pull Current Config from Server** button fetches `GET /api/sync/remote-config` and populates the fields.
- **Live URL preview updates as you type.
- **`RemoteConfig` data class** (`Models.kt`): holds `serverType`, `host`, `port`, `updatedAt`, `updatedBy`; `toBaseUrl()` builds the full HTTP URL.
- **`WebAppSync.pullRemoteConfig()`**: polls `GET /api/sync/remote-config` (no auth required).
- **`WebAppSync.pushRemoteConfig()`**: pushes to `POST /api/sync/admin/remote-config` (admin Bearer token).
- **`Repository.checkAndApplyRemoteConfig()`**: called silently after each successful login; if the server returns a different host/port/type, saves the new `webAppUrl` and `serverType` to DataStore automatically.
- **`AdminSettings.serverType`** field added (persisted to DataStore); default `"standalone"`.
- **`WebAppSync.normalizeUrl()`** — ensures any URL entered by the user has `http://` prepended. Accepts bare host:port, `http://`, or `https://`. Applied in `verifyServer()`, `login()`, Save URL button, and the login flow.
- **In-app Debug Log screen** — `Admin → View Debug Log` shows a real-time log of sync events and errors with timestamps, level filter (ALL / ERR / WARN / INFO), tap-to-expand detail, and error count badge. Share icon copies the full log to clipboard.
- **`AppLog` singleton** — captures errors from Repository with full context (URL, token prefix, status code).

### Changed
- **Old "Server URL" text field in Admin screen replaced by the new Remote Config Push section. The previous `syncPushManagedServerUrl` / `syncPullServerConfig` functions remain for backwards compatibility.

### Fixed
- **Server URL missing http://** — `Verify Server` and `Login` now work when the URL is entered without a scheme (e.g. `sidscri.tplinkdns.com:8009` or `192.168.0.205:8009`). Added `WebAppSync.normalizeUrl()` which prepends `http://` automatically. Applied to `verifyServer()`, `login()`, the Save URL button, and the login flow.
- **"Not an Advanced Flashcards server" on Verify** — `VALID_SERVER_APPS` now includes the space-separated name variants (`"Advanced Flashcards WebAppServer"` etc.) that `version.json` actually returns. Previously only old camelCase names without spaces were accepted.
- **401 "Save failed: 401" on Push/Pull API keys** — server tokens are in-memory and get wiped on every RPi reboot/service restart. App now detects this, clears the stale token, marks the session expired, and shows `"⚠️ Session expired — please login again"` instead of a raw 401 error.

## v7.0.0 (build 41) — 2026-02-09 **Updated bundled Web Server to v8.7.0 (build 60)** (from v8.6.1 build 58), including:

### Added
- **Packaged support metadata:** add `webappserver_version.json` (web server core version file).
- **Version API upgrade:** `/api/version` returns `is_packaged` plus `app_*` and `web_*` fields (packaged shows both; stand-alone shows web only).
- **Packaged support version metadata:** add `webappserver_version.json` (web server core version file).
- **Version API upgrade:** `/api/version` now returns `is_packaged` plus `app_*` and `web_*` fields (packaged shows both; stand-alone shows web only).
- **Admin/System version display:** App Information shows a single **Web Server** version line for stand-alone and dual **App + Web** versions when `is_packaged: true`.
- **User dropdown version display:** mirrors stand-alone vs packaged behavior (single vs dual version lines).
- **Edit Deck modal tabs:** the deck edit button now opens a tabbed view: **Edit Deck** (existing) + **Edit Cards** (new).
- **Edit Cards management:** search / group filter / select cards for the active deck, with **Select all**, **Clear selection**, and **# Selected** counter.
- **Per‑card actions:** inline **Edit** (term / definition / pron / group) and **Remove** (soft delete → `deleted`).
- **Restore flows:** restore deleted cards from **Edit Decks → Deleted**, and also via **Restore** on cards shown when **Show deleted** is enabled in the Edit Cards list.
- **Duplicate handling prompt:** when an edit would duplicate another card term, prompt with **Add duplicate**, **Replace duplicate**, or **Cancel**.
- **Edited history:** edited cards are tracked under Deleted → **Edited**, with a **Clear edited history** action.
- **AI template bulk editor (with preview):** replaced the non-working “State‑only” tool with an **AI template** flow:
  - choose one or more fields to change (Term / Definition / Pron / Group),
  - type an instruction (example: “Make definitions state only; ‘Capital of Texas’ → ‘Texas’”),
  - see an **auto one‑example preview** immediately on the form,
  - use **Preview All** to view the full change list, then **Apply**.
- **AI generator **Instructions** box that overrides “Short answers only” when provided.
- Deck AI setting (default OFF): show example format template buttons/dropdown for Term/Definition templates.
- Deck AI setting (default ON): show a live “Example output” preview before generating when inputs are provided.

### Changed
- **Stand-alone version display:** when `is_packaged` is missing/false, Admin/System “App Information” hides the Application line and shows only Web Server version.
- **Version file lookup:** prefer `webappserver_version.json` and fall back to legacy version files when present.
- Stand-alone mode hides the **Application** line entirely when `version.json` is missing `is_packaged` or it is `false`.
- Version file lookup prefers `webappserver_version.json` and falls back to legacy filenames where present.
- Removed the non-action “dot” indicator on the deck list (active highlighting and Active text remain).
- Bulk/AI edits override any “short terms only” style toggles for the targeted field(s) during apply.
- AI Template “Field(s) to change” redesigned as a compact dropdown (Definition, Terms, Definition + Term, Pronunciation, Group).
- AI Deck Generator controls refined: Generate button spacing/size, plus Preview All + Cancel actions.
- Treat AI instructions as an explicit formatting/behavior override (client + server).

### Fixed
- **Edit Cards inline editor layout:** reformatted to match the “In Custom Set” list style (no accordion feel), with checkbox top-left, fields aligned, and Save/Cancel contained properly across mobile/desktop orientations.
- **Modal scrolling:** Edit Deck overlay now captures scroll correctly and locks background scrolling.
- **State cleanup:** search text + selections clear when the Edit Deck modal is closed/exited; search also has an **X** clear control.
- **AI Template UI:** modal now opens reliably above the Edit Deck overlay (z-index), with alerts rendered inside the Edit Cards view and auto-hiding.
- **Runtime stability:** fixed JS `await` usage inside non-async functions and corrected server-start errors introduced by endpoint indentation.
- AI Deck Generator live “Example output” preview now shows real preview output (matches the AI Template behavior).
- AI Generator instructions box no longer stays populated after leaving the AI Generator; Clear button is always visible and sits next to the Instructions field.
- Inserted example format blocks no longer add excessive blank lines.
- Instructions textarea auto-expands to fit multi-line template text.
- Leaving the AI Generator now clears Keywords and resets Max Cards to 25.
- Learned/All **List** tabs could render blank due to a JS runtime error.
- App could fail to load from a malformed `async function` declaration.
- Edit Decks Back button sizing now matches Custom Set Settings.

---

## v6.0.0 (build 40) — 2026-02-03

- **Updated bundled Web Server to v8.6.0 (build 57)** (from v8.5.1 build 54), including:

### Changed

- **Controls row rearranged:** group dropdown + All Cards on the left, search icon on the right (was reversed). Search overlay now expands from the right edge.
- **Settings icon moved to title row:** ⚙️ button now sits directly right of User:**** display in the header title row.
- **Study/Group label hidden:** "Study / Group" label text removed on mobile (≤600px) and landscape to save vertical space.
- **Landscape group sizing:** "Select group..." dropdown matches "All Cards" button sizing (both 6px 10px padding, 12px font).
- **Desktop search icon:** search bar replaced with 🔍 icon on all screen sizes; expands as overlay on click.
- **Portrait controls layout:** group dropdown auto-width on left, All Cards + 🔍 pushed right via space-between.
- **Landscape controls right-aligned:** controls row pushed to right side of screen.
- **Mobile logo inline:** deck logo displays inline between Cards loaded and User line instead of overlapping.
- **CSS selector fix:** corrected `.selectBtn` → `.select` to match actual HTML class on group dropdown button.
- **Removed stale `.rightControls`:** cleaned up all references to the removed rightControls div from CSS.
- **AI generation context-aware:** AI no longer assumes foreign language vocabulary when generating cards. Determines subject from keywords literally — "fast food chains types of food" produces menu items, not Spanish food words. Complex topics (science, etc.) get full definitions; simple ones get concise answers.
- **Add Card pre-selects active deck:** Target Deck dropdown in "Add Cards" tab now defaults to the deck you're currently studying instead of always defaulting to Kenpo Vocabulary.
- **Custom Set counts reflect custom status:** when studying a Custom Set, the Unlearned/Unsure/Learned counts line now shows the custom set's own card statuses instead of main deck statuses.
- **Random card input narrower:** "Pick random cards to add" number field reduced to prevent overlapping the label text and Add Random button; max value increased to 9999.
- **Admin User Deck Access simplified:** removed Disable/Enable Built-In for User buttons and built-in status badge. The Allow/Deny buttons now handle all access control. Status line shows clear "Access: Granted" or "Access: Not granted" for all deck types including built-in decks.
- **Allow/Deny preserves dropdowns:** clicking Allow or Deny no longer triggers a full config reload that resets the user and deck dropdowns, enabling bulk access changes without reselecting.
- **Non-admin built-in editing off by default:** `allowNonAdminDeckEdits` now defaults to `false` in both backend config and admin UI checkbox. Label text changed from "Allow non-admins to edit built-in/unlocked decks" to "Allow non-admins to edit built-in decks".
- **Deck Ownership blank state:** "Current owner" line is now hidden when no deck is selected, and shows "No owner assigned" when a deck has no owner ID instead of displaying raw IDs.
- **Portrait card layout overhaul:** card height increased from 260px to 320px (280px on ≤400px screens). Card text enlarged to 26px (22px small screens). Card face now scrollable for long breakdown content that overflows.
- **Status line inline with Card counter:** "All (flat) • Studying: X" text now appears on the same line as "Card 1 / 10" in portrait and landscape, replacing the separate header status line on mobile.
- **Landscape controls compact:** group dropdown, All Cards, and search icon reduced to 11px font with 4px padding for minimal space usage.
- **Faster initial load after login: settings + decks now load in parallel; counts + cards load in parallel during refresh (reduced sequential network calls from 6 to 4).
- **Portrait Study action row stabilized:** Prev / Speak / Custom / Next are forced onto a single edge-to-edge row in portrait, with Next staying aligned to the right of Custom (no wrapping).
- **Breakdown button relocated (portrait):** breakdown action moved to the header next to the search icon to reduce control crowding on mobile.
- **Portrait alignment tweaks:** reduced card-area side padding to the left edge in portrait and aligned the status hint line to the left edge. Replaced the "Only Admin (...)" hint line with a compact **"Custom > Status"** hint in portrait.
- **Confirmation visuals standardized:** **✓** for success, **✖** for error. Admin confirmations auto-clear after a few seconds.
- **Custom Set study label shows filter mode:** status bar now shows "Studying: Unlearned/Unsure/Learned" instead of "Studying: Custom Set" when studying a Custom Set.

### Fixed (Admin Dashboard)

- **Edit User deck access API:** fixed URL mismatch (`/api/admin/user/deck_access?user_id=` → `/api/admin/user/<id>/deck-access`). Edit User modal now loads deck access correctly.
- **Edit User field name mismatch:** JS used `userDecks`/`grantedAdminDeckIds` but backend returns `ownedDecks`/`grantedAdminDecks`.
- **Owned decks show 0 cards:** backend now includes `cardCount` in deck-access endpoint response.
- **Edit User modal wider:** max-width increased from 700px to 900px; deck columns min-width 300px.
- **Edit User deck access read-only:** removed checkboxes; shows Granted/Not granted text synced with Admin > Decks status. Manage link directs to Admin > Decks > User Deck Access.
- **renderBuiltInDecks syntax:** fixed nested function causing potential JS errors.
- **Custom Set Manage Cards / Saved Sets tabs blank:** tabs appeared empty because the `.hidden` class (with `!important`) was never removed during tab switching, overriding `.csTabContent.active`. Now properly toggles both classes.
- **Admin logs empty on fresh start:** logs were purely in-memory and lost on restart. Now backed by files that persist.
- **Breakdown text overflow in portrait:** card faces now have `overflow-y: auto`, so long term breakdowns scroll instead of clipping or overlapping control buttons.
- **Built-in status showing incorrectly:** previously showed "✓ Built-in active" even when the deck wasn't built-in or was disabled for the user. Removed entirely in favor of the simplified access status.
- **Custom Sets and Saved Sets are now **deck-scoped** (no cross-deck leakage when switching decks).
- Custom Set Study view uses only the active deck's Custom Set (star tab no longer affects other deck lists).
- **Custom-marked cards now appear in Custom Set:** starred/custom cards are correctly aggregated and shown inside Custom Set, including across decks the user can access.
- **Custom Set random count input overlap fixed:** `.csRandomInput` now overrides the global `input{min-width:280px}` rule using `min-width: auto !important;` so it stays at 52px.
- **Manage Cards lists taller:** increased `.csCardList` height to show more cards (desktop and portrait).
- **Manage Cards action buttons relocated:** "Select All", "Set Learned", "Set Unsure", "Clear All", and "Remove" now live inside each expanded accordion pane (instead of a global bottom action bar).
- **Buttons compact + responsive:** removed the "Mark In-" prefix, reduced button sizing/text to match the tab typography, and made the layout adapt per screen size (portrait uses a 2-row wrap; landscape keeps actions on one row with Remove pinned right).
- **Checkbox position standardized:** selection checkboxes are placed to the **left of the term** across all orientations/devices; status badges (e.g., **U**) remain on the far right.
- **Safe text wrapping:** long terms/definitions wrap before controls and rows expand in height as needed (no overlap with checkbox/badge).
- **Landscape list viewport increased:** expanded list height so ~5 cards are visible at a time while scrolling.
- **Landscape pane width refined:** accordion pane width reduced (approx. 85% of available width) for a cleaner, less edge-to-edge look.
- **Custom Set Settings Back button resized:** reduced to ~50% size on mobile to better match the page scale.
- **Breakdown save closes modal:** saving a breakdown now closes the breakdown window/modal instead of leaving it open.
- **Custom Set → Manage Cards responsive layout:** prevented overflow/misalignment on smaller screens by overriding global input min-width and stacking the two panes on narrow widths.
- **Admin confirmations auto-clear:** "Access granted/denied" and "Deck transferred" messages now disappear after a few seconds and do not persist when changing the selected user/deck.
- **Correct icons for errors:** "Access denied" (and other error confirmations) now use **✖** instead of **✓**.
- **Custom Set counts showing 0/0/0:** backend API now returns `counts` object with `active/unsure/learned/total` breakdown so the counts line displays real numbers.
- **Settings tab empty on first open:** Custom Set Settings tab was blank when opening because `hidden` class was not removed (only `active` was added). Now properly removes both.
- **Custom Set modal overflow on mobile:** converted from modal overlay (which used `display:grid; place-items:center` causing clipping) to a full-page scrollable view inside `<main>`, eliminating horizontal/vertical overflow.
- **Landscape accordion not triggering:** `max-width: 720px` media query missed landscape phones (where width is the long edge, ~800px+). Now uses `(max-width: 720px) OR (orientation: landscape AND max-height: 500px)`. Added matching CSS landscape rules for pane stacking and card list height capping.

---

### Added (Admin Dashboard)

- **Allow/Deny buttons:** replaced Unlock/Lock buttons with Allow/Deny + static "Access" label in User Deck Access section.
- **Live access status indicators:** selecting user + deck shows current access state (Granted/Not granted, Built-in Active/Disabled, Owned).
- **Built-in status badge:** shows ⛔ or ✓ next to Disable/Enable Built-In buttons.
- **Deck Ownership section:** new Admin > Decks > Deck Ownership panel to transfer deck ownership between users with confirmation.
- **`/api/admin/deck-ownership` endpoint:** transfers deck cards and metadata to new owner.
- **`/api/admin/user-deck-status` endpoint:** returns access status for user+deck combination.
- **File-based logging system:** server.log, error.log, and user_activity.log now write to disk in the logs directory, persisting across server restarts.
- **Log rotation on startup:** server.log and error.log are automatically rotated on each server start (previous saved as .prev); user_activity.log is continuous unless manually cleared (saved to .prev before clearing).
- **Log download endpoint:** `/api/admin/logs/download` serves log files for download; returns 204 if file is empty (download button disabled for empty logs).
- **Expandable admin stat tiles:** clicking any stat card (Users, Cards, Decks, Breakdowns, Learned, Unsure, Unlearned) expands a detail panel showing per-user and per-item breakdowns. Collapse by clicking again.
- **Deck Short Answers mode:** new per-deck toggle (`⚙️ Deck AI Settings` section in AI Generator tab) that forces AI-generated definitions to 1-4 words. Ideal for capitals, translations, simple vocabulary. Setting persists via `/api/decks/<id>/settings`.
- **Deck settings API:** `GET/POST /api/decks/<deck_id>/settings` for per-deck configuration (currently: shortAnswers).
- **Settings → Display: **Show UI error log** toggle (default OFF). When enabled, JS/UI errors appear in an on-screen log panel.
- **Custom Set Settings full-page view:** Custom Set Settings converted from a modal overlay to a scrollable full-page view (same pattern as Edit Decks), eliminating mobile overflow/clipping issues.
- **Manage Cards collapsible panes:** In Custom Set → Manage Cards, both "In Custom Set" and "Available Cards" panes are collapsible (collapsed by default) on mobile in portrait **and** landscape. Accordion detection uses dual media queries to correctly detect landscape phones (where screen width exceeds 720px but height is under 500px).

---

## 5.6.0 (build 39) — 2026-01-31

### Fixed — Admin Access + AI Definitions + Server Verification

- **Admin access bug fixed**: Admin screen now uses BOTH server-sourced `isAdmin` AND local `AdminUsers.isAdmin()` fallback. Previously, if the server restarted (clearing in-memory tokens), the admin would be locked out even though they're in the admin list. `refreshAdminStatus()` now gracefully falls back to the local admin list when the server is unreachable or tokens are expired.

- **Keywords no longer required for deck creation**: When AI Search is selected, keywords field is now optional. If left blank, the deck name and/or description are used as the AI search terms instead. Label changed from "Search Keywords *" to "Search Keywords (optional)".

- **Description auto-fills with deck name**: When creating a new deck with an empty description, it now auto-fills with the deck name instead of "Created from AI search".

- **AI description generation in Edit Deck dialog**: Added "AI Generate Description" button that uses AI to create a brief deck description from the deck name. Only shown when AI access is configured.

- **Concise definitions by default**: AI-generated definitions are now SHORT and LITERAL by default (e.g., "Goodbye" not "A way to say goodbye"; "Texas" not "Capital city of Texas"). The prompt explicitly instructs the AI to produce 1-5 word definitions.

- **Per-deck "Descriptive Definitions" toggle**: New toggle in Edit Deck dialog under "Deck Settings". When enabled, AI generates longer explanatory definitions (1-2 sentences) for that specific deck. Default is OFF (concise mode). Stored per-deck in `descriptiveDefinitions` field.

- **Server verification on sync/login**: Before logging in, the app now calls `/api/version` on the target server and verifies the `app_name` matches a known Advanced Flashcards server. Prevents connecting to random services.

- **Verify Server button**: Admin users see a "Verify Server" button next to the server URL field that tests the connection and shows the server name, version, and install type.

### Changed
- `AiGenerationHelper.searchAndGenerateTerms()` now accepts `descriptive: Boolean` parameter
- `AiGenerationHelper.generateDefinitions()` now accepts `descriptive: Boolean` parameter
- New `AiGenerationHelper.generateDescription()` function for AI deck descriptions
- `StudyDeck` model now includes `descriptiveDefinitions: Boolean` field
- `Store.updateDeck()` and `Repository.updateDeck()` accept optional `descriptiveDefinitions` parameter
- `WebAppSync.verifyServer()` new function for server identity verification
- `WebAppSync.login()` now verifies server before attempting login
- Login screen server URL section redesigned with side-by-side Verify/Save buttons

---

## 5.5.0 (build 38) — 2026-01-31

### Added — Feature Parity with WebServer v8.4.0

- **Deck Editing**: Edit deck name and description directly on Android
  - New Edit button (pencil icon) on each user-created deck
  - Edit Deck dialog with name/description fields
  - Changes sync automatically to server when logged in
  - `WebAppSync.updateDeck()` calls `POST /api/decks/{id}`

- **Set Default Deck**: Set/clear default deck on Android
  - Star button toggles default status for user-created decks
  - Yellow star indicates current default deck
  - `WebAppSync.setDefaultDeck()` calls `POST /api/decks/{id}/set_default`
  - `WebAppSync.clearDefaultDeck()` calls `POST /api/decks/{id}/clear_default`

- **User Card Deletion Sync**: Deleting user cards now syncs to server
  - `WebAppSync.deleteUserCard()` calls `DELETE /api/sync/user_cards/{id}`
  - Local deletion happens first, server sync follows

### Changed
- Repository methods now handle server sync automatically when logged in
- Deck management methods return success/failure status for error handling
- Store.kt now has `updateDeck()`, `setDefaultDeck()`, and `clearDefaultDeck()` methods

### Technical Notes
- Feature sync analysis tool created: `sync_android_to_webserver.py`
- Comprehensive feature comparison document generated
- All deck management API endpoints now implemented in WebAppSync.kt

---

## 5.4.0 (build 37) — 2026-01-28

### Added — GEN8 Deck Access + Invite Codes
- **Invite code redemption**: Users can unlock decks by entering an invite code in **Edit Decks → Switch** (calls `POST /api/sync/redeem-invite-code`).
- **Per-deck logos support**: Android deck model now supports `logoPath` so deck icons/logos match the WebApp “Switch Study Subject” experience.
- **Admin Deck Access controls (Option 1+)**: Admin screen now includes a **Deck Admin (Server)** section to:
  - View/update deck access config (calls `GET/POST /api/sync/admin/deck-config`).
  - Generate/delete invite codes (calls `POST /api/sync/admin/deck-invite-code`, `DELETE /api/sync/admin/deck-invite-code/<code>`).
  - Quick link to open Web Admin dashboard (`/admin`).
- **Deck Admin (Server)** section (admin-only):
  - View/edit/save server deck config (built-in decks + related toggles).
  - Generate deck invite codes.
  - Button to open the full Web Admin page in a browser.
- **Server-sourced admin state** stored in app settings (`isAdmin`) via `/api/admin/status`.
- Deck model supports optional `logoPath` from the server.

### Changed
- After redeeming a code, the app performs an **authoritative deck pull** and updates available deck list.
- Admin visibility is based on the server’s admin truth (token-based), not local assumptions.
- Version bump to align with WebServer GEN8 deck-access generation.

### Fixed — Branding + Build Stability
- **Rebranding sweep**: Updated user-facing text and theme naming to **Advanced Flashcards** throughout the app **except** for the built-in **Kenpo Vocabulary** deck name/content.
- **Release compile reliability**: Fixed invalid multiline `Text("...")` strings that could break `:app:compileReleaseKotlin` during CI/local builds.
- **Admin UI stability**: Fixed missing `context` reference in Admin UI by using `LocalContext.current` where needed.


---

## 5.3.1 (build 36) — 2026-01-26

### Changed
- Changed icons and logos to Advanced Flashcards branding

---

## 5.3.0 (build 35) — 2026-01-24

### Added — Web Server Sync Integration
- **Deck Sync**: Pull and push custom decks to/from web server
  - `WebAppSync.pullDecks()` - Download decks from server
  - `WebAppSync.pushDecks()` - Upload decks to server
- **User Cards Sync**: Pull and push user-created flashcards
  - `WebAppSync.pullUserCards()` - Download user cards from server
  - `WebAppSync.pushUserCards()` - Upload user cards to server
- **Vocabulary Sync**: Pull canonical kenpo_words.json from server
  - `WebAppSync.pullVocabulary()` - Download built-in vocabulary
- **Full Sync Methods**: Sync everything at once
  - `Repository.syncPullAll()` - Pull decks, cards, and progress
  - `Repository.syncPushAll()` - Push decks, cards, and progress

### Changed
- Web server is now the canonical source for kenpo_words.json
- Decks created on web can be synced to Android and vice versa
- User cards are now sharable between web and Android

### Technical
- Added `DeckSyncResult`, `UserCardsSyncResult`, `VocabularySyncResult` data classes
- Repository now has deck and user card sync integration
- Server URL for vocabulary: `/api/vocabulary`
- Server URL for deck sync: `/api/sync/decks`
- Server URL for user cards sync: `/api/sync/user_cards`

---

## 5.2.0 (build 34) — 2026-01-22

### Changed
- Updated server data path references in WebAppSync.kt to reflect Windows installer location:
  `C:/Program Files/Advanced Flashcards/_internal/data/`

---

## 5.1.1 (build 33) — 2026-01-20

### Fixed
- **Deck switching now works**: Added `activeCardsFlow()` in Repository that filters cards by active deck ID. Study screens now show only cards from the selected deck.
- **User-added cards appear in deck**: Fixed `allCardsFlow()` to include userCards alongside default and custom cards
- **File upload feedback**: Image and document upload now shows selected filename, checkmark confirmation, and action buttons

### Added
- **AI Features section in Settings**: When API keys are available, users can toggle "Use ChatGPT" and "Use Gemini" on/off without needing Admin access
- **AI auto-enabled on login**: When API keys are pulled from server during login, ChatGPT/Gemini are automatically enabled if keys are present

### Changed
- Study screens (To Study, Unsure, Learned, All, Custom, Deleted) now use `activeCardsFlow()` for deck filtering
- ManageDecksScreen uses `allCardsFlow()` for group suggestions across all decks

---

## 5.1.0 (build 32) — 2026-01-19

### Added — AI Generation for Card Creation
- **Generate Definition button**: Click to get 3 AI-generated definition options in dropdown
- **Generate Pronunciation button**: Click to get AI-generated phonetic pronunciation  
- **Generate Group button**: Click to get 3 AI group suggestions (considers existing groups)
- **AiGenerationHelper**: New helper class supporting both ChatGPT and Gemini APIs
- All AI buttons show loading spinner while generating

### Added — User Cards Management
- **View User Cards**: Expandable section showing all user-added cards
- **Edit User Cards**: Click edit icon to modify term, definition, pronunciation, group
- **Delete User Cards**: Click delete icon to remove user cards
- **Edit Card Dialog**: Full editing dialog with all fields

### Improved — Create Deck AI Search
- AI search now calls real API (ChatGPT/Gemini) to generate flashcard terms
- Loading spinner during search
- Better error handling and status messages

### Improved — File Upload Feedback
- Image picker now shows selected filename
- Document picker now shows selected filename
- Clear status messages about AI configuration required

### New File
- `AiGenerationHelper.kt` - Centralized AI API calls for flashcard generation

---

## 5.0.2 (build 31) — 2026-01-19

### Fixed
- **Breakdown icon**: Changed from "!" (Info) back to puzzle piece (Extension) on To Study and Unsure screens
- **Definition speak**: Custom Set and Learned > Study now properly speak definitions when flipped (matching To Study/Unsure behavior)

### Added
- **Randomize Custom Set**: Toggle in Settings > Randomization section, syncs with Custom Set's internal random setting

### Changed
- **View Deleted Cards**: Moved from Settings root to Edit Decks > Switch tab (at bottom)

---

## 5.0.1 (build 30) — 2026-01-19

### Added — Shuffle Button
- **Shuffle icon** on all study screens (To Study, Unsure, Learned Study)
- Works even when random setting is off - tap to reshuffle deck instantly
- Blue shuffle icon in header bar (both portrait and landscape)

### Added — Voice Settings
- **Auto-speak term on card change**: Automatically speaks the term when navigating to a new card
- **Speak definition when flipped**: Speaks the definition when card is flipped to back side
- New toggles in Settings > Voice section

### Changed
- Moved "Edit Decks" button above "View Deleted Cards" in Settings

### Known Issues / Planned for Next Release
- AI Generate buttons in Edit Decks need full implementation
- View/Edit/Delete user-added cards interface needed
- Image and Document upload processing for deck creation
- Custom Set shuffle/random toggle in Settings

---

## 5.0.0 (build 29) — 2026-01-18

### Added — Edit Decks Feature (Major)
New "Edit Decks" screen accessible from Settings with three tabs:

**Switch Tab:**
- View all available study decks (built-in and user-created)
- Switch between different study subjects
- See active deck with card count
- Delete user-created decks (built-in decks cannot be deleted)
- Default deck indicator (Kenpo Vocabulary)

**Add Cards Tab:**
- Manually add terms and definitions to any deck
- Select target deck from dropdown
- Optional AI-generated definitions (requires AI API)
- Optional AI-generated pronunciations
- Optional AI-generated group assignment with max groups limit
- Form validation for required fields

**Create Deck Tab:**
- Create new study decks from various sources
- Three creation methods:
  - **AI Search**: Search for terms using keywords, select from AI-generated results
  - **Upload Image**: Scan photos of study materials (AI extracts terms)
  - **Upload Document**: Process PDF, Word, Text, CSV, Excel files
- AI generates: terms, definitions, pronunciations, and groups
- Select/deselect individual terms from AI results
- Set deck name and description

### Changed
- "Manage Decks (Coming Soon)" button now active as "Edit Decks"
- Repository now includes full deck management methods

---

## 4.5.2 (build 28) — 2026-01-18

### Added
- **Auto-Sync explanation card**: Sync Progress screen now includes a clear description of auto-sync features:
  - First login always syncs automatically
  - Auto-pull on login option
  - Auto-push on change option
  - Offline changes queued and synced when online
- **Manual Sync description**: Explains Push (sends to server) and Pull (downloads from server)

### Changed
- Improved Sync Progress screen layout with better organization of auto vs manual sync info

---

## 4.5.1 (build 27) — 2026-01-18

### Fixed
- Web App Sync now uses per-card `updated_at` timestamps for conflict-free merging across devices.
- Offline progress changes are queued and pushed when online (auto-push best-effort).

### Changed
- Server and app sync payloads now use `{status, updated_at}` entries (legacy string payloads still supported).

All notable changes to this project will be documented in this file.

The format is simple and practical:
- **Added**: new user-facing features
- **Changed**: behavior changes, refactors
- **Fixed**: bug fixes
- **Security**: auth/permissions/security changes

---

## Unreleased
- (Add changes here as you work. Move them into a release when you publish.)

---

## 4.5.0 (v26) — 2026-01-16
### Added
- **Deck Management groundwork**: Data models and storage for future multi-deck support
  - `StudyDeck` model with id, name, description, isDefault, isBuiltIn flags
  - `DeckSettings` for tracking active deck selection
  - Storage methods for decks and user-created cards
  - "Manage Decks (Coming Soon)" placeholder button in Settings

### Removed
- **Import CSV button**: Replaced with future Deck Management feature
- **"Show Custom Set Button" setting**: Unnecessary setting removed

### Fixed
- **Custom Set settings dialog**: "Reflect status in Main Decks" toggle wraps properly
- **Custom Set "ALL" filter**: Shows all cards (was incorrectly filtering)
- **Custom Set status counts**: Increased height/font to prevent text cutoff
- **Custom Set Learned view**: Shows "Relearn" button instead of "Got it"

### Changed
- **API keys auto-pull on login**: Progress and API keys sync automatically
- **Push/Pull buttons restored**: Manual sync available in Sync Progress screen

---

## 4.4.4 (v24) — 2026-01-15
### Changed
- **Removed redundant top bar headers**: Learned, All Cards, and Custom screens no longer have separate TopAppBar title - header is now inline with controls (matching Unsure pattern)
- **Learned screen**: List/Study chips moved inline with "Learned List" or "Learned Study" title, search icon and group filter on right
- **All Cards screen**: Title + search icon + group filter all in single header row
- **Custom screen**: Title + Card count + search/settings/delete icons in single header row
- **Consistent UI pattern**: All screens now follow same header layout as Unsure page

---

## 4.4.3 (v23) — 2026-01-15
### Added
- **Custom Set isolated status tracking**: Custom set now has its own status (Active/Unsure/Learned) separate from main decks
- **Custom Set status filter**: Tap "Custom: ##", "Unsure: ##", "Learned: ##" to filter cards within custom set
- **"Reflect status changes in Main Decks" toggle**: Optional setting in Custom Set settings to sync status changes to main decks
- **Custom Set settings dialog**: Accessible via settings icon in Custom Set screen
- **Search X clear button**: All search fields now have an X icon to clear search text
- **Remove card confirmation**: Trash icon in Custom Set now removes only current card with confirmation dialog

### Changed
- **Custom Set "Remove" button changed to "Unsure"**: Secondary action now marks card as Unsure within custom set instead of removing
- **Landscape card height increased**: Cards fill more vertical space in landscape mode (180dp → 220dp)
- **Search text size reduced in landscape**: Prevents "Search" placeholder text from being cut off
- **Learned screen**: Removed redundant "Learned: ##" count below status row, uses search icon toggle like other screens
- **All Cards screen**: Now uses search icon toggle in portrait mode (matching To Study/Unsure pattern)
- **Custom Set portrait layout**: Shows Custom/Unsure/Learned counts in compact row, Card position inline with title

### Fixed
- **Custom Set status isolation**: Status changes in Custom Set no longer affect main deck status (unless "Reflect" setting is ON)
- **Search tap-outside behavior**: Tapping outside search field closes it but keeps filtered results

---

## 4.4.2 (v22) — 2026-01-14
### Added
- **Settings toggle to show/hide the Custom Set (⭐) button (default ON).

### Changed
- **Unsure/To Study portrait layout uses a compact header row (title + search + group filter) and removes the redundant top app bar.
- Portrait search is now icon-based (expand/collapse) like landscape; tap outside collapses search while keeping filtered results.
- Sync screen now labels admin sessions with “(Admin)” in the login status line.hat changed:
- Added a setting to show/hide the Custom Set (⭐) button (default ON).
- Unsure/To Study portrait layout: compact header row with search icon; removed redundant top bar.
- Portrait search collapses when tapping outside; search text stays so results remain filtered.
- Sync status: “(Admin)” label appears for admin logins.
- Admin badge:** if the logged-in user is an admin, the UI shows **(Admin)** after the username.
- Search UX (portrait):**
  - Portrait uses a **search icon** toggle (matches landscape).
  - Tapping outside of search **closes the search UI but keeps filtered results**.
  - Added an **X** icon to clear search and reset the deck position.
- **Random study controls:**
  - Added **Random** checkbox beside **Card #/##**.
  - Added **⟳ Reshuffle** icon to re-randomize the current deck on demand.
  - Applies to: **To Study**, **Unsure**, **Custom**, **Learned → Study**.
- **Custom Set:**
  - Custom Set now uses **Custom Set Settings** for sort/random (instead of global study settings).
  - Added Settings action to **pick a number of random Unlearned cards** for the Custom Set (with 🎲 helper).

---

## v4.4.1 (versionCode 21) — 2026-01-13
### Added
- `syncPullApiKeysForUser()` method in Repository for user-level API key retrieval
- `pullApiKeysForUser()` method in WebAppSync calling `/api/sync/apikeys`

### Changed
- **API keys pulled for ALL users**: All authenticated users now receive API keys on login (not just admins)
- Uses new `/api/sync/apikeys` endpoint available to all authenticated users
- Non-admin users can now use AI breakdown features without admin access

---

## v4.4.0 (versionCode 20) — 2026-01-13
### Fixed
- **Admin Screen Loading**: Fixed admin screen immediately redirecting by waiting for settings to load
- Admin screen now shows loading spinner while settings load

### Added
- **(Admin) label**: Shows after username in Login, Sync Progress screens when user is admin
- **Key validation indicators**: "Key Accepted" / "Key Invalid" shown for ChatGPT and Gemini API keys
- **First login auto-sync**: Always syncs progress and breakdowns on first device login
- **Admin auto-pulls API keys**: When admin logs in, API keys are automatically pulled from server

### Changed
- Improved AI picker dropdown in Sync Progress screen with checkmark for current selection
- "Pending sync" message now says "Push to sync" to clarify action needed
- Login screen clarifies that first login always syncs automatically
- Auto-pull setting renamed to "Auto-pull progress on future logins"

---

## v4.3.0 (versionCode 19) — 2026-01-13
### Added
- **Model Selection**: Choose AI model for ChatGPT (gpt-4o default) and Gemini (gemini-1.5-flash default)
- Model settings sync with server alongside API keys
- **Admin Users SoT**: Fetches admin usernames from server on login (`/api/admin/users`)

### Fixed
- **Admin Button**: Fixed isAdmin() check not recognizing logged-in admin user
- Simplified admin username comparison logic with server-side Source of Truth

### Changed
- Admin screen renamed to "AI Access Settings"
- Push/Pull buttons now sync models along with API keys
- ChatGPT default model changed from gpt-3.5-turbo to gpt-4o
- AdminUsers object now caches admin list from server

---

## v4.2.0 (versionCode 18) — 2026-01-12
### Added
- **About Screen**: New About page in More with app info, creator contact (Sidney Shelton, Sidscri@yahoo.com), and feature overview
- **User Guide Screen**: Comprehensive printable/downloadable user guide accessible from About page
- **Login Screen**: Dedicated login page moved from Admin Settings (all users can access)
- **Sync Progress Screen**: New screen for Push/Pull progress sync and Breakdown sync
- **Gemini AI Integration**: Added Google Gemini API support for breakdown autofill
- **Breakdown AI Selector**: Users can choose between Auto Select (best result), ChatGPT, or Gemini for AI breakdowns
- **Auto-sync settings**: Option to auto-pull progress on login and auto-push changes when made
- **Pending sync indicator**: Visual indicator when offline changes need syncing
- **API key sync**: Admin can push/pull encrypted API keys to/from server
- **Version display**: Current app version shown in Settings screen

### Changed
- **Navigation restructure**: 
  - Login moved from Admin to its own Login screen in More
  - Sync functions moved to dedicated Sync Progress screen
  - Admin Settings only visible to admin users (Sidscri)
- Admin screen now only contains API key management (ChatGPT + Gemini)
- Improved login flow with auto-sync on successful login

### Security
- Admin Settings screen restricted to admin users only
- API keys can be encrypted and stored on server for cross-device access

---

## v4.1.0 (versionCode 17) — 2026-01-12
### Added
- Shared ID mapping for cross-device sync compatibility
- Helper mapping integration matching web server IDs

### Fixed
- Sync fully working with web server v5.2+

---

## v4.0.7.1 (versionCode 15/16) — 2026-01-11
### Added
- Shared card ID approach — both Android and Web resolve identical IDs for breakdowns/progress

### Fixed
- Cross-device sync alignment with web server

---

## v4.0.7 (versionCode 14) — 2026-01-10
### Fixed
- **Critical:** Changed login endpoint from `/api/login` to `/api/sync/login`
- Root cause: Server had duplicate `/api/login` routes; Flask used web session endpoint instead of token endpoint
- Auth tokens now correctly received and saved

---

## v4.0.5 (versionCode 12) — 2026-01-10
### Added
- Debug instrumentation for login response
- `debugInfo` field in `LoginResult` capturing token length and raw response preview
- This debug output revealed the root cause (server returning `{ok, user}` with no token)

---

## v4.0.4 (versionCode 11) — 2026-01-09
### Changed
- Rewrote login save logic to create fresh `AdminSettings` object instead of using `.copy()` on stale state
- Added token preview display showing first 8 characters

### Fixed
- Attempted fix for token not persisting (root cause was server-side)

---

## v4.0.3 (versionCode 10) — 2026-01-09
### Added
- `syncPushProgressWithToken()` and `syncPullProgressWithToken()` methods
- `CustomCardStatus` enum and `CustomSetSettings` for future Custom Set isolation

### Fixed
- Attempted fix for "No auth token" error (root cause was server-side)

---

## v4.0.2 (versionCode 9) — 2026-01-09
### Fixed
- Changed breakdowns endpoint from `/api/breakdowns` to `/api/sync/breakdowns`
- Resolved 401 errors on Sync Breakdowns

---

## v4.0.1 (versionCode 8) — 2026-01-09
### Fixed
- Button layout issues in All Cards screen
- Improved landscape mode for Custom/Learned screens
- Renamed status labels

### Added
- Reset to Default Settings option

---

## v4.0.0 (versionCode 7) — 2026-01-09
### Added
- Landscape mode support
- Group filtering for study screens
- Web app login/sync system (Admin screen)
- ChatGPT API integration for breakdown auto-fill
- Admin settings screen

---

## v3.0.1 — 2026-01-08
### Changed
- Speaker button: removed text, icon-only
- Renamed "Unlearned" to "To Study"

### Added
- Custom set star icon on study screens (To Study, Unsure, Learned>Study)

---

## v2.2.0 — 2026-01-08
### Added
- Custom study sets with star-based selection
- Group filtering dropdown
- Sort mode settings (JSON order / alphabetical / group-based)
- Admin section placeholder
- Return-to-top navigation

### Fixed
- Text visibility issues in Learned/All screens
- Breakdown button visibility across all views

---

## v2.1.0 — 2026-01-08
### Fixed
- Text visibility issues (purple text on dark background)

### Changed
- Updated versioning strategy for F-Droid updates

### Added
- QR code landing page

---

## v2.0.0 — 2026-01-07
### Added
- 3-state progress tracking (Active / Unsure / Learned)
- Term breakdowns with AI auto-fill capability
- Voice customization
- Dark theme styling
- Bottom navigation
- Custom study sets

---

# How to Update This Changelog

## Manual Updates
1. When you make changes, add them under `## Unreleased`
2. When releasing:
   - Update `versionCode` and `versionName` in `app/build.gradle`
   - Rename `## Unreleased` to `## vX.Y.Z (versionCode N) — YYYY-MM-DD`
   - Create a new empty `## Unreleased` section

## Version Numbering
- `versionName`: User-visible version (e.g., "4.1.0")
- `versionCode`: Integer that must increment for each release (e.g., 17)

## Build & Release
```bash
# Update build.gradle:
versionCode 17
versionName "4.1.0"

# Build release APK:
./gradlew assembleRelease

# Output: app/build/outputs/apk/release/app-release.apk
```

## v4.4.2 (v22) – Implemented fixes (verified in code)

- **Admin badge:** if the logged-in user is an admin, the UI shows **(Admin)** after the username.
- **Search UX (portrait):**
  - Portrait uses a **search icon** toggle (matches landscape).
  - Tapping outside of search **closes the search UI but keeps filtered results**.
  - Added an **X** icon to clear search and reset the deck position.
- **Random study controls:**
  - Added **Random** checkbox beside **Card #/##**.
  - Added **⟳ Reshuffle** icon to re-randomize the current deck on demand.
  - Applies to: **To Study**, **Unsure**, **Custom**, **Learned → Study**.
- **Custom Set:**
  - Custom Set now uses **Custom Set Settings** for sort/random (instead of global study settings).
  - Added Settings action to **pick a number of random Unlearned cards** for the Custom Set (with 🎲 helper).
