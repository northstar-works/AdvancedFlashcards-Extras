# SidscriPi Dashboard Changelog

## v2.2.0 (2026-02-18) - Dashboard Safety + Better Embedded UI

### ✨ New Features

1. **Hide stopped services (optional)**
   - New Settings toggle: *Hide stopped services on the Dashboard*
   - When enabled, only `active` services appear on the main list.

2. **Safer controls to prevent accidental shutdowns**
   - New Settings toggle: *Disable Stop actions* (hides Stop button **and** blocks Stop via the dashboard API)
   - New Settings toggle: *Protect Pi Dashboard service* (always blocks Stop for `pi-dashboard`)

3. **Hide specific services from the Dashboard list**
   - New Settings: *Hidden services* (unit names)
   - Supports manual entry and a multi-select picker.

### 🛠️ UI Improvements

1. **Better scrolling for embedded service UIs (Viewer)**
   - Modal panels now size to the viewport with safer flex behavior (`min-height:0`)
   - Background page scroll locks while a modal is open
   - Improved small-screen layout: viewer bar wraps and URL moves to its own line


## v2.1.0 (2025-02-17) - Major Bug Fix Release

### 🐛 Critical Bug Fixes

1. **Fixed Empty Dashboard** - Dashboard now properly renders services and system info
   - Added null checks in `renderSys()` and `renderSvc()` functions
   - Added loading states while data is being fetched

2. **Fixed All Action Buttons Not Working** - JavaScript syntax error that broke all functionality
   - **Root cause**: Missing closing brace `}` in the `kiwixRefresh()` function
   - This caused ALL JavaScript after line 1091 to fail, including:
     - Start/Stop/Restart buttons
     - View (eye icon) button
     - Edit (config) button
     - Settings tab functionality
     - Logs tab functionality

3. **Fixed HTML Structure** - Missing `</div>` tag for the logs tab section
   - This caused overlapping content and broken layout

4. **Fixed `switchTab()` Function** - Was using undefined `event` variable
   - Now correctly passes the button element as a parameter

### ✨ New Features

1. **Back to Dashboard Button** 
   - Added prominent "← Dashboard" button in both Viewer and Editor panels
   - Pressing it closes overlays and returns to the main dashboard tab

2. **File Browser for Config Files**
   - When a service has no config files defined, you can now browse for them
   - Click the "📁 Browse..." button in the editor to navigate directories
   - Supports navigating through `/opt/`, `/etc/`, `/home/` paths
   - Shows only config-like files (.conf, .xml, .yaml, .toml, .json, etc.)
   - Manual path input also supported

3. **Always-Available Edit Button**
   - Edit button now shows for ALL services
   - If no config files are predefined, it opens the file browser
   - Makes it easier to discover and edit configuration

4. **Expanded Allowed Edit Paths**
   - Added `/opt/` and `/etc/` as allowed editing paths
   - More flexible for custom service configurations

5. **API Endpoint for Directory Browsing**
   - New `/api/browse?path=/path` endpoint
   - Returns directory listing with file/folder types

### 🔧 Technical Improvements

- Better error handling throughout JavaScript
- Loading states prevent empty UI during fetch
- Escape key now closes all overlays (viewer, editor, browser)
- Improved tab switching reliability
- Added data-tab attributes for nav buttons

### 📝 Files Changed

- `server.py` - Complete rewrite of JavaScript section, added browse API

## v2.0.0 - Previous Version

- Initial v2 release with service dashboard
- Real-time system monitoring
- Service start/stop/restart
- Config file editor
- Kiwix library refresh
- Settings management
